(function(root){'use strict';
const R=typeof module!=='undefined'?require('./relation-network'):root.GhostRelationNetwork;
const taxonomy=typeof module!=='undefined'?require('./place-taxonomy'):root.GhostPlaceTaxonomy;
function hits(text,words){const found=[],occupied=[];for(const word of [...new Set(words)].filter(Boolean).sort((a,b)=>b.length-a.length||(a<b?-1:a>b?1:0))){let at=-1;while((at=text.indexOf(word,at+1))>=0){const end=at+word.length;if(occupied.some(([a,b])=>at<b&&end>a))continue;occupied.push([at,end]);found.push({word,at,end});}}return found.sort((a,b)=>a.at-b.at);}
const sceneTerms=new Set(Object.values(taxonomy.groups).flatMap(g=>g.words).filter(w=>taxonomy.classify(w).category==='space'));
const otherworld=new Set(['冥府','冥司','冥界','阴司','阴曹','阴世','幽冥','地府','天宫','九天','瑶池','广寒宫','广寒','仙人岛','神仙岛','罗刹国','大罗刹国','毒龙国','十八狱','黑暗狱']);
// These units require semantic review before they can establish or inherit a scene.
function uncertainScene(text){return /追述|忆及|昔年|闻说|听说|梦见|梦中|尝闻|传闻|据说|欲往|欲赴|欲至|将往|将赴|拟往|未至|未到|不至|不到|[曰云言道][：:]*[“「]/.test(text);}
function evidenceKey(chapterId,source,target,anchorText,text){return JSON.stringify([chapterId,source,target,anchorText,text]);}
function connectedGraph(graph,preserve=()=>false){const ids=new Set(graph.edges.flatMap(e=>[e.source,e.target]));return {...graph,nodes:graph.nodes.filter(n=>ids.has(n.id)||preserve(n))};}
function uniqueSteps(steps){return (typeof module!=='undefined'?require('../spatial-routes'):root.GhostSpatialRoutes).normalize(steps);}
function movementNotes(c){
 const source=c.units.map(u=>u.text).join('').replace(/\s/gu,'');
 const steps=c.route_steps?c.route_steps.map(s=>({...s,from:s.from_space,to:s.to_space,fromPlace:s.from?.name||null,toPlace:s.to?.name||null,kind:s.transition_kind})):uniqueSteps(c.steps);
 return steps.filter(s=>s.kind==='movement'&&s.from&&s.to&&s.quote&&source.includes(s.quote.replace(/\s/gu,''))).map(s=>{const from=hits(s.from,c.places),to=hits(s.to,c.places);return {chapter:c.title,chapterId:c.id,unit:s.unit,source_indices:s.source_indices,from:s.from,to:s.to,fromPlace:c.route_steps?s.fromPlace:from.length===1?from[0].word:null,toPlace:c.route_steps?s.toPlace:to.length===1?to[0].word:null,actors:Array.isArray(s.actors)?s.actors:(s.actors||'').split(/[、，,]/u).filter(Boolean),text:s.quote};});
}
function spaceView(graph,id,reverse,includeContext=false){const edges=graph.edges.map(e=>({...e,evidence:e.evidence.filter(r=>includeContext||r.assignment==='explicit')})).filter(e=>(reverse?e.target===id:e.source===id)&&e.evidence.length).map(e=>({...e,weight:new Set(e.evidence.map(r=>r.chapterId)).size}));const ids=new Set([id,...edges.flatMap(e=>[e.source,e.target])]);return {nodes:graph.nodes.filter(n=>ids.has(n.id)).map(n=>({...n,degree:edges.filter(e=>e.source===n.id||e.target===n.id).length})),edges,mode:'located-spaces'};}
function buildRaw(chapters,options={}){
 const places=new Map(),pairs=new Map(),spaces=new Map(),otherworldSpaces=new Map(),pending=[];
 const node=word=>{const id='place:'+word;if(!places.has(id))places.set(id,{id,label:word,kind:'place',realm:otherworld.has(word)?'otherworld':'human',degree:0});return id;};
 for(const original of chapters){const accepted=w=>original.reviews?.['places:'+w]?.status==='accepted'&&original.reviews['places:'+w].kind==='places',moved=original.places.filter(w=>sceneTerms.has(w)&&!accepted(w)),c={...original,places:original.places.filter(w=>!original.spaces.includes(w)&&(accepted(w)||taxonomy.classify(w).category==='place')),spaces:[...new Set([...original.spaces,...moved])].filter(w=>taxonomy.classify(w).category!=='excluded')};
  for(const p of c.places)node(p);
  const units=c.units.map(u=>({...u,ps:hits(u.text,c.places.filter(w=>!u.token_words||u.token_words.includes(w))),ss:hits(u.text,c.spaces.filter(s=>!c.places.includes(s)&&(!u.token_words||u.token_words.includes(s))))})),present=[...new Set(units.flatMap(u=>u.ps.map(p=>p.word)))].sort();
  for(let i=0;i<present.length;i++)for(let j=i+1;j<present.length;j++){const source=node(present[i]),target=node(present[j]),key=JSON.stringify([source,target]);if(!pairs.has(key))pairs.set(key,{source,target,weight:0,relation:'places',chapter:'同篇地点',evidence:[]});const e=pairs.get(key);e.weight++;const excerpts=units.filter(u=>u.ps.some(p=>p.word===present[i]||p.word===present[j]));e.evidence.push({chapter:c.title,chapterId:c.id,actors:[],text:excerpts.map(u=>u.text).join('\n…\n'),basis:'同篇地点关系，每篇计1次；不表示人物移动',units:excerpts.map(u=>u.id)});}
  // Use an endpoint only when both its place and space are unambiguous and
  // the saved quotation is present in the source. Never assign all chapter spaces.
  const text=c.units.map(u=>u.text).join('').replace(/\s/gu,'');
  for(const step of uniqueSteps(c.steps)){if(!step.quote||!text.includes(step.quote.replace(/\s/gu,'')))continue;
   for(const endpoint of [step.from,step.to]){if(!endpoint)continue;const pp=hits(endpoint,c.places),ss=hits(endpoint,c.spaces);if(pp.length!==1)continue;
    for(const s of ss){if(!step.quote.includes(s.word))continue;const source=node(pp[0].word),target='space:'+s.word,key=JSON.stringify([source,target]);if(!spaces.has(key))spaces.set(key,{source,target,weight:0,relation:'located-space',chapter:'地点与空间',evidence:[]});const e=spaces.get(key);if(!e.evidence.some(r=>r.chapterId===c.id))e.weight++;if(!e.evidence.some(r=>r.chapterId===c.id&&r.quote===step.quote))e.evidence.push({chapter:c.title,chapterId:c.id,unit:step.unit,quote:step.quote,text:step.quote,actors:Array.isArray(step.actors)?step.actors:(step.actors||'').split(/[、，,]/u).filter(Boolean),basis:'已保存路径端点的地点归属，仍可回原文核对',assignment:'endpoint'});
    }
   }
  }
  const boundRoutes=(c.route_steps||[]).filter(s=>s.source_valid&&s.transition_kind==='movement'&&(s.from_place_id||s.to_place_id));
  const starts=new Map(),ends=new Map();for(const s of boundRoutes){const end=s.unit_end??s.unit;if(!starts.has(s.unit))starts.set(s.unit,[]);starts.get(s.unit).push(s);if(!ends.has(end))ends.set(end,[]);ends.get(end).push(s);}
  let current=null;
  for(const u of units){
   // An explicitly reviewed journey interrupts the old scene. Its destination
   // can anchor subsequent units, but a departure must not leave later rooms
   // attributed to the city just left (e.g. Huang Ying's return from Jinling).
   const starting=starts.get(u.id)||[],ending=ends.get(u.id)||[];
   if(starting.length)current=null;
   const uncertain=uncertainScene(u.text);if(uncertain)current=null;
   const anchors=uncertain?[]:u.ps.filter(p=>!/^人/.test(u.text.slice(p.end))&&(/[在于至到抵赴往如游寓居归入过自从]$/.test(u.text.slice(0,p.at))||/^(?:城中|境内|境中)/.test(u.text.slice(p.end))));
   if(u.ps.length&&!anchors.length)current=null;
   for(const s of u.ss){
    const preceding=anchors.filter(p=>p.end<=s.at).at(-1),intervening=u.ps.some(p=>p.end<=s.at&&(!preceding||p.at>preceding.at)),anchor=preceding?{place:preceding.word,unit:u.id,text:u.text}:(!u.ps.length?current:null);
    if(!anchor||intervening){pending.push({chapter:c.title,chapterId:c.id,space:s.word,unit:u.id,text:u.text});continue;}
    const source=node(anchor.place),target='space:'+s.word,key=JSON.stringify([source,target]);if(!spaces.has(key))spaces.set(key,{source,target,weight:0,relation:'located-space',chapter:'地点与空间',evidence:[]});const e=spaces.get(key),same=anchor.unit===u.id;
    if(!e.evidence.some(r=>r.chapterId===c.id))e.weight++;
    if(!e.evidence.some(r=>r.chapterId===c.id&&r.unit===u.id))e.evidence.push({chapter:c.title,chapterId:c.id,unit:u.id,anchorUnit:anchor.unit,anchorText:anchor.text,quote:u.text,evidenceId:evidenceKey(c.id,source,target,anchor.text,u.text),actors:R.presentPeople(c,u.text),text:same?u.text:anchor.text+'\n…\n'+u.text,basis:same?'定位语句同单位线索':'延续前文场景的线索，需结合上下文核对',assignment:same?'explicit':'context'});
   }
   if(anchors.length){const last=anchors.at(-1);current={place:last.word,unit:u.id,text:u.text};if(u.ps.some(p=>p.at>last.at))current=null;}
   if(ending.length){const last=ending.at(-1),place=last.to?.name,word=place&&c.places.find(w=>(c.place_aliases?.[w]||w)===place);current=word?{place:word,unit:u.id,text:last.quote}:null;}
  }
 }
 if(options.includeOtherworld){
   for(const original of chapters){
    const accepted=w=>original.reviews?.['places:'+w]?.status==='accepted'&&original.reviews['places:'+w].kind==='places';
    const cPlaces=original.places.filter(w=>!otherworld.has(w)&&!original.spaces.includes(w)&&(accepted(w)||taxonomy.classify(w).category==='place'));
    const evidences=(original.realm_evidence||[]).filter(e=>(e.realm==='天界'||e.realm==='地界')&&e.space&&original.evidence_review?.[e.id]?.kind!=='reject');
    for(const evidence of evidences){
     const otherId=node(evidence.space),other=places.get(otherId);other.realm='otherworld';other.otherworldRealm=evidence.realm;
     for(const place of cPlaces.filter(p=>p!==evidence.space)){
      const source=node(place),key=JSON.stringify([source,otherId]);
      if(!pairs.has(key))pairs.set(key,{source,target:otherId,weight:0,relation:'place-otherworld',chapter:'地点与异境',evidence:[]});
      const edge=pairs.get(key);if(!edge.evidence.some(r=>r.chapterId===original.id&&r.id===evidence.id)){edge.weight++;edge.evidence.push({id:evidence.id,chapter:original.title,chapterId:original.id,unit:evidence.unit,actors:[],text:evidence.excerpt||'',basis:'同篇提及，非移动证据',assignment:'otherworld'});}
     }
     const spaceId='space:'+evidence.space;if(!otherworldSpaces.has(spaceId))otherworldSpaces.set(spaceId,{id:spaceId,label:evidence.space,kind:'space',realm:'otherworld',otherworldRealm:evidence.realm,degree:0});
     for(const place of cPlaces.filter(p=>p!==evidence.space)){const source=node(place),key=JSON.stringify([source,spaceId]);if(!spaces.has(key))spaces.set(key,{source,target:spaceId,weight:0,relation:'located-otherworld',chapter:'地点与异境',evidence:[]});const edge=spaces.get(key);if(!edge.evidence.some(r=>r.chapterId===original.id&&r.id===evidence.id)){edge.weight++;edge.evidence.push({id:evidence.id,chapter:original.title,chapterId:original.id,unit:evidence.unit,quote:evidence.excerpt||'',text:evidence.excerpt||'',actors:[],basis:'同篇提及，非移动证据',assignment:'otherworld'});}}
    }
   }
  }
 const allPlaceNodes=[...places.values()].map(n=>({...n})),ppAll={nodes:allPlaceNodes,edges:[...pairs.values()],mode:'places-all'},psNodes=new Map([...places].map(([id,n])=>[id,{...n}]));for(const original of chapters)for(const word of original.places.filter(w=>sceneTerms.has(w))){const id='space:'+word;if(!psNodes.has(id))psNodes.set(id,{id,label:word,kind:'space',degree:0});}for(const [id,n] of otherworldSpaces)if(!psNodes.has(id))psNodes.set(id,{...n});for(const e of spaces.values())if(!psNodes.has(e.target))psNodes.set(e.target,{id:e.target,label:e.target.slice(6),kind:'space',degree:0});const ps={nodes:[...psNodes.values()],edges:[...spaces.values()],mode:'located-spaces'};
 for(const g of [ppAll,ps]){const byId=new Map(g.nodes.map(n=>[n.id,n]));for(const e of g.edges){byId.get(e.source).degree++;byId.get(e.target).degree++;}}
 const isolatedPlaces=ppAll.nodes.filter(n=>n.degree===0),connectedIds=new Set(ppAll.nodes.filter(n=>n.degree>0).map(n=>n.id)),pp={nodes:ppAll.nodes.filter(n=>connectedIds.has(n.id)),edges:ppAll.edges.filter(e=>connectedIds.has(e.source)&&connectedIds.has(e.target)),mode:'places'};const classification=[...new Set(chapters.flatMap(c=>c.places))].sort().map(word=>({...taxonomy.classify(word),evidence:chapters.filter(c=>c.places.includes(word)).map(c=>({chapter:c.title,chapterId:c.id,units:c.units.filter(u=>u.text.includes(word))}))}));return {places:pp,placesAll:ppAll,spaces:ps,pending,isolatedPlaces,classification};
}
function build(chapters,options={}){
 const out=buildRaw(chapters,options),aliases=Object.assign({},...chapters.map(c=>c.place_aliases||{}));
 if(Object.entries(aliases).some(([a,b])=>a!==b)){
  const Merge=typeof module!=='undefined'?require('../place-node-merges'):root.GhostPlaceNodeMerges;
  out.placesAll=Merge.graph(out.placesAll,aliases);out.spaces=Merge.graph(out.spaces,aliases);
  out.isolatedPlaces=out.placesAll.nodes.filter(n=>!n.degree);out.places=connectedGraph({...out.placesAll,mode:'places'});
 }
 return out;
}
const api={build,hits,sceneTerms,otherworld,spaceView,uncertainScene,connectedGraph,movementNotes,uniqueSteps};if(typeof module!=='undefined'){module.exports=api;return;}
const el=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
function mount(container,chapters,onExport,options={}){
 const graphs=build(chapters,{includeOtherworld:true}),intro=el('section');intro.className='card';intro.append(el('h2','地点与空间'));container.append(intro);
 const first=el('section'),second=el('section');first.className=second.className='card';first.append(el('h2','一、全书地点网络'),el('p','同篇地点相连，线宽表示涉及篇数。'));second.append(el('h2','二、篇目空间网络'),el('p','选择篇目，查看地点、空间与异境。点线读原文。'));container.append(first,second);

 const allOut=el('div'),range=el('select');range.setAttribute('aria-label','地点网络范围');for(const [v,t]of [['located','已定位地点'],['unmapped','未定位地点＋异境'],['all','全部地点词']]){const o=el('option',t);o.value=v;range.append(o);}const savedRange=new URLSearchParams(root.location?.search||'').get('range');range.value=['located','unmapped','all'].includes(savedRange)?savedRange:'all';const rangeLabel=el('label','网络范围');rangeLabel.append(range);first.append(rangeLabel,allOut);
 const viewMode=el('select');viewMode.setAttribute('aria-label','空间网络视图');for(const [v,t]of [['chapter','按篇目'],['place','按地点']]){const o=el('option',t);o.value=v;viewMode.append(o);}const viewLabel=el('label','空间网络 ');viewLabel.append(viewMode);second.append(viewLabel);
 second.id='chapter-spatial-network';
 const chapterPanel=el('div'),placePanel=el('div');placePanel.hidden=true;second.append(chapterPanel,placePanel);
 if(root.location?.hash==='#chapter-spatial-network')root.requestAnimationFrame?.(()=>second.scrollIntoView?.({block:'start'}));
 const chapterUI=root.GhostChapterSpaces.mount(chapterPanel,chapters,{placeRecords:options.placeRecords});
 const placePick=el('select');placePick.setAttribute('aria-label','选择地点查看内部空间');
 for(const n of graphs.spaces.nodes.filter(n=>n.kind==='place'&&graphs.spaces.edges.some(e=>e.source===n.id)).sort((a,b)=>a.label.localeCompare(b.label,'zh'))){const o=el('option',n.label);o.value=n.id;placePick.append(o);}
 const placePlot=el('div');placePanel.append(placePick,el('p','线表示场景归属；点线查看原文。'),placePlot);
 function drawPlaceSpaces(){placePlot.replaceChildren();if(!placePick.value){placePlot.append(el('p','当前范围没有具备归属证据的地点—空间关系。'));return;}const graph=spaceView(graphs.spaces,placePick.value,false,true);root.GhostBookNetwork.mount(placePlot,chapters,onExport,{graph,lexical:true,simple:true,readable:true,allowAll:true,chapterSpatial:true,realmColors:true,networkTitle:'地点与空间',relationLegend:'连线依据定位语句、场景延续或路径端点；以原文为准。'});}
 placePick.onchange=drawPlaceSpaces;viewMode.onchange=()=>{chapterPanel.hidden=viewMode.value!=='chapter';placePanel.hidden=viewMode.value!=='place';second.children[0].textContent=viewMode.value==='place'?'二、地点与空间':'二、篇目空间网络';if(!placePanel.hidden)drawPlaceSpaces();};
 if(new URLSearchParams(root.location?.search||'').get('spaceview')==='place'){viewMode.value='place';viewMode.onchange();}
 // Compatibility with place-linked bookmarks: choose the first matching chapter.
 const pick={set value(id){const c=chapters.find(c=>c.places.some(w=>(c.place_aliases?.[w]||w)===id.slice(6)));if(c)chapterUI.selectChapter(c.id);if([...placePick.children].some(o=>o.value===id)){placePick.value=id;if(viewMode.value==='place')drawPlaceSpaces();}}};

 let prepared=null,levels=options.placeRecords||{},levelsReady=!!options.placeRecords;
 const moves=el('details'),moveBody=el('div');moves.append(el('summary','人物移动与原文'),moveBody);first.append(moves);const notes=chapters.flatMap(movementNotes);
 function drawMoves(id){moveBody.replaceChildren();if(id)moves.open=true;const word=id?.slice(6),rows=notes.filter(r=>!word||r.fromPlace===word||r.toPlace===word||r.from.includes(word)||r.to.includes(word));moves.children[0].textContent='人物移动与原文（'+rows.length+'条）';for(const r of rows.slice(0,100))moveBody.append(el('strong','《'+r.chapter+'》 · '+(r.actors.join('、')||'人物未标明')+'：'+r.from+' → '+r.to),el('blockquote',r.text));if(rows.length>100)moveBody.append(el('p','显示前100条；选择地名缩小范围。'));}drawMoves();
 const label=e=>{const r=e.evidence[0];return (r?'《'+r.chapter+'》':'')+(r?.actors?.length?' · '+r.actors.join('、'):'')+(e.evidence.length>1?' 等':'');};
 const drawAll=()=>{allOut.replaceChildren();if((range.value==='located'||range.value==='unmapped')&&!levelsReady){allOut.append(el('p','定位资料尚未载入，请稍后重试。'));return;}const source=graphs.placesAll||graphs.places;let graph=source;if(range.value==='located'||range.value==='unmapped'){const nodes=source.nodes.filter(n=>n.realm==='otherworld'||(range.value==='located'?levels[n.label]?.located:!levels[n.label]?.located)),ids=new Set(nodes.map(n=>n.id));graph={nodes,edges:source.edges.filter(e=>ids.has(e.source)&&ids.has(e.target)),mode:range.value==='located'?'places-located':'places-unmapped'};}graph=connectedGraph(graph,n=>n.realm==='otherworld');const exact=prepared?.graphs['places:full'],matched=exact?.signature===root.GhostTutorialNetwork.signature(graph)?exact:null;root.GhostBookNetwork.mount(allOut,chapters,onExport,{graph,lexical:true,scope:'chapter',simple:true,readable:true,allowAll:true,levelColors:!!root.GhostPlaceLevelColors,levelRecords:levels,realmColors:true,kindLegend:'地点按层级配色；朱红：异境。',relationLegend:'— 表示两地同篇出现，不代表实际移动。异境节点来自篇内原文证据。线长不作数量比较。',initialView:'all',spreadLayout:true,edgeLabel:label,tutorial:!!matched,partition:matched?.partition,metrics:matched?.metrics,positions:matched?.positions,onNodeSelect:id=>{if(!graphs.spaces.nodes.some(n=>n.kind==='place'&&n.id===id))return;pick.value=id;drawSpaces();drawMoves(id);},networkTitle:range.value==='located'?'已定位地点网络（含异境）':range.value==='unmapped'?'未定位地点与异境网络':'全部地点词网络（含异境）'});};
 const drawSpaces=()=>chapterUI.refresh(levels);
 pick.onchange=drawSpaces;range.onchange=drawAll;drawAll();if(!options.placeRecords)fetch('place-levels.json',{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error();return r.json();}).then(d=>{levels=d.places||{};levelsReady=true;renderUnresolved();drawAll();drawSpaces();}).catch(()=>{unresolved.children[0].textContent='定位资料加载失败，请刷新重试';});fetch('networkx-analysis.json',{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error();return r.json();}).then(d=>{prepared=d;}).catch(()=>{});
 const unresolved=el('details');unresolved.append(el('summary','未定位地点核查（载入定位资料后统计）'));const unresolvedBody=el('div');unresolved.append(unresolvedBody);const renderUnresolved=()=>{unresolvedBody.replaceChildren();const rows=graphs.classification.filter(r=>r.category==='place'&&!levels[r.word]?.located);unresolved.children[0].textContent='未定位地点核查（'+rows.length+'项）';if(!rows.length){unresolvedBody.append(el('p','目前没有未定位的地点候选词。'));return;}for(const r of rows){const row=el('details');row.append(el('summary',r.word+' · '+r.evidence.length+'篇'));let expanded=false;row.ontoggle=()=>{if(!row.open||expanded)return;expanded=true;for(const e of r.evidence)for(const u of e.units)row.append(el('strong','《'+e.chapter+'》'),el('blockquote',u.text));const edit=el('a','打开地点修订');edit.href='../../index.html#location-panel';edit.target='_blank';edit.rel='noopener';row.append(edit,el('p','在地点修订中搜索：'+r.word));};unresolvedBody.append(row);}unresolvedBody.append(el('p','以上列出全部未定位地点候选词；请逐条结合原文与历史地理资料核算。'));};first.append(unresolved);const pending=el('details');pending.append(el('summary','全书尚未归属地点的空间线索（'+graphs.pending.length+'处）'));let loaded=false;pending.ontoggle=()=>{if(!pending.open||loaded)return;loaded=true;const list=el('div'),more=el('button','再看50条');let offset=0;const add=()=>{for(const r of graphs.pending.slice(offset,offset+50))list.append(el('strong','《'+r.chapter+'》 · '+r.space),el('blockquote',r.text));offset+=50;more.hidden=offset>=graphs.pending.length;};more.onclick=add;pending.append(list,more);add();};container.append(pending);
 const method=el('details');method.append(el('summary','关系定义与资料下载'),el('p','地名按现有地点词表保留，未自动合并别名。同篇关系没有方向，不表示两个地点间发生移动。地点—空间只在定位语句或其后续场景建立线索；遇到其他地名、追述或梦见等提示会中断场景继承，人物籍贯不作为所在场所。仍需逐条核对；没有定位依据的空间不连线。'),el('p','图中隐藏无关联节点，下载资料保留；教程统计仅在整图指纹匹配时使用。空间词同名合并为词汇节点，不表示各篇中的宅院是同一建筑。'));const save=el('button','下载两个网络及未归属线索');save.onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify(graphs)],{type:'application/json'})),a=el('a');a.href=url;a.download='聊斋-地点与空间网络.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};method.append(save);container.append(method);
 if(options.placeRecords)renderUnresolved();
}
root.GhostPlaceSpaces={...api,mount};
})(typeof window==='undefined'?globalThis:window);
