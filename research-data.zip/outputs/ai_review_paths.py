"""Resumable DeepSeek audit of narrative-space classifications and omissions."""
from __future__ import annotations
import argparse, getpass, json, os, re
from datetime import datetime, timezone
from pathlib import Path
from urllib import error, request

ROOT = Path(__file__).parent
DATA = ROOT / 'ghost_map'
SOURCE = DATA / '歷史地名對照與文本地圖.json'
OUT = DATA / '空间路径_AI审核.json'
LEDGER = DATA / '空间路径_AI审核_预算.json'
URL = 'https://api.deepseek.com/chat/completions'
INPUT_PRICE, OUTPUT_PRICE = .30, 1.20
ACCESS = {'私人', '公共', '混合', '开放自然', '待核'}
REALM = {'人间', '异境', '待核'}
KINDS = {'movement', 'plot', 'mention'}


def prompt(chapter):
    text = ''.join(u['text'] for u in chapter.get('source_units', []))
    events = [{k: e.get(k, '') for k in ('unit', 'quote', 'actors', 'space', 'from_space', 'to_space', 'transition_kind')}
              for e in chapter.get('narrative_events', [])]
    return ('你是《聊斋志异》空间叙事校核助手。严格依据输入简体原文，不改写原文，不把推测当事实。'
            '请核查已有情节步骤的两个独立字段：space_access 只能是 私人、公共、混合、开放自然、待核；'
            'space_realm 只能是 人间、异境、待核。私人/公共/混合/开放自然按人物的进入、观看、控制权与空间边界判断；'
            '人间/异境须看情节与原文，天宫、龙宫、冥府、地狱、仙境等属于异境，普通地点不能自动变成异境。'
            '同时查找已有步骤遗漏的明确空间变化，只补充有原文引句、能说明人物或情节从一个空间到另一个空间的步骤。'
            '不要把方位词、距离词、天气、抽象比喻当作地点，不要补充纯静态地点。只输出 JSON：'
            '{"classifications":[{"step":0,"space_access":"私人","space_realm":"人间",'
            '"evidence":"不超过40字","confidence":0.0}],"added_events":[{"unit":0,"unit_end":0,'
            '"quote":"原文连续引句","actors":"人物","space":"空间变化", "from_space":"",'
            '"to_space":"", "transition_kind":"movement|plot|mention", "event":"不超过60字",'
            '"space_access":"待核","space_realm":"待核","evidence":"不超过40字","confidence":0.0}]}\n篇名：' + chapter['chapter'] +
            '\n已有步骤：' + json.dumps(events, ensure_ascii=False) + '\n原文：' + text)


def cost(usage):
    p = usage.get('prompt_tokens') or usage.get('input_tokens')
    c = usage.get('completion_tokens') or usage.get('output_tokens')
    return ((p * INPUT_PRICE + c * OUTPUT_PRICE) / 1_000_000) if isinstance(p, int) and isinstance(c, int) else 0


def call(chapter, key, model, max_tokens=2400):
    body = json.dumps({'model': model, 'messages': [
        {'role': 'system', 'content': '你是古汉语数字人文校勘助手，只输出 JSON。'},
        {'role': 'user', 'content': prompt(chapter)}], 'temperature': 0,
        'response_format': {'type': 'json_object'}, 'max_tokens': max_tokens}).encode('utf-8')
    req = request.Request(URL, data=body, headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key}, method='POST')
    with request.urlopen(req, timeout=180) as response:
        raw = json.loads(response.read().decode('utf-8'))
    content = raw['choices'][0]['message']['content']
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        match = re.search(r'\{.*\}', content, flags=re.S)
        if not match:
            raise
        parsed = json.loads(match.group(0))
    return parsed, raw.get('usage', {})


def validate(result, chapter):
    units = {u['unit']: u for u in chapter.get('source_units', [])}
    full = ''.join(u['text'] for u in chapter.get('source_units', []))
    offsets, cursor = [], 0
    for source_unit in chapter.get('source_units', []):
        offsets.append((source_unit['unit'], cursor, cursor + len(source_unit['text'])))
        cursor += len(source_unit['text'])
    events = chapter.get('narrative_events', [])
    classifications, seen_steps = [], set()
    for row in result.get('classifications', []) if isinstance(result, dict) else []:
        try: step = int(row['step'])
        except (KeyError, TypeError, ValueError): continue
        if not 0 <= step < len(events) or step in seen_steps: continue
        access, realm = row.get('space_access'), row.get('space_realm')
        if access not in ACCESS or realm not in REALM: continue
        seen_steps.add(step)
        classifications.append({'step': step, 'space_access': access, 'space_realm': realm,
                                 'evidence': str(row.get('evidence', ''))[:160],
                                 'confidence': max(0, min(1, float(row.get('confidence', 0))))})
    additions = []
    existing_quotes = {e.get('quote', '') for e in events}
    for row in result.get('added_events', []) if isinstance(result, dict) else []:
        quote = str(row.get('quote', '')).strip()
        try: unit = int(row['unit']); unit_end = int(row.get('unit_end', unit))
        except (KeyError, TypeError, ValueError): continue
        if not quote or quote in existing_quotes or unit not in units or unit_end not in units: continue
        hits = [m.start() for m in re.finditer(re.escape(quote), full)]
        if len(hits) != 1: continue
        start, end = hits[0], hits[0] + len(quote)
        covered = [(number, a, b) for number, a, b in offsets if a < end and start < b]
        if not covered: continue
        unit, unit_end = covered[0][0], covered[-1][0]
        kind = row.get('transition_kind')
        if kind not in KINDS: continue
        if kind == 'movement' and (not row.get('from_space') or not row.get('to_space')): continue
        additions.append({'unit': unit, 'unit_end': unit_end, 'quote': quote,
                          'actors': str(row.get('actors', ''))[:120], 'space': str(row.get('space', ''))[:160],
                          'from_space': str(row.get('from_space', ''))[:120], 'to_space': str(row.get('to_space', ''))[:120],
                          'transition_kind': kind, 'event': str(row.get('event', ''))[:240],
                          'interpretation': str(row.get('evidence', ''))[:160],
                          'space_access': row.get('space_access') if row.get('space_access') in ACCESS else '待核',
                          'space_realm': row.get('space_realm') if row.get('space_realm') in REALM else '待核',
                          **({'space_review_source': 'deepseek', 'space_review_evidence': str(row.get('evidence', ''))[:160]}
                             if row.get('space_access') in ACCESS and row.get('space_realm') in REALM else {}),
                          'ai_path_review': 'deepseek', 'confidence': max(0, min(1, float(row.get('confidence', 0))))})
        existing_quotes.add(quote)
    return {'classifications': classifications, 'added_events': additions}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--limit', type=int, default=20); ap.add_argument('--budget-usd', type=float, default=2.95); ap.add_argument('--max-tokens', type=int, default=2400); ap.add_argument('--model', default=os.getenv('DEEPSEEK_MODEL', 'deepseek-chat')); ap.add_argument('--prompt-key', action='store_true'); args = ap.parse_args()
    key = getpass.getpass('DeepSeek API key (不会写入文件): ') if args.prompt_key else os.getenv('DEEPSEEK_API_KEY')
    if not key: raise SystemExit('未设置 DeepSeek API key')
    payload = json.loads(SOURCE.read_text(encoding='utf-8'))
    chapters = payload['chapter_overview']
    saved = json.loads(OUT.read_text(encoding='utf-8')) if OUT.exists() else {'reviews': []}
    reviews = {str(r['chapter_id']): r for r in saved.get('reviews', []) if r.get('chapter_id') is not None}
    ledger = json.loads(LEDGER.read_text(encoding='utf-8')) if LEDGER.exists() else {'cap_usd': args.budget_usd, 'model': args.model, 'attempts': [], 'price_basis': 'conservative peak input .30/output 1.20 USD per million'}
    used = sum(float(a.get('cost_upper_bound_usd', 0)) for a in ledger['attempts'])
    todo = [c for c in chapters if str(c['chapter_id']) not in reviews][:args.limit]
    print(f'queue={len(chapters)} cached={len(reviews)} remaining_batch={len(todo)} budget_left=${args.budget_usd-used:.4f}', flush=True)
    for chapter in todo:
        reserve = (len(prompt(chapter)) * 4 * INPUT_PRICE + args.max_tokens * OUTPUT_PRICE) / 1_000_000
        if used + reserve > args.budget_usd: break
        attempt = {'chapter_id': chapter['chapter_id'], 'reserved_usd': reserve, 'status': 'reserved'}; ledger['attempts'].append(attempt)
        try:
            result, usage = call(chapter, key, args.model, args.max_tokens); clean = validate(result, chapter)
            reviews[str(chapter['chapter_id'])] = {'chapter_id': chapter['chapter_id'], **clean, 'model': args.model}
            actual = cost(usage); attempt.update(status='accepted', usage=usage, cost_upper_bound_usd=max(reserve, actual), additions=len(clean['added_events']))
        except (error.URLError, TimeoutError, ValueError, KeyError, json.JSONDecodeError) as exc:
            attempt.update(status='failed', error=type(exc).__name__, cost_upper_bound_usd=reserve)
        used += attempt['cost_upper_bound_usd']
        OUT.write_text(json.dumps({'status': 'deepseek_path_review', 'reviews': list(reviews.values())}, ensure_ascii=False, indent=2), encoding='utf-8')
        ledger['used_upper_bound_usd'] = used; LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding='utf-8')
        print(f"chapter={chapter['chapter_id']} cached={len(reviews)} additions={len(reviews.get(str(chapter['chapter_id']), {}).get('added_events', [])) if str(chapter['chapter_id']) in reviews else 0} budget=${used:.4f}", flush=True)
    print(f'done cached={len(reviews)} used_upper_bound=${used:.4f}', flush=True)


if __name__ == '__main__': main()
