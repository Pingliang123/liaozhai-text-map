"""Source-evidenced historical dates linked to story places."""
import re

SOURCE_URL = 'https://agri-history.ihns.ac.cn/history/historic%20table.htm'
ERAS = {'宣德': (1426,1435), '万历': (1573,1620), '崇祯': (1628,1644),
        '顺治': (1644,1661), '康熙': (1662,1722)}
NUMBER = r'[元一二三四五六七八九十百零〇两\d]+'
GANZHI = r'[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]'
DATE = re.compile(r'(?P<era>'+'|'.join(ERAS)+r')(?:(?P<n>'+NUMBER+r')(?:、(?P<n2>'+NUMBER+r'))?年(?:间)?|(?P<gz>'+GANZHI+r')(?:年|岁|间)?|间|初年)?|(?P<bare>'+GANZHI+r')(?:之年|年|岁|间)|(?P<period>明季|明末)')


def chinese_number(text):
    if text.isdigit(): return int(text)
    digits = dict(zip('零〇一二三四五六七八九两', [0,0,1,2,3,4,5,6,7,8,9,2]))
    if text == '元': return 1
    total, value = 0, 0
    for char in text:
        if char in digits: value = digits[char]
        elif char in '十百': total += (value or 1) * {'十':10,'百':100}[char]; value = 0
        else: raise ValueError(text)
    return total + value


def resolve_date(match):
    era = match['era']
    if era:
        first, last = ERAS[era]
        if match['n']:
            n = chinese_number(match['n']); n2 = chinese_number(match['n2']) if match['n2'] else n
            # 二十六、七 means years 26 and 27, not years 26 and 7.
            if n2 < n and match['n2'] and len(match['n2']) == 1: n2 += n // 10 * 10
            a, b = first+n-1, first+n2-1
            if not first <= a <= b <= last: return None, None, '纪年超出年号范围，待核'
            return a, b, '年号纪年换算' if a == b else '年号纪年范围换算'
        if match['gz']:
            gz = match['gz']; stems='甲乙丙丁戊己庚辛壬癸'; branches='子丑寅卯辰巳午未申酉戌亥'
            years=[y for y in range(first,last+1) if stems[(y-4)%10]+branches[(y-4)%12] == gz]
            if len(years)==1: return years[0],years[0],'年号约束下的干支换算'
            return None,None,'干支与年号不符或有多解，待核'
        return first,last,'年号期间；“初年”不自动缩为某一年'
    return None,None,'缺少年号约束的干支／时代线索，未换算'


# Read against the full local chapters. IDs are unit-based; excerpts are
# asserted when building so an edition change cannot silently reuse the audit.
AUDIT = {
    3068: ('康熙七年', ['稷下'], '叙述者在场', '下句“余适客稷下”；不是震中定位。'),
    8035: ('康熙四年', ['永年'], '事件地点', '永年举人；地方报广平、行永年查审。广平为行政报审地。'),
    8298: ('康熙二十六年', ['邑西村'], '事件地点', '事件明示在邑西村民圃中；“邑”具体指向待考。'),
    9211: ('康熙二十一年', ['山东'], '事件区域', '山东旱灾；不可与本篇平阳地震合并。'),
    9080: ('宣德间', ['华阴'], '故事时代与主要地点', '开篇宫中征促织，后文由华阴令摊派；主要地方故事发生于华阴。'),
    22313: ('万历间', ['历城'], '事件地点', '历城令梦城隍索役；庙东只是篇内方位。'),
    9224: ('康熙二十四年', ['平阳'], '事件区域', '本段另述平阳地震及水灾。'),
    11196: ('康熙二十一年', ['绰然堂'], '讲述日期', '毕子向作者细述异事的日期；狐事的发生年份未定。'),
    22916: ('康熙二十六、七年', ['养母峪'], '事件地点', '石崖崩露洞口；与开篇查牙山探洞分别记录。'),
    28209: ('甲寅岁', ['衮郡'], '事件区域', '三藩作反为历史约束，人工据此定位1674；原文“衮”保留待地理核对。'),
}


def build_chronology(chapters):
    rows=[]
    for chapter in chapters:
        for unit in chapter['source_units']:
            source=unit['text']
            for m in DATE.finditer(source):
                a,b,method=resolve_date(m)
                places=[p['word'] for p in chapter['places'] if p['word'] in source]
                relation='同句地名提及，地点角色待核' if places else '篇内地名关联，事件地点待核'
                if not places: places=list(dict.fromkeys(p['word'] for p in chapter['places']))
                note=''; role='时间提及，事件／人物经历待核'
                if unit['unit'] in AUDIT:
                    expected,places,role,note=AUDIT[unit['unit']]
                    if expected not in source: raise ValueError('年代审查与底本不符')
                    relation='已回看原文的地点关系'
                    if unit['unit']==28209: a=b=1674; method='三藩事件约束下的人工干支判读'
                if not places: places=['地点待核']
                rows.append({'id':f"u{unit['unit']}-{m.start()}", 'chapter_id':chapter['chapter_id'],
                    'chapter':chapter['chapter'],'unit':unit['unit'],'expression':m.group(),
                    'start':m.start(),'end':m.end(),'year_start':a,'year_end':b,
                    'date_label': str(a) if a is not None and a==b else f'{a}—{b}' if a is not None else '年份未定',
                    'method':method,'places':places,'place_relation':relation,'time_role':role,
                    'review_note':note,'excerpt':source,
                    'review_status':'已回看原文' if unit['unit'] in AUDIT else '待人工核对'})
    rows.sort(key=lambda r:(r['year_start'] is None,r['year_start'] or 0,r['chapter_id'],r['unit']))
    return {'records':rows,'sources':[{'title':'中国历代年号索引表','url':SOURCE_URL}],
            'note':'按公元年排序；原文月日仍为旧历。未定干支和明季／明末不强制换算。篇内地点关联需核对事发地、籍贯及讲述地。'}


def render_report(data):
    lines=['# 《聊斋志异》地点年表','',data['note'],'',
           '| 年代 | 原文纪年 | 篇目 | 地点 | 时间与地点关系 | 原文依据 |',
           '|---|---|---|---|---|---|']
    for r in data['records']:
        ai=r.get('ai_review',{})
        ai_note=('；AI审核：'+ai.get('label','')+'，'+ai.get('reason','')) if ai else ''
        values=[r['date_label'],r['expression'],r['chapter'],'、'.join(r['places']),
                r['time_role']+'；'+r['place_relation']+'；'+r['review_note']+ai_note,r['excerpt']]
        lines.append('| '+' | '.join(v.replace('|','／').replace('\n',' ') for v in values)+' |')
    lines.extend(['','纪年对照来源：[中国历代年号索引表]('+SOURCE_URL+')。'])
    return '\n'.join(lines)+'\n'
