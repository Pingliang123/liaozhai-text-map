"""Source-reviewed exclusions from geographic proper names, not token deletion."""
import re
import json
from pathlib import Path

POLICY = json.loads((Path(__file__).parent/'direction_place_review.json').read_text(encoding='utf-8'))

REASONS = {
    '北山': '《农人》“在北山时”为未具名山地场景，按用户校读归为空间词，不作地理专名。',
    '北闱': '《金和尚》“赴北闱，领乡荐”为赴试表述，不作独立地名。',
}
DISTANCE = r'^[东西南北](?:去|行|距|走|往)?[一二三四五六七八九十百千万两数几\d]+(?:余|餘|多)?里(?:许|許)?$'


def rejection_reason(word):
    return (POLICY['exclude'].get(word) or
            ('相对方位／篇内空间，改列空间词：' + POLICY['spaces'][word] if word in POLICY['spaces'] else '') or
            ('误切片语，修正为：' + POLICY['replacements'][word] if word in POLICY['replacements'] else '') or
            REASONS.get(word) or ('方位与距离片语，描述位置关系，不是地理专名。' if re.fullmatch(DISTANCE, word) else ''))


def chapter_reason(chapter, word):
    return POLICY['chapter_exclusions'].get(chapter, {}).get(word) or rejection_reason(word)


def reviewed_places(chapter, places, source):
    result = {}
    for p in places:
        word = p['word']
        target = POLICY['replacements'].get(word)
        if target and target in source:
            result.setdefault(target, dict(p, word=target))
        elif not chapter_reason(chapter, word):
            result.setdefault(word, p)
    return list(result.values())
