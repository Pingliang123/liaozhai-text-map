"""Build the authored, reproducible notebook for the ghost-map workflow."""
import json
import sys
from pathlib import Path

ROOT=Path(__file__).parent
OUT=ROOT/'ghost_map'

def cell(kind, source, i):
    c={'cell_type':kind,'id':f'ghost-map-{i:02d}','metadata':{},'source':source.splitlines(keepends=True)}
    if kind=='code': c.update({'execution_count':None,'outputs':[]})
    return c

def main():
    cells=[
        cell('markdown','# 《聊齋志異》全書鬼怪地圖：從分詞、清洗到地點事件序列\n\n參考附件流程，先重用全書分詞快取，再清洗與停用詞、生成詞雲，最後分開保存人物／年份／地點的模型候選與異事地點熱點。附件未被執行。',0),
        cell('code',"from pathlib import Path\nimport json, sys, hashlib\nrepo=Path.cwd().resolve()\nfor p in [repo,*repo.parents]:\n    if (p/'outputs'/'analyze_ghost_map.py').exists(): repo=p; break\nsys.path.insert(0,str(repo/'outputs'))\nfrom liaozhai_nlp import jsonl_read\nfrom analyze_ghost_map import cleaned_frequency, STOPWORDS\ndata=repo/'outputs'/'ghost_map'\nunits=jsonl_read(repo/'outputs'/'nlp'/'segmented_units.jsonl.gz')\nmanifest=json.loads((data/'manifest.json').read_text(encoding='utf-8'))\nmanifest",1),
        cell('markdown','## 1. 清洗與詞雲\n\n停用詞只影響詞雲及清洗後詞頻，不刪除分詞快取。停用詞表包含附件示例中的高頻功能詞，並補上繁簡兩套形式。',2),
        cell('code',"freq=cleaned_frequency(units)\n{'stopwords':len(STOPWORDS),'cleaned_tokens':sum(freq.values()),'word_types':len(freq),'top20':freq.most_common(20)}",3),
        cell('markdown','![清洗後詞雲](全書詞雲.png)\n\n圖形用本地中文字體與 matplotlib 排版；沒有假裝第三方 WordCloud 的隨機布局具有文學意義。',4),
        cell('markdown','## 2. 全量候選\n\n人物與地點表保留模型／詞性／後綴候選，因古文 NER 會把「俄」「日」「公子」等誤當地點。年份用正則找出，仍需區分紀年、相對時間、節日與敘事套語。',5),
        cell('code',"read=lambda n:json.loads((data/n).read_text(encoding='utf-8'))\npeople=read('人物詞表_全量模型候選.json')\nhigh_people=read('人物詞表_高置信表層候選.json')\nplaces=read('地點詞表_全量模型候選.json')\nyears=read('年份詞表.json')\n{'people_types':people['count'],'high_surface_people':high_people['count'],'place_types':places['count'],'time_mentions':years['mentions'],'year_only_mentions':years['year_only_mentions']}",6),
        cell('code',"[(r['word'],r['mentions'],r['chapters'],r['methods']) for r in places['candidates'][:30]]",7),
        cell('markdown','## 3. 以篇目為單位的人物、地點與異事\n\n篇目才是主要分析單位：先列出每篇所有人物／地點候選、年份和異事觸發詞，再比較篇目與篇目之間的同一地點。分句只作原文回查。',8),
        cell('code',"chapter_data=read('篇目人物地點年份分析.json')\n[(r['chapter'],r['people'][:8],r['places'][:8],r['years'],r['event_types']) for r in chapter_data['chapters'][:10]]",9),
        cell('markdown','## 4. 異事地點熱點\n\n熱點定義為：地點候選出現在一篇，而該篇任何分句出現異事觸發詞；同一篇內的人物、年份、異事類型都附在地點事件上。這是篇目級文本關聯，不是同句因果或地理座標。',10),
        cell('code',"hotspots=read('異事地點熱點.json')\n[(r['place'],r['event_mentions'],r['event_chapters'],r['event_types']) for r in hotspots['named_hotspots'][:25]]",11),
        cell('code',"[(r['place'],r['event_mentions'],r['event_chapters']) for r in hotspots['generic_spatial_hotspots']]",12),
        cell('markdown','## 5. 同一地點的事件順序與鬼怪地圖\n\n順序採原書篇章次序，再採篇內分句 ID；只有在文本明示年份時才另作年代線索。每條邊保留該篇人物、年份、異事類型和原文證據，不把它當作人物的自動旅行路線。',13),
        cell('code',"edges=read('鬼怪地圖事件序列.json')['edges']\nedges[:30]",14),
        cell('markdown','## 6. 研究限制\n\n人物、地點仍是候選，代詞共指、同名、異名與物種身分未完成全書人工標註；同一地點詞也可能是泛稱。後續應建立正例／漏例評估集，將地點、事件、人物角色、年份與「實地／夢境／比喻」分層標註。',15),
    ]
    for c in cells:
        if c['cell_type']=='code':
            c['source']=[line.replace("/'nlp'/", "/'nlp_dictionary'/") for line in c['source']]
    cells[1]['source'].append("\nassert hashlib.sha256((repo/'outputs'/'nlp_dictionary'/'segmented_units.jsonl.gz').read_bytes()).hexdigest() == manifest['segmentation_cache_sha256']\n")
    nb={'cells':cells,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':sys.version.split()[0]}},'nbformat':4,'nbformat_minor':5}
    (OUT/'全書鬼怪地圖分析.ipynb').write_text(json.dumps(nb,ensure_ascii=False,indent=2),encoding='utf-8')

if __name__=='__main__': main()
