"""Compare dictionary segmentation with the preserved baseline, without accuracy claims."""
import json
from collections import Counter
from pathlib import Path
from liaozhai_nlp import jsonl_read, json_write

ROOT=Path(__file__).parent

def main():
    old=jsonl_read(ROOT/'nlp'/'segmented_units.jsonl.gz')
    new=jsonl_read(ROOT/'nlp_dictionary'/'segmented_units.jsonl.gz')
    dictionary=set((ROOT/'nlp_dictionary'/'user_dictionary_t2s.txt').read_text(encoding='utf-8').splitlines())
    examples=[]; changed=0; merged=Counter()
    for a,b in zip(old,new):
        if (a['unit'],a['original'],a['text'])!=(b['unit'],b['original'],b['text']):
            raise ValueError('Passage mismatch')
        old_spans={(t['start'],t['end']) for t in a['tokens']}
        if [(t['word'],t['start'],t['end']) for t in a['tokens']] != [(t['word'],t['start'],t['end']) for t in b['tokens']]:
            changed+=1
        for t in b['tokens']:
            if t['word'] in dictionary and (t['start'],t['end']) not in old_spans:
                parts=[x['word'] for x in a['tokens'] if x['end']>t['start'] and x['start']<t['end']]
                if len(parts)>1 and len(t['word'])>1:
                    merged[t['word']]+=1
                    if len(examples)<80:
                        examples.append({'chapter':b['chapter'],'unit':b['unit'],'original':b['original'],
                                         'before':parts,'after':t['word'],'start':t['start'],'end':t['end']})
    manifest=json.loads((ROOT/'nlp_dictionary'/'manifest.json').read_text(encoding='utf-8'))
    json_write(ROOT/'nlp_dictionary'/'分詞字典變更核對.json',{
        'dictionary':manifest['user_dictionary'],'clauses':len(new),'changed_clauses':changed,
        'baseline_tokens':sum(len(u['tokens']) for u in old),
        'dictionary_tokens':sum(len(u['tokens']) for u in new),
        'merged_dictionary_occurrences':sum(merged.values()),'merged_word_types':len(merged),
        'most_common_merges':merged.most_common(40),'examples':examples,
        'interpretation':'Boundary changes are not an accuracy score; dictionary entries require context review.'})
    print(json.dumps({'changed_clauses':changed,'merged_occurrences':sum(merged.values()),
                      'top_merges':merged.most_common(15)},ensure_ascii=False))

if __name__=='__main__': main()
