(async function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const researchPages = ['research-hub', 'book-synthesis', 'chronology-panel', 'candidate-review', 'research-library'];
  const editorPages = [['place-panel', '地点与分类'], ['people-panel', '人物'], ['space-panel', '空间词'], ['time-panel', '时间词'], ['realm-review', '三界关系'], ['narrative-panel', '情节路径'], ['segmentation-panel', '分词']];
  let currentEditor = 'place-panel';
  let currentResearch = 'research-hub';
  function showEditor(id) {
    currentEditor = id;
    for (const [target, label] of editorPages) {
      $(target).hidden = target !== id; $(target).open = target === id;
      $('editor-tabs').querySelector('[data-editor="' + target + '"]').setAttribute('aria-pressed', String(target === id));
      if (target === id) $('editor-heading').textContent = label;
    }
  }
  function showScreen(screen, research = currentResearch) {
    for (const id of ['map-section', 'workspace', 'research-screen', 'reports-screen']) $(id).hidden = id !== screen;
    for (const [id, target] of [['nav-map', 'map-section'], ['nav-text', 'workspace'], ['nav-research', 'research-screen'],['nav-reports','reports-screen']]) {
      $(id).setAttribute('aria-current', target === screen ? 'page' : 'false');
    }
    if (screen === 'research-screen') {
      currentResearch = research;
      $('nav-research').setAttribute('href', '#' + research);
      $('research-more').open = ['candidate-review','research-library'].includes(research);
      for (const id of researchPages) { $(id).hidden = id !== research; $(id).open = id === research; }
      for (const [id, target] of [['nav-path', 'research-hub'], ['nav-synthesis', 'book-synthesis'], ['nav-chronology', 'chronology-panel'], ['nav-candidates', 'candidate-review'], ['nav-documents', 'research-library']]) {
        $(id).setAttribute('aria-current', target === research ? 'page' : 'false');
      }
    }
    if (screen === 'map-section') resize();
    if (screen === 'reports-screen') renderReports();
  }
  function reveal(id, record = true) {
    const target = $(id);
    if (!target) return;
    let screen = id==='reports-screen' ? id : researchPages.includes(id) || id === 'research-screen' ? 'research-screen' :
      ['workspace', 'narrative-panel', 'save-chapter', 'person-editor', 'people-panel', 'realm-review', 'place-panel', 'time-panel', 'space-panel', 'segmentation-panel'].includes(id) ? 'workspace' : 'map-section';
    for (let node = target; node; node = node.parentElement) {
      if (['map-section', 'workspace', 'research-screen','reports-screen'].includes(node.id)) { screen = node.id; break; }
    }
    showScreen(screen, researchPages.includes(id) ? id : currentResearch);
    if (screen === 'workspace') {
      let editor = editorPages.find(([target]) => target === id)?.[0];
      if (id === 'person-editor') editor = 'people-panel';
      for (let node = target; node && !editor; node = node.parentElement) editor = editorPages.find(([key]) => key === node.id)?.[0];
      showEditor(editor || currentEditor);
    }
    if (record && window.location.hash !== '#' + id) window.history.pushState(null, '', '#' + id);
    for (let node = target; node; node = node.parentElement) {
      if (node.tagName === 'DETAILS') node.open = true;
    }
    target?.scrollIntoView({behavior: window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start'});
  }
  const M = GhostMapModel, G = GhostMapGeometry, N = GhostMapNarrative;
  const P = GhostMapPackage, embedded = JSON.parse($('map-data').textContent);
  let installed = null, packageError = '';
  const packageDB = typeof indexedDB === 'undefined' ? null : indexedDB;
  if (packageDB) {
    try {
      const savedPackage = await P.load(packageDB, embedded);
      if (savedPackage) installed = P.validate(savedPackage, embedded);
    } catch (error) { packageError = '本机总资料包未载入，当前使用网站基线：' + error.message; }
  }
  const base = installed ? installed.base : embedded, model = M.create(base);
  const publishedRevisions = !installed && $('published-revisions') ? JSON.parse($('published-revisions').textContent || 'null') : null;
  if (publishedRevisions) model.importDocument(publishedRevisions);
  const state = {place: null, chapter: model.ids[0], dirty: false, unpersisted: false, candidatePage: 0, transform: {k: 1, x: 0, y: 0}, width: 0, height: 0};
  const storageScope = (base.corpus_id || base.source_sha256) + (installed ? '-package-' + installed.installation_id : '');
  const storageKey = 'liaozhai-map-corrections-v3-' + storageScope;
  const locationBackupKey = 'liaozhai-map-locations-v1-' + storageScope;
  let storageSnapshot = null, storageInvalid = false, storageAncestor = null;
  function withLocationBackup(doc) {
    // Older open tabs export chapters only. Recover the independent geographic mirror.
    if(doc && !Object.hasOwn(doc,'place_locations')) {
      const backup=localStorage.getItem(locationBackupKey);
      if(backup) doc={...doc,place_locations:JSON.parse(backup)};
    }
    return doc;
  }
  let projection, rings = [], regionRings = G.geoJSONRings(embedded.modern_boundaries || {}), backgroundReady = false, regionBoundaryReady = regionRings.length > 0, regionBoundaryRemote = false, drag = null, suppressClick = false;
  const pointNodes = new Map();
  const allPlaces = () => model.places();
  let locationWord = '', locationDirty = false, pickingLocation = false, projectionPlaces = '';
  const svgNS = 'http://www.w3.org/2000/svg';
  function element(tag, attributes = {}, content) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attributes)) {
      if (key === 'class') node.className = value;
      else if (key === 'value') node.value = value;
      else node.setAttribute(key, value);
    }
    if (content !== undefined) node.textContent = content;
    return node;
  }
  function svg(tag, attributes = {}, content) {
    const node = document.createElementNS(svgNS, tag);
    for (const [key, value] of Object.entries(attributes)) node.setAttribute(key, value);
    if (content !== undefined) node.textContent = content;
    return node;
  }
  const button = (title, action, className = '') => {
    const b = element('button', {type: 'button', class: className}, title);
    b.addEventListener('click', action); return b;
  };
  function message(id, content, error = false) {
    $(id).textContent = content;
    $(id).classList.toggle('error', error);
  }
  function persist(proposed = model.document()) {
    if (storageInvalid) throw new Error('本机已有修订无法解析，未覆盖。请先保留备份，再检查修订文件。');
    let latest;
    try { latest = localStorage.getItem(storageKey); }
    catch (_) { model.importDocument(proposed); state.unpersisted = true; message('storage-status', '浏览器不允许本机储存：本次修订只保留于目前页面，关闭前请下载 JSON。', true); return false; }
    // Merge separate chapters, refuse concurrent edits to the same chapter.
    // Do this before mutating the current model, so conflicts keep the editor.
    let merged = proposed;
    if (latest !== storageSnapshot) {
      try { merged = M.mergeDocuments(base, storageAncestor, proposed, latest ? withLocationBackup(JSON.parse(latest)) : null); }
      catch (error) { message('storage-status', error.message, true); throw error; }
    }
    try {
      const encoded = JSON.stringify(merged); localStorage.setItem(storageKey, encoded);
      storageSnapshot = encoded; model.importDocument(merged); storageAncestor=model.document();
      localStorage.setItem(locationBackupKey, JSON.stringify(merged.place_locations || []));
      state.unpersisted = false;
      message('storage-status', '修订已保存于此浏览器本机。仍建议下载 JSON 备份；不会覆写附件。');
      return true;
    } catch (_) {
      model.importDocument(merged);
      state.unpersisted = true;
      message('storage-status', '浏览器不允许本机储存：本次修订只保留于目前页面，关闭前请下载 JSON。', true);
      return false;
    }
  }
  try {
    let saved = localStorage.getItem(storageKey), migrated = false;
    storageSnapshot = saved;
    if (!saved && installed) {
      model.importDocument(installed.revisions); storageAncestor = model.document();
      persist(); saved = storageSnapshot;
    }
    if (!saved && !installed) for (const sha of [base.source_sha256, ...(base.compatible_source_sha256 || [])]) {
      saved = localStorage.getItem('liaozhai-map-corrections-v2-' + sha);
      if (saved) { migrated = true; break; }
    }
    if (saved) { model.importDocument(withLocationBackup(JSON.parse(saved))); storageAncestor=model.document();
      if (!migrated || persist()) message('storage-status', migrated ? '已迁移旧版修订为简体；旧备份未删除。用户修订优先，请核对《丁前溪》的旧分类或还原该篇基线。' : '已恢复本机修订；可下载 JSON 备份。'); }
    else if (!installed) message('storage-status', publishedRevisions ? '已载入发布版本的人工修订；后续修改保存于当前浏览器，请下载备份。' : '尚无本机修订。保存后同步更新地图；请下载 JSON 备份。');
  } catch (error) { storageInvalid = !!storageSnapshot; message('storage-status', '本机修订未载入：' + error.message + '。原始资料仍可使用；不会覆盖无法解析的修订。', true); }
  $('version').textContent = '版本 ' + base.app_version;
  message('package-status', packageError || (installed ? '已恢复总资料包（' + base.app_version + '）；后续修改请再次合并下载。' : '总资料包包含全文、分词、分析、定位与已保存修订，可在同一底本的网站恢复。'), !!packageError);
  const routeViewKey='liaozhai-route-view-'+storageScope;
  let restoredRouteActor='';
  $('movement-scope').value='auto';
  try {
    const saved=typeof sessionStorage==='undefined'?null:JSON.parse(sessionStorage.getItem(routeViewKey)||'null');
    if(saved){
      if(model.ids.includes(saved.chapter)) state.chapter=saved.chapter;
      if(allPlaces().some(p=>p.id===saved.place)) state.place=saved.place;
      if(['auto','chapter','place','off'].includes(saved.scope)) $('movement-scope').value=saved.scope;
      if(typeof saved.actor==='string') restoredRouteActor=saved.actor;
    }
  }catch(_){}
  function movementMode(){const scope=$('movement-scope').value||'auto';return scope==='auto'?(state.place?'place':'chapter'):scope;}
  function routeAggregatePlaces(){return $('movement-place-scope')?.value === 'aggregate';}

  function checkboxes(container, values, checked) {
    container.replaceChildren();
    for (const value of values) {
      const label = element('label'), input = element('input', {type: 'checkbox', value});
      input.checked = checked.includes(value); label.append(input, document.createTextNode(value)); container.append(label);
    }
  }
  const checked = container => [...container.querySelectorAll('input:checked')].map(n => n.value);
  function chips(container, types) {
    for (const type of types) container.append(element('span', {class: 'chip', 'data-type': type}, type));
  }
  function segmented(chapter) {
    return chapter.source_units.map(unit => {
      const source = unit.text || unit.original;
      const pieces = []; let cursor = 0;
      for (const t of unit.tokens) {
        const start = Array.isArray(t) ? t[0] : t.start;
        const end = Array.isArray(t) ? t[1] : t.end;
        if (start > cursor) pieces.push(source.slice(cursor, start));
        pieces.push(source.slice(start, end)); cursor = end;
      }
      if (cursor < source.length) pieces.push(source.slice(cursor));
      return pieces.join(' / ');
    }).join('\n');
  }
  function askToDiscard() {
    return !state.dirty || window.confirm('本篇有未保存修改。要放弃这些修改吗？');
  }
  function markDirty() {
    state.dirty = true; syncSaveStatus();
    message('edit-status', '有未保存修改；请保存本篇（Ctrl / ⌘ + S）。');
  }
  function syncSaveStatus() {
    const label = '《' + model.view(state.chapter).chapter + '》';
    message('global-edit-status', reportDraft ? '报表有未保存修改' : label + (state.dirty ? ' · 未保存' : state.unpersisted ? ' · 未写入本机，请备份' : model.hasEdit(state.chapter) ? ' · 已保存修订' : ' · 无未保存修改'), state.unpersisted);
    $('quick-save').hidden = !state.dirty && !state.unpersisted && !reportDraft;
    $('quick-save').textContent=reportDraft?'保存报表行':'保存本篇';
    $('cancel-edit').hidden = !state.dirty;
  }
  $('workspace').addEventListener('input', event => {
    if (!['chapter-search', 'chapter-select'].includes(event.target.id)) markDirty();
  });
  $('workspace').addEventListener('change', event => {
    if (!['chapter-search','chapter-select','original-text','traditional-text'].includes(event.target.id)) markDirty();
  });
  window.addEventListener('storage', event => {
    if (event.key !== storageKey || event.newValue === storageSnapshot) return;
    message('storage-status', '其他页面已更新修订。不同篇目保存时自动合并；同篇冲突不会覆盖，请保留草稿。', true);
  });
  window.addEventListener('beforeunload', event => {
    if (state.dirty || state.unpersisted) { event.preventDefault(); event.returnValue = ''; }
  });
  function matchingChapters() {
    const query = model.simplify($('chapter-search').value.trim());
    return model.ids.filter(id => model.view(id).chapter.includes(query) || (model.view(id).search_title || '').includes(query));
  }
  function adjacentChapter(step) {
    const ids = matchingChapters(), index = ids.indexOf(state.chapter);
    return index < 0 ? (step > 0 ? ids[0] : undefined) : ids[index + step];
  }
  function populateChapters() {
    const query = model.simplify($('chapter-search').value.trim());
    const matches = matchingChapters();
    message('chapter-search-status', query ? '找到 ' + matches.length + ' 篇；上下篇仅在搜索结果中切换。' + (!matches.includes(state.chapter) ? '当前篇不在结果内，仍保留；按下一篇进入结果。' : '') : '按底本顺序浏览；可搜索繁体或简体篇名。');
    $('chapter-prev').disabled = adjacentChapter(-1) === undefined;
    $('chapter-next').disabled = adjacentChapter(1) === undefined;
    $('clear-chapter-search').hidden = !query;
    if (!matches.includes(state.chapter)) matches.unshift(state.chapter);
    $('chapter-select').replaceChildren(...matches.map(id => element('option', {value: id},
      '#' + (id + 1) + ' ' + model.view(id).chapter + (model.hasEdit(id) ? ' · 已修订' : ''))));
    $('chapter-select').value = String(state.chapter);
  }
  function personRow(person) {
    const tr = element('tr'), nameCell = element('td'), canonicalCell = element('td'), aliasCell = element('td'), typeCell = element('td'), reviewCell = element('td'), actions = element('td');
    nameCell.append(element('input', {type: 'text', value: person.word, 'aria-label': '人物表层词', 'data-field': 'word'}));
    canonicalCell.append(element('input', {type: 'text', value: person.canonical || '', 'aria-label': '所指人物', 'data-field': 'canonical'}));
    aliasCell.append(element('input', {type: 'text', value: (person.aliases || []).join('、'), 'aria-label': '人物别称', 'data-field': 'aliases'}));
    const types = element('div', {class: 'checkboxes'}); checkboxes(types, M.PEOPLE, Object.keys(person.person_types || {})); typeCell.append(types);
    const select = element('select', {'aria-label': '人物审核状态', 'data-field': 'review_status'});
    select.append(element('option', {value: 'candidate'}, '待核候选'), element('option', {value: 'reviewed'}, '已核对（见依据）'));
    select.value = person.review_status || 'candidate'; reviewCell.append(select);
    const hints = (person.identity_links || []).map(x => x.surface).join('、');
    if (hints) canonicalCell.append(element('p', {class: 'row-note'}, '本篇词形线索（未确认共指）：' + hints));
    if (person.role) canonicalCell.append(element('p', {class: 'row-note'}, person.role));
    if (person.ontology_status) canonicalCell.append(element('p', {class: 'row-note'}, '类型判定：' + (person.ontology_status === 'reviewed' ? '已核对' : '待核候选') + '。' + (person.ontology_evidence || '')));
    canonicalCell.append(element('input', {type: 'text', value: person.evidence || '', 'aria-label': '人物判定依据', 'data-field': 'evidence', placeholder: '原文引文与身份判断依据'}));
    tr.dataset.role = person.role || ''; tr.dataset.ontologyEvidence = person.ontology_evidence || '';
    [nameCell, canonicalCell, aliasCell, typeCell, reviewCell, actions].forEach((cell, i) => cell.setAttribute('data-label', ['人物称呼', '指向谁／原文依据', '其他称呼', '人、鬼、妖、神（可多选）', '是否已核对', ''][i]));
    actions.append(button('移除', () => { tr.remove(); markDirty(); }, 'danger'));
    tr.append(nameCell, canonicalCell, aliasCell, typeCell, reviewCell, actions); return tr;
  }
  function evidenceRow(e, review) {
    const box = element('div', {class: 'evidence-card', 'data-evidence': e.id});
    box.append(element('strong', {}, e.realm + ' · ' + e.space + ' · 原文单位 ' + e.unit), element('blockquote', {}, e.excerpt));
    const select = element('select', {'aria-label': e.space + '的空间关联', 'data-field': 'kind'});
    select.append(element('option', {value: 'mention'}, '待核／仅提到此空间'), element('option', {value: 'crossing'}, '有跨界：人物进入或离开此空间'), element('option', {value: 'reject'}, '排除：不属于此界空间'));
    select.value = review?.kind || 'mention';
    const note = element('input', {type: 'text', value: review?.note || '', placeholder: '确认跨界时：人物、出发地、方向及原文依据', 'aria-label': '空间审核依据', 'data-field': 'note'});
    const origin = element('input', {type: 'text', value: review?.origin_place || '', placeholder: '跨界出发地（须与本篇地点词一致）', 'aria-label': '跨界出发地', 'data-field': 'origin_place'});
    const originLabel = element('label', {}, '从哪个人间地点出发？'); originLabel.append(origin);
    const noteLabel = element('label', {}, '判断依据（人物、方向和原文）'); noteLabel.append(note);
    const showOrigin = () => { originLabel.hidden = select.value !== 'crossing'; };
    showOrigin(); select.addEventListener('change', showOrigin);
    note.style.width = '100%'; origin.style.width = '100%'; box.append(select, originLabel, noteLabel); return box;
  }
  function renderChapter() {
    const c = model.view(state.chapter), changes = model.editable(state.chapter);
    populateChapters(); state.dirty = false; syncSaveStatus();
    message('research-preview-status', '');
    $('chapter-status').textContent = model.hasEdit(state.chapter) ? '人工修订（逐项状态见下）' : (c.annotation_status || '模型／规则候选，待核对');
    const summary = $('chapter-summary'); summary.replaceChildren();
    summary.append(element('h3', {}, c.chapter + ' · 文本序号 #' + (c.chapter_id + 1)), element('p', {class: 'muted'},
      c.source_units.length + ' 个原文单位 · ' + c.token_count + ' 个分词 · 人物称呼 ' + c.people.length + ' 项（可能含别称）'));
    renderResearch(c);
    checkboxes($('event-editor'), M.EVENTS, Object.keys(changes.event_types));
    checkboxes($('realm-editor'), M.REALMS, changes.realms_present);
    $('place-editor').value = changes.places.map(p => p.word).join('\n');
    $('review-note').value = changes.review_note;
    $('time-editor').value = Object.keys(changes.years).join('\n');
    $('space-editor').value = changes.space_words.join('\n');
    $('narrative-editor').replaceChildren(...changes.narrative_events.map((row, index) => narrativeRow(N.movement(row), index)));
    if (!changes.narrative_events.length) $('narrative-editor').append(element('p', {class: 'muted'}, '此篇暂无情节标注，不表示没有空间变化。可按原文新增步骤。'));
    const spaceEvidence = $('space-evidence'); spaceEvidence.replaceChildren();
    for (const word of changes.space_words) {
      const card = element('details', {class: 'evidence-card'});
      const hits = (c.space_evidence || []).filter(e => e.word === word);
      card.append(element('summary', {}, word + ' · ' + (hits[0]?.category || '人工补充／类别待核')));
      const units = c.source_units.filter(u => (u.text || u.original).includes(word));
      card.append(element('p', {class: 'muted'}, '以下列出含此词的原文单位；每处是否为空间用法仍需核对，不作为自动确认次数。'));
      for (const unit of units) card.append(element('p', {class: 'muted'}, '原文单位 ' + unit.unit), element('blockquote', {}, unit.text || unit.original));
      spaceEvidence.append(card);
    }
    if (!changes.space_words.length) spaceEvidence.append(element('p', {}, '未检出或未保留候选；不代表本篇没有空间描写，可依据原文补充。'));
    $('people-editor').replaceChildren(...c.people.map(personRow));
    $('evidence-editor').replaceChildren(...c.realm_evidence.map(e => evidenceRow(e, changes.evidence_review[e.id])));
    if (!c.realm_evidence.length) $('evidence-editor').append(element('p', {class: 'muted'}, '未找到指定三界地名的明确词形；不捏造具名目的地。可在三界与修订理由中记录叙事判读。'));
    $('original-text').value = c.source_units.map(u => u.text || u.original).join('');
    $('traditional-text').value = c.source_units.map(u => u.original).join('');
    $('segmentation-editor').value = changes.segmentation_note || segmented(c);
    message('edit-status', model.hasEdit(state.chapter) ? '已载入本篇修订。' : '原始候选已载入，尚未人工确认。');
    if (projection) { renderMovement(); paintMap(); }
  }
  function chooseChapter(id, scroll = false) {
    if (id !== state.chapter && !askToDiscard()) return false;
    if (id !== state.chapter) { state.chapter = id; renderChapter(); }
    if (scroll) reveal('workspace');
    renderPlace(); return true;
  }
  function narrativeRow(row, index) {
    const card = element('article', {class: 'evidence-card', 'data-narrative': 'true'});
    const edit = element('details'); edit.open = index === undefined;
    const heading = element('summary', {}, (index === undefined ? '新步骤' : '步骤 ' + (index + 1)) + ' · ' + (row.space || '待填写空间') + ' · ' + (row.event || '待填写事件'));
    edit.append(heading);
    const basic = element('div', {class:'narrative-fields'}), extra = element('details', {class:'narrative-fields'});
    extra.append(element('summary', {}, '补充信息 · 地点、身份、时间与解读'));
    const fields = {actors:'人物（多人用顿号分隔）', location:'地点与角色（事发地／籍贯／不明）', space:'场景或空间变化', from_space:'出发空间（移动时必填）', to_space:'到达空间（移动时必填）', temporal_order:'事件时间顺序（可填回述、同时、先后待核）', event:'原文事件', identity:'人物身份阶段', interpretation:'研究解读（与事实分开）', quote:'原文引文（须与单位一致）'};
    for (const [field, title] of Object.entries(fields)) {
      const label = element('label', {}, title), input = element(['event','quote','interpretation'].includes(field) ? 'textarea' : 'input', {type:'text', 'data-field': field, 'aria-label': title});
      input.value = row[field] || ''; label.append(input);
      (['location','identity','temporal_order','interpretation'].includes(field) ? extra : basic).append(label);
      if (field === 'from_space' || field === 'to_space') label.setAttribute('data-route-field', 'true');
    }
    const unitLabel = element('label', {}, '引文所在原文单位'), select = element('select', {'data-field':'unit', 'aria-label':'引文所在原文单位'});
    const kindLabel = element('label', {}, '此步的空间关系'), kind = element('select', {'data-field':'transition_kind', 'aria-label':'空间关系类型'});
    for (const [value, label] of [['mention','场景记录／待核'],['movement','人物移动（有原文依据）'],['plot','情节转换（可无人物移动）']]) kind.append(element('option', {value}, label));
    kind.value = row.transition_kind || 'mention'; kindLabel.append(kind); basic.insertBefore(kindLabel, basic.children[0]);
    const showRoute = () => { for (const label of basic.querySelectorAll('[data-route-field]')) label.hidden = kind.value === 'mention'; };
    showRoute(); kind.addEventListener('change', showRoute);
    select.append(...model.view(state.chapter).source_units.map(u => element('option', {value:String(u.unit)}, String(u.unit) + ' · ' + (u.text || u.original).slice(0, 35))));
    select.value = String(row.unit ?? model.view(state.chapter).source_units[0].unit); unitLabel.append(select); basic.append(unitLabel);
    const endLabel = element('label', {}, '引文末单位（跨段引文）'), endSelect = element('select', {'data-field':'unit_end', 'aria-label':'引文末单位'});
    endSelect.append(element('option', {value:''}, '同起始单位'), ...model.view(state.chapter).source_units.map(u => element('option', {value:String(u.unit)}, String(u.unit) + ' · ' + (u.text || u.original).slice(0,35))));
    endSelect.value = row.unit_end === undefined ? '' : String(row.unit_end); endLabel.append(endSelect); extra.append(endLabel);
    for(const [field,label,values] of [
      ['from_place_id','出发空间对应地图地点',allPlaces().map(p=>[p.id,p.name])],
      ['to_place_id','到达空间对应地图地点',allPlaces().map(p=>[p.id,p.name])],
      ['space_access','本步空间使用方式',['私人','公共','混合','开放自然','待核'].map(v=>[v,v])],
      ['space_realm','本步空间所属世界',['人间','异境','待核'].map(v=>[v,v])],
      ['from_access','出发端使用方式（人工覆盖）',['私人','公共','混合','开放自然','待核'].map(v=>[v,v])],
      ['from_realm','出发端所属世界（人工覆盖）',['人间','异境','待核'].map(v=>[v,v])],
      ...['from_type','to_type'].map(field=>[field,(field==='from_type'?'出发':'到达')+'端统一场所类型（人工覆盖）',['家宅','卧室内室','书斋','庭院园林','道路街市','官署考场','寺观','旅店','自然山野','水域','异境场所','城郭聚落','其他','待核'].map(v=>[v,v])])]) {
      const holder=element('label',{},label),select=element('select',{'data-field':field,'aria-label':label});
      select.append(element('option',{value:''},'自动线索／未绑定'),...values.map(([value,title])=>element('option',{value},title)));
      if(row[field] && !values.some(([value])=>value===row[field])) select.append(element('option',{value:row[field]},row[field]+'（地点待定位）'));
      select.value=row[field] || '';holder.append(select);extra.append(holder);
    }
    const meaning=element('label',{},'空间对人物与情节的作用（人工解读）');
    meaning.append(element('textarea',{'data-field':'space_function',value:row.space_function || ''}));extra.append(meaning);
    const boundary=element('label',{},'空间边界／媒介（墙、门、画、梦、洞、桥等）');
    boundary.append(element('input',{'data-field':'boundary_medium',value:row.boundary_medium || ''}));extra.append(boundary);
    const role=element('label',{},'空间叙事功能');
    const roleSelect=element('select',{'data-field':'narrative_role','aria-label':'空间叙事功能'});
    roleSelect.append(...[['','待核'],['隔离','隔离／阻断'],['通行','通行／连接'],['转换','越界／转换'],['显影','显影／揭示'],['审判','审判／秩序'],['庇护','庇护／藏匿'],['诱导','诱导／召唤'],['混合','多重功能']].map(([value,label])=>element('option',{value},label)));
    roleSelect.value=row.narrative_role || '';role.append(roleSelect);extra.append(role);
    edit.append(basic, extra);
    edit.append(button('上移', () => { const parent = card.parentNode, index = [...parent.children].indexOf(card); if (index > 0) { parent.insertBefore(card, parent.children[index - 1]); markDirty(); } }),
      button('下移', () => { const parent = card.parentNode, index = [...parent.children].indexOf(card); if (index < parent.children.length - 1) { parent.insertBefore(parent.children[index + 1], card); markDirty(); } }),
      button('删除此步', () => { card.remove(); markDirty(); }, 'danger'));
    card.append(edit); return card;
  }
  $('add-narrative').addEventListener('click', () => {
    const container = $('narrative-editor');
    if (!container.querySelector('[data-narrative]')) container.replaceChildren();
    container.append(narrativeRow({})); markDirty();
  });
  $('chapter-select').addEventListener('change', () => {
    if (!chooseChapter(Number($('chapter-select').value))) $('chapter-select').value = String(state.chapter);
  });
  $('chapter-search').addEventListener('input', populateChapters);
  $('clear-chapter-search').addEventListener('click', () => { $('chapter-search').value = ''; populateChapters(); });
  for (const [id, label] of editorPages) {
    const tab = button(label, () => reveal(id)); tab.setAttribute('data-editor', id);
    $('editor-tabs').append(tab);
  }
  $('view-chapter-research').addEventListener('click', () => reveal('research-hub'));
  for (const [id, step] of [['chapter-prev', -1], ['chapter-next', 1]]) $(id).addEventListener('click', () => {
    const next = adjacentChapter(step);
    if (next !== undefined) chooseChapter(next, true);
  });
  for (const [id, target] of [['nav-map', 'map-section'], ['nav-text', 'workspace'], ['nav-research', 'research-hub'],
    ['nav-path', 'research-hub'], ['nav-synthesis', 'book-synthesis'], ['nav-chronology', 'chronology-panel'],
    ['nav-candidates', 'candidate-review'], ['nav-documents', 'research-library'],['nav-reports','reports-screen']]) $(id).addEventListener('click', event => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault(); reveal(id === 'nav-research' ? currentResearch : id==='nav-candidates' ? 'reports-screen' : target);
    });
  function routeHash() {
    const id = (window.location?.hash || '').slice(1);
    if (!id) showScreen('map-section');
    else if ($(id)) reveal(id, false);
  }
  window.addEventListener('hashchange', routeHash);
  window.addEventListener('popstate', routeHash);
  $('add-person').addEventListener('click', () => {
    $('people-editor').append(personRow({word: '', person_types: {人: 1}, review_status: 'candidate'})); markDirty();
  });
  $('original-segmentation').addEventListener('click', () => {
    $('segmentation-editor').value = segmented(model.view(state.chapter)); markDirty();
  });
  function collectChanges() {
    const people = [...$('people-editor').children].map(tr => ({
      word: tr.querySelector('[data-field="word"]').value,
      canonical: tr.querySelector('[data-field="canonical"]').value,
      aliases: tr.querySelector('[data-field="aliases"]').value.split(/[,，、]/).map(s => s.trim()).filter(Boolean),
      review_status: tr.querySelector('[data-field="review_status"]').value,
      evidence: tr.querySelector('[data-field="evidence"]').value,
      role: tr.dataset.role || '', ontology_evidence: tr.querySelector('[data-field="evidence"]').value || tr.dataset.ontologyEvidence || '',
      person_types: Object.fromEntries(checked(tr).map(t => [t, 1])),
    }));
    const evidence_review = Object.fromEntries([...$('evidence-editor').querySelectorAll('[data-evidence]')].map(box => [box.dataset.evidence, {
      kind: box.querySelector('[data-field="kind"]').value, note: box.querySelector('[data-field="note"]').value,
      origin_place: box.querySelector('[data-field="origin_place"]').value,
    }]));
    return {people, evidence_review, event_types: Object.fromEntries(checked($('event-editor')).map(t => [t, 1])),
      narrative_events: [...$('narrative-editor').querySelectorAll('[data-narrative]')].map(card => ({
        ...Object.fromEntries(['actors','location','space','event','identity','interpretation','quote','from_space','to_space','temporal_order','transition_kind','from_place_id','to_place_id','space_access','space_realm','space_function','boundary_medium','narrative_role','from_access','from_realm','from_type','to_type'].map(field => [field, card.querySelector('[data-field="' + field + '"]').value])),
        unit: Number(card.querySelector('[data-field="unit"]').value),
        ...(card.querySelector('[data-field="unit_end"]').value ? {unit_end:Number(card.querySelector('[data-field="unit_end"]').value)} : {}),
      })),
      space_words: $('space-editor').value.split(/[\n,，、]/).map(w => w.trim()).filter(Boolean),
      years: Object.fromEntries($('time-editor').value.split(/\n/).map(w => w.trim()).filter(Boolean).map(w => [w, 1])),
      realms_present: checked($('realm-editor')), places: $('place-editor').value.split(/[\n,，、]/).map(word => word.trim()).filter(Boolean).map(word => ({word})),
      review_note: $('review-note').value, segmentation_note: $('segmentation-editor').value};
  }
  function saveChapter() {
    try {
      const proposed = M.create(base); proposed.importDocument(model.document()); proposed.save(state.chapter,collectChanges());
      const durable = persist(proposed.document()); renderChapter(); updateResults();
      message('edit-status', durable ? '保存成功：地图、篇目、人物、时间词与三界关联已同步。' : '已应用到当前页面，未写入本机存储；关闭前请下载修订 JSON。', !durable);
    } catch (error) { reveal('save-chapter'); message('edit-status', '未保存：' + error.message, true); }
  }
  $('save-chapter').addEventListener('click', saveChapter);
  $('quick-save').addEventListener('click',()=>{if(reportDraft) reportActive?.querySelector('[data-report-save]')?.click();else saveChapter();});
  $('cancel-edit').addEventListener('click', () => {
    if (state.dirty && !window.confirm('放弃本篇所有未保存修改？已保存修订不会删除。')) return;
    renderChapter(); updateResults();
  });
  window.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key?.toLowerCase() === 's') {
      event.preventDefault(); if(reportDraft) reportActive?.querySelector('[data-report-save]')?.click();else if (state.dirty || state.unpersisted) saveChapter();
    }
  });
  $('reset-chapter').addEventListener('click', () => {
    if (!window.confirm('撤回本篇已保存及未保存修订，恢复原始候选？其他篇目不变。')) return;
    try { const proposed=M.create(base); proposed.importDocument(model.document()); proposed.reset(state.chapter);
      persist(proposed.document()); renderChapter(); updateResults(); }
    catch (error) { message('edit-status', error.message, true); }
  });
  function downloadDocument(doc, filename) {
    const url = URL.createObjectURL(new Blob([JSON.stringify(doc,null,2)], {type:'application/json'}));
    const a = element('a', {href:url,download:filename}); document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url),1000);
  }
  $('export-draft').addEventListener('click', () => {
    // Raw draft can be backed up even if its values fail annotation validation.
    downloadDocument({draft_version:1,corpus_id:base.corpus_id,chapter_id:state.chapter,
      chapter:model.view(state.chapter).chapter,changes:collectChanges(),place_location_draft:locationDirty?locationInput():null,
      report_draft:reportDraft?{row:reportActive?.getAttribute('data-report-editor'),fields:Object.fromEntries([...reportActive.querySelectorAll('[data-field]')].map(n=>[n.getAttribute('data-field'),n.value])),person_types:checked(reportActive)}:null},'聊斋未保存草稿.json');
    message('storage-status','当前输入已下载为草稿；草稿不是已审核修订备份，暂不支持直接导入。');
  });
  $('load-latest').addEventListener('click', () => {
    if(reportDraft){message('storage-status','请先保存或取消报表输入，再载入最新修订。',true);return;}
    if (!askToDiscard() || locationDirty && !window.confirm('放弃未保存的定位输入，载入最新修订？') || state.unpersisted && !window.confirm('本页有未写入本机的修订，请先下载备份。仍要载入其他页面的修订吗？')) return;
    try { const latest=localStorage.getItem(storageKey), proposed=M.create(base); if(latest) proposed.importDocument(withLocationBackup(JSON.parse(latest)));
      model.importDocument(proposed.document()); storageSnapshot=latest; storageInvalid=false; state.unpersisted=false;
      storageAncestor=model.document(); loadLocation(locationWord);
      renderChapter(); updateResults(); message('storage-status','已载入本机最新修订；没有删除保存的数据。'); }
    catch(error) { message('storage-status','未载入，当前输入保留：'+error.message,true); }
  });
  $('export-edits').addEventListener('click', () => {
    if (state.dirty || locationDirty || reportDraft) { message('storage-status', '有未保存的篇目、报表或定位修改，请先保存再下载，避免遗漏。', true); return; }
    const url = URL.createObjectURL(new Blob([JSON.stringify(model.document(), null, 2)], {type: 'application/json'}));
    const a = element('a', {href: url, download: '聊斋人工修订-v2.json'}); document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  $('export-package').addEventListener('click', () => {
    if (state.dirty || locationDirty || reportDraft) { message('storage-status', '有未保存的篇目、报表或定位修改，请先保存再合并下载。', true); return; }
    try {
      // Include saves from other tabs, using the existing conflict-safe merge.
      let revisions = model.document();
      let latest, readable = true;
      try {
        latest = localStorage.getItem(storageKey);
      } catch (_) { readable = false; }
      if (readable && latest !== storageSnapshot) revisions = M.mergeDocuments(base, storageAncestor, revisions, latest ? withLocationBackup(JSON.parse(latest)) : null);
      downloadDocument(P.create(base, revisions), '聊斋文本地图整合资料包.json');
      message('package-status', '已合并下载总资料包：全文、分词、AI分析、定位及已保存人工修订；请保留下载文件。');
    } catch (error) { message('package-status', '未下载：' + error.message, true); }
  });
  $('import-package').addEventListener('change', async () => {
    const file = $('import-package').files[0];
    if (!file) return;
    try {
      if (state.dirty || locationDirty || state.unpersisted || reportDraft) throw new Error('请先保存当前修改并下载备份，再恢复总资料包');
      if (file.size > 200000000) throw new Error('总资料包大于 200 MB');
      const bundle = P.validate(JSON.parse(await file.text()), embedded);
      if (!window.confirm('恢复将切换至这份总资料包及其中的人工修订，并重新载入网页。当前资料请先下载备份。是否恢复？')) return;
      bundle.installation_id = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
      await P.install(packageDB, embedded, bundle);
      window.location.reload();
    } catch (error) { message('package-status', '未恢复，当前资料保留：' + error.message, true); }
    finally { $('import-package').value = ''; }
  });
  $('import-edits').addEventListener('change', async () => {
    const file = $('import-edits').files[0];
    if (!file) return;
    try {
      if(reportDraft) throw new Error('请先保存或取消报表输入');
      if (!askToDiscard()) return;
      if(locationDirty && !window.confirm('放弃未保存的定位输入，导入备份？')) return;
      if (file.size > 10000000) throw new Error('修订档大于 10 MB');
      const doc = JSON.parse(await file.text());
      if ((model.document().overrides.length || model.document().place_locations.length) && !window.confirm('汇入会替换目前已保存的篇目及定位修订。请确认已下载备份，是否继续？')) return;
      const proposed=M.create(base); proposed.importDocument(doc); persist(proposed.document()); loadLocation(locationWord); renderChapter(); updateResults();
      message('edit-status', state.unpersisted ? '已应用汇入内容，但未写入本机；关闭前请下载备份。' : '汇入完成：所有修订已同步。',state.unpersisted);
    } catch (error) { message('storage-status', '汇入失败，原有修订未变：' + error.message, true); }
    finally { $('import-edits').value = ''; }
  });

  function locationWords() {
    return [...new Set([...allPlaces().map(p=>p.name),...model.document().place_locations.map(r=>r.name),
      ...model.ids.flatMap(id=>model.view(id).places.map(p=>model.name(p.word)))])].sort((a,b)=>a.localeCompare(b,'zh'));
  }
  function refreshLocationOptions() {
    const query=model.simplify($('location-search').value.trim());
    $('location-word').replaceChildren(element('option',{value:''},'选择文本地名'),...locationWords().filter(word=>word===locationWord || word.includes(query)).map(word=>element('option',{value:word},word)));
    $('location-word').value=locationWord;
    const old=$('location-parent').value;
    $('location-parent').replaceChildren(element('option',{value:''},'未指定／跨界范围见说明'),...allPlaces().filter(p=>p.name!==locationWord).map(p=>element('option',{value:p.id},p.name)));
    $('location-parent').value=old;
  }
  function loadLocation(word) {
    locationWord=word; refreshLocationOptions();
    const r=model.placeInfo(word);
    for (const [id,key] of [['location-modern','modern_name'],['location-modern-level','modern_level'],['location-region','region_description'],
      ['location-source','source_url'],['location-note','note'],['location-level','admin_level'],['location-parent','parent_id'],
      ['location-lon','lon'],['location-lat','lat'],['location-kind','coordinate_kind']]) $(id).value=r[key] ?? '';
    locationDirty=false; pickingLocation=false; $('cancel-pick-location').hidden=true; $('map').style.cursor='';
    message('location-status',word ? word+'：'+(r.lon===null?'待定位；可先保存区域信息。':'已定位；可补充或修改信息。'):'选择地名后填写信息。');
  }
  function openLocation(word=locationWord) {
    if (word !== locationWord && locationDirty && !window.confirm('放弃未保存的定位输入，查看其他地点？')) {$('location-word').value=locationWord;return;}
    if (word !== locationWord || !locationDirty) loadLocation(word);
    reveal('location-panel');
  }
  function locationInput() {
    return {name:locationWord,admin_level:$('location-level').value || 'unknown',modern_name:$('location-modern').value,
      modern_level:$('location-modern-level').value,region_description:$('location-region').value,parent_id:$('location-parent').value,
      source_url:$('location-source').value,note:$('location-note').value,coordinate_kind:$('location-kind').value || 'pending',
      lon:$('location-lon').value.trim()===''?null:Number($('location-lon').value),lat:$('location-lat').value.trim()===''?null:Number($('location-lat').value)};
  }
  $('location-level').replaceChildren(...Object.entries(M.LEVELS).map(([value,label])=>element('option',{value},label)));
  $('location-search').addEventListener('input',refreshLocationOptions);
  $('open-location-editor').addEventListener('click',()=>openLocation(allPlaces().find(p=>p.id===state.place)?.name || locationWord));
  $('location-word').addEventListener('change',()=>openLocation($('location-word').value));
  for (const id of ['location-modern','location-modern-level','location-region','location-source','location-note','location-level','location-parent','location-lon','location-lat','location-kind']) {
    for (const event of ['input','change']) $(id).addEventListener(event,()=>{locationDirty=true;message('location-status','定位信息尚未保存。');});
  }
  $('discard-location').addEventListener('click',()=>loadLocation(locationWord));
  $('clear-location-coordinates').addEventListener('click',()=>{
    $('location-lon').value='';$('location-lat').value='';$('location-kind').value='pending';locationDirty=true;
    message('location-status','坐标已清空；保存后此地会列为待定位，区域说明保留。');
  });
  $('save-location').addEventListener('click',()=>{
    try {
      const proposed=M.create(base); proposed.importDocument(model.document()); proposed.saveLocation(locationInput());
      const durable=persist(proposed.document()); locationDirty=false; pickingLocation=false; $('cancel-pick-location').hidden=true; $('map').style.cursor='';
      updateResults(); resize();
      const p=allPlaces().find(p=>p.name===locationWord);
      if(p) {$('map-search').value='';$('place-layer').value='';$('event-filter').value='';updateResults();choosePlace(p.id);state.transform={k:1,x:0,y:0};paintMap();}
      message('location-status',durable?(p?'定位已保存并加入地图；相关篇目按地点词自动关联。':'区域信息已保存，等待补充坐标。'):'已应用到本页；请下载修订备份保存定位信息。',!durable);
    } catch(error) {message('location-status',error.message,true);}
  });
  $('reset-location').addEventListener('click',()=>{
    if(!locationWord || !window.confirm('恢复'+locationWord+'的原始定位？篇目中的地点词保留。')) return;
    try {const proposed=M.create(base);proposed.importDocument(model.document());proposed.resetLocation(locationWord);persist(proposed.document());loadLocation(locationWord);updateResults();resize();}
    catch(error){message('location-status',error.message,true);}
  });
  $('pick-location').addEventListener('click',()=>{
    if(!locationWord){message('location-status','请先选择文本地名。',true);return;}
    pickingLocation=true;$('cancel-pick-location').hidden=false;$('map').style.cursor='crosshair';
    message('location-status','请在地图上点击近似位置；拖动或缩放后仍可选点。');reveal('map');
  });
  $('cancel-pick-location').addEventListener('click',()=>{pickingLocation=false;$('cancel-pick-location').hidden=true;$('map').style.cursor='';message('location-status','已取消选点，原输入保留。');});
  window.addEventListener('beforeunload',event=>{if(locationDirty){event.preventDefault();event.returnValue='';}});
  loadLocation('');

  const aggregatePlaces = () => $('place-count-scope').value === 'aggregate';
  function filteredChapters(place, aggregate = aggregatePlaces()) {
    const query = model.simplify($('map-search').value.trim()), type = $('event-filter').value;
    const names=[...(place.search_names || [place.name,place.modern_name])], seen=new Set([place.id]);
    let parent=aggregatePlaces() ? place.parent_id : null;
    while(parent && !seen.has(parent)) {
      seen.add(parent); const node=allPlaces().find(p=>p.id===parent); if(!node) break;
      names.push(...(node.search_names || [node.name,node.modern_name])); parent=node.parent_id;
    }
    const placeMatch = names.filter(Boolean).some(s => s.includes(query)) || place.name.includes(model.name(query));
    return model.atPlace(place,aggregate).filter(c => (!type || c.event_types[type] > 0) &&
      (!query || placeMatch || c.chapter.includes(query) || (c.search_title || '').includes(query) || c.places.some(p => model.name(p.word).includes(query))));
  }
  function matchesLayer(p) {
    const layer = $('place-layer').value;
    if (!layer) return true;
    if (layer === 'small-settlement') return ['town', 'village'].includes(G.placeLevel(p));
    if (layer === 'review-ambiguous') return p.location_audit?.status === 'ambiguous';
    if (layer === 'review-unknown') return G.placeLevel(p) === 'unknown';
    return G.placeLevel(p) === layer || p.scale_category === layer;
  }
  function currentPlaces() {
    return allPlaces().filter(matchesLayer)
      .map(p => ({...p,chapters:filteredChapters(p)})).filter(p => p.chapters.length);
  }
  function renderPlace() {
    const out = $('place-detail'); out.replaceChildren();
    const p = allPlaces().find(p => p.id === state.place);
    if (!p) { out.append(element('p', {}, '点击地点或使用地点选单，查看篇目及三界原文。')); return; }
    const chapters = filteredChapters(p), counts = Object.fromEntries(M.EVENTS.map(t => [t, chapters.filter(c => c.event_types[t] > 0).length]));
    out.append(element('h3', {}, p.name + ' → ' + p.modern_name), element('p', {class: 'muted'},
      '目前条件下涉及 ' + chapters.length + ' 篇；' + p.mapping_review_status + '。' + p.note));
    out.append(element('p', {class: 'muted'}, '现代参考座标：北纬 ' + p.lat.toFixed(4) + '°、东经 ' + p.lon.toFixed(4) + '°。'));
    if(p.admin_level || p.region_description) out.append(element('p',{},'文本地名层级：'+(M.LEVELS[p.admin_level] || '待核')+'；现代单位：'+(p.modern_level || '待核')+'；区域：'+(p.region_description || '见来源')));
    if(p.source_url) out.append(element('a',{href:p.source_url,target:'_blank',rel:'noopener noreferrer'},'定位资料来源'));
    if(p.location_audit) {
      const review = element('details'); review.append(element('summary',{},'位置核查与原文依据'),element('p',{},p.location_audit.note));
      for(const e of p.location_audit.evidence || []) review.append(button('《'+e.chapter+'》',()=>chooseChapter(e.chapter_id,true)),element('blockquote',{},e.quote));
      if(p.level_source_url) review.append(element('a',{href:p.level_source_url,target:'_blank',rel:'noopener noreferrer'},'层级资料来源'));
      if(p.historical_parent_warning) review.append(element('p',{class:'warning'},p.historical_parent_warning));
      out.append(review);
    }
    out.append(button('修改'+p.name+'的定位与层级',()=>openLocation(p.name)));
    const direct=filteredChapters(p,false), total=filteredChapters(p,true), children=model.descendants(p);
    out.append(element('p', {class:'chips'}, '直接提及：'+direct.length+'篇 · 区域汇总：'+total.length+'篇（按篇目去重） · 当前列表：'+(aggregatePlaces()?'区域汇总':'直接提及')),
      element('p',{class:'muted'},(p.scale_label || '层级待核')+'。'+(p.historical_level_status || '')+(p.containment_note || '')));
    const hierarchy=element('details'); hierarchy.append(element('summary',{},'包含关系与汇总范围 · '+children.length+'个已关联地点'), element('p',{class:'muted'},base.place_hierarchy?.basis || '未建立包含关系，不推测古代隶属。'));
    const parent=allPlaces().find(q=>q.id===p.parent_id);
    if(parent) hierarchy.append(element('p',{},'关联上级：'+parent.name+'（'+(parent.level_label || M.LEVELS[parent.admin_level] || '参考区域')+'）'),button('查看上级'+parent.name,()=>{
      $('place-layer').value='';updateResults();choosePlace(parent.id);
    }));
    const childList=element('div',{class:'chips'});
    for(const child of children) childList.append(button(child.name+' · 直接提及 '+filteredChapters(child,false).length+'篇',()=>{
      $('place-layer').value=''; updateResults(); choosePlace(child.id);
    }));
    hierarchy.append(childList);
    if(!children.length) hierarchy.append(element('p',{},'本图未建立可汇总的下级地点；不代表该地区实际没有下级单位。'));
    const sources=new Set((base.place_hierarchy?.edges || []).filter(edge=>(edge.parent_id===p.id || edge.child_id===p.id) &&
      allPlaces().find(q=>q.id===edge.child_id)?.parent_id===edge.parent_id).map(edge=>edge.source_url));
    for(const child of children) if(child.coordinate_kind && child.source_url) sources.add(child.source_url);
    for(const source of sources) hierarchy.append(element('a',{href:source,target:'_blank',rel:'noopener noreferrer'},'包含关系来源'));
    out.append(hierarchy);
    const stats = element('div', {class: 'chips'});
    for (const type of M.EVENTS) stats.append(element('span', {class: 'chip', 'data-type': type}, type + '：' + counts[type] + ' 篇'));
    out.append(stats);
    out.append(button('研究' + p.name + '的人物、空间与情节', () => reveal('research-hub')));
    const spaces = new Map();
    for (const c of chapters) for (const word of new Set(c.space_words || [])) spaces.set(word, (spaces.get(word) || 0) + 1);
    const spaceSummary = element('details');
    spaceSummary.append(element('summary', {}, '所涉篇目的空间特征（' + spaces.size + ' 种词）'),
      element('p', {class: 'muted'}, '按涉及篇数统计，含候选与人工保留词；场景所属地区待原文核对。'));
    spaceSummary.append(element('p', {}, [...spaces].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(([word, count]) => word + '：' + count + ' 篇').join('、') || '暂无保留的空间词'));
    out.append(spaceSummary);
    const list = element('div', {class: 'chapters'});
    for (const c of chapters) {
      const tags = M.EVENTS.filter(t => c.event_types[t] > 0).join('／') || '未标记';
      const b = button('#' + (c.chapter_id + 1) + ' ' + c.chapter + '〔' + tags + '〕', () => chooseChapter(c.chapter_id, true), c.chapter_id === state.chapter ? 'active' : '');
      list.append(b);
    }
    out.append(element('p', {class: 'muted'}, '以下按文本篇序排列，不是事件的历史年代；每篇可多类型。'), list);
    if (/^https?:\/\//i.test(p.source_url)) out.append(element('a', {href: p.source_url, target: '_blank', rel: 'noopener noreferrer'}, '地理对照来源（仍需核对具体条目）'));
    if (!chapters.length) out.append(element('p', {class: 'warning'}, '所选地点已被目前筛选隐藏，请清除搜寻或异事类型条件。'));
  }
  function renderRealms() {
    const panel = $('realm-panel'); panel.replaceChildren(element('h3', {}, '三界文本空间（非地理坐标）'));
    const place = allPlaces().find(p => p.id === state.place);
    if(place && aggregatePlaces()) panel.append(element('p',{class:'muted'},'以下三界连线与证据仍针对所选地名的直接关联，不把下级地点的跨界路线转画为省域出发。'));
    const links = place ? model.links(place, new Set(filteredChapters(place).map(c => c.chapter_id))) : globalRealmLinks();
    const allLinks = model.activeEvidence(new Set(model.ids));
    panel.append(element('p', {class: 'muted'}, (place ? place.name + '的篇内空间关联' : '全书三界证据，采用当前筛选及人工修订') + '；虚线＝提及／待核，实线＝人工确认本篇跨界。0 表示本次范围未检出具名证据。'));
    for (const realm of ['天界', '地界']) {
      const section = element('section', {class: 'realm-section', 'data-realm': realm, id: realm === '天界' ? 'realm-sky' : 'realm-underworld'});
      section.append(element('h3', {class: 'realm-heading'}, realm + (realm === '天界' ? '／仙境与异域候选' : '／幽冥与地府候选')));
      const relevant = links.filter(e => e.realm === realm);
      const allRelevant = allLinks.filter(e => e.realm === realm);
      const currentSummary = new Set(relevant.map(e => e.space)).size + ' 个空间证据词 · ' + relevant.length + ' 次提及 · ' + new Set(relevant.map(e => e.chapter_id)).size + ' 篇';
      const baselineSummary = '全书基线：' + new Set(allRelevant.map(e => e.space)).size + ' 个空间证据词 · ' + allRelevant.length + ' 次提及 · ' + new Set(allRelevant.map(e => e.chapter_id)).size + ' 篇';
      section.append(element('p', {class: 'muted'}, currentSummary + (place ? '；' + baselineSummary : '')));
      const groups = new Map();
      for (const e of relevant) {
        const key = e.chapter_id + '|' + e.space;
        if (!groups.has(key)) groups.set(key, []); groups.get(key).push(e);
      }
      for (const evidence of groups.values()) {
        const e = evidence[0], card = element('details', {class: 'evidence-card'});
        card.append(element('summary', {}, e.space + ' · ' + e.chapter + '（' + evidence.length + ' 处）'));
        for (const occurrence of evidence) {
          card.append(element('p', {class: 'muted'}, '原文单位 ' + occurrence.unit + ' · ' + (occurrence.review.kind === 'crossing' ? '人工确认本篇跨界' : '篇内提及，待核')),
            element('blockquote', {}, occurrence.excerpt));
          if (occurrence.review.note) card.append(element('p', {}, occurrence.review.note));
        }
        card.append(button('查看全篇与修订', () => chooseChapter(e.chapter_id, true))); section.append(card);
      }
      if (!groups.size) section.append(element('p', {class: 'muted'}, '当前筛选下暂无具名空间证据。'));
      panel.append(section);
    }
  }
  function unmappedPlaces() {
    const mapped = new Set(allPlaces().map(p => model.name(p.name))), rows = new Map();
    for (const id of model.ids) for (const p of model.view(id).places) {
      const word = model.name(p.word); if (mapped.has(word)) continue;
      if (!rows.has(word)) rows.set(word, {...base.unmapped_textual_places?.find(r=>r.place===word),place: word, chapter_ids: [], reason: base.unmapped_textual_places?.find(r=>r.place===word)?.reason || '未定位地点词；请回看原文并核对古今地理，尚无地图坐标。'});
      if (!rows.get(word).chapter_ids.includes(id)) rows.get(word).chapter_ids.push(id);
    }
    return [...rows.values()];
  }
  function globalRealmLinks() {
    const query = model.simplify($('map-search').value.trim()), type = $('event-filter').value;
    const allowed = new Set(model.ids.filter(id => {
      const c = model.view(id);
      return (!type || c.event_types[type] > 0) && (!query || c.chapter.includes(query) || c.places.some(p => p.word.includes(query)));
    }));
    return model.activeEvidence(allowed);
  }
  if(base.location_audit) {
    const audit=base.location_audit;
    message('location-audit-summary','已筛查 '+audit.checked+' 个参考点；语境改正 '+audit.corrected+' 个，撤下错配／依据不足 '+audit.withdrawn+' 个。其余点仍含同名待核，未全部逐篇确证。');
    for(const row of audit.rows.filter(r=>['corrected','withdrawn','ambiguous'].includes(r.status))) {
      const card=element('details'); card.append(element('summary',{},row.name+' · '+({corrected:'改正',withdrawn:'撤下待核',ambiguous:'同名待核'}[row.status])),element('p',{},row.note));
      for(const e of row.evidence || []) card.append(button('《'+e.chapter+'》',()=>chooseChapter(e.chapter_id,true)),element('blockquote',{},e.quote));
      card.append(button('修改'+row.name+'的定位与层级',()=>openLocation(row.name)));
      $('location-audit-list').append(card);
    }
  }
  $('export-location-audit').addEventListener('click',()=>downloadDocument(base.location_audit || {},'聊斋地名定位核查.json'));
  function historicalAdminLevel(featureType,parentName='') {
    const type = featureType || '';
    if (/省/.test(type)) return 'province';
    if (/府|直隶州/.test(type)) return 'prefecture';
    if (/州/.test(type)) return /府/.test(parentName) ? 'county' : 'prefecture';
    if (/县/.test(type)) return 'county';
    if (/镇|村/.test(type)) return 'town';
    return 'unknown';
  }
  function fillLocationFromHistorical(word, match, search) {
    openLocation(word);
    const coordinates = match.lon !== null && match.lat !== null && Number.isFinite(Number(match.lon)) && Number.isFinite(Number(match.lat)) &&
      Number(match.lon)>=70 && Number(match.lon)<=140 && Number(match.lat)>=15 && Number(match.lat)<=55;
    $('location-level').value = historicalAdminLevel(match.feature_type,match.parent_name);
    $('location-modern').value = (match.name || word) + '（历史记录，现代名称待核）';
    $('location-modern-level').value = '清代代表年记录：' + (match.feature_type || '层级待核') + '；现代层级待核';
    $('location-region').value = (match.parent_name ? '清代隶属：' + match.parent_name + '；' : '') +
      '历史地名检索记录，需结合篇目原文确认其所指区域。';
    $('location-source').value = match.uri || search?.source?.url || '';
    $('location-note').value = '繁体查询词：' + (search?.query_traditional || word) +
      '；优先查询清代代表年1820。检索结果可能有同名地点，当前记录仅作候选，不自动证明故事发生地；坐标为历史数据库参考点，县域边界仍需核对。';
    if (coordinates) {
      $('location-lon').value = Number(match.lon).toFixed(5); $('location-lat').value = Number(match.lat).toFixed(5);
      $('location-kind').value = 'reference';
    } else {
      $('location-lon').value = ''; $('location-lat').value = ''; $('location-kind').value = 'pending';
    }
    locationDirty = true;
    $('location-coordinates').open = coordinates;
    message('location-status', '已将清代历史地名候选填入编辑器；请结合篇目、层级和区域核对后再保存。', true);
  }
  function unmappedList() {
    const query = model.simplify($('unmapped-search').value.trim()), list = $('unmapped-list'); list.replaceChildren();
    for (const p of unmappedPlaces().filter(p => p.place.includes(query))) {
      const d = element('details'); d.append(element('summary', {}, p.place + ' · ' + p.chapter_ids.length + ' 篇'), element('p', {class: 'muted'}, p.reason));
      const info=model.placeInfo(p.place);
      if(info.region_description) d.append(element('p',{},'已补充区域：'+info.region_description+' · '+M.LEVELS[info.admin_level]+' · 等待坐标'));
      const search = base.historical_place_search?.records?.find(row => model.simplify(row.word) === model.simplify(p.place));
      if (search) {
        const box = element('div', {class: 'historical-search'});
        box.append(element('strong', {}, '历史地名检索（清代优先）'),
          element('p', {class: 'muted'}, '繁体查询词：' + search.query_traditional + ' · 1820年结果：' + search.matches.length + ' 条 · ' + search.status));
        if (search.query_url) box.append(element('a', {href: search.query_url, target: '_blank', rel: 'noopener noreferrer'}, '打开本次检索'));
        if (search.matches.length) {
          for (const match of search.matches) {
            const row = element('div', {class: 'historical-match'});
            row.append(element('p', {}, (match.name || '未命名记录') + ' · ' + (match.feature_type || '层级待核')),
              element('p', {class: 'muted'}, '存续：' + (match.years || '未载') +
                (match.parent_name ? ' · 隶属：' + match.parent_name : '') +
                (match.coordinates ? ' · 坐标：' + match.coordinates : ' · 无有效坐标')));
            if (match.uri) row.append(element('a', {href: match.uri, target: '_blank', rel: 'noopener noreferrer'}, '查看历史记录'));
            row.append(button('填入定位编辑器', () => fillLocationFromHistorical(p.place, match, search)));
            box.append(row);
          }
        } else box.append(element('p', {class: 'muted'}, '1820年没有精确记录；请保留待核状态，不据此强行定位。'));
        d.append(box);
      }
      d.append(button('补充'+p.place+'的定位与层级',()=>openLocation(p.place)));
      for (const id of p.chapter_ids) d.append(button('#' + (id + 1) + ' ' + model.view(id).chapter, () => chooseChapter(id, true)));
      list.append(d);
    }
    if (!list.children.length) list.append(element('p', {}, '无符合的未定位候选。'));
  }
  function renderCandidateList() {
    const kind = $('candidate-kind').value, query = model.simplify($('candidate-search').value.trim()).toLowerCase();
    const panel = base.candidate_review?.[kind], list = $('candidate-list'); list.replaceChildren();
    if (!panel) { list.append(element('p', {}, '当前版本没有候选审阅数据。')); return; }
    const matches = panel.rows.filter(row => {
      if (!query) return true;
      const haystack = [row.word, row.status, ...(row.methods || []), ...(row.ai_review ? [row.ai_review.label, row.ai_review.evidence, row.ai_review.canonical] : []),
        ...(row.examples || []).map(x => x.context || ''), ...(row.chapter_ids || []).map(id => model.view(id).chapter)].join(' ').toLowerCase();
      return haystack.includes(query);
    });
    const pages = Math.max(1, Math.ceil(matches.length / 50)); state.candidatePage = Math.min(state.candidatePage, pages - 1);
    message('candidate-count', '符合 ' + matches.length + '／' + panel.count + ' 个');
    message('candidate-page', '第 ' + (state.candidatePage + 1) + '／' + pages + ' 页，每页 50 项');
    $('candidate-prev').disabled = state.candidatePage === 0; $('candidate-next').disabled = state.candidatePage >= pages - 1;
    for (const row of matches.slice(state.candidatePage * 50, (state.candidatePage + 1) * 50)) {
      const card = element('article', {class: 'candidate-card'}), title = element('div');
      title.append(element('strong', {}, row.word), element('span', {class: 'chip'}, row.status || '待核候选')); card.append(title);
      const meta = element('div', {class: 'candidate-meta'});
      meta.append(element('span', {class: 'muted'}, '出现 ' + row.mentions + ' 次／篇目数 ' + (row.chapters || (row.chapter_ids || []).length)),
        element('span', {class: 'muted'}, '来源：' + ((row.methods || []).join('、') || (kind === 'times' ? '时间正则' : '模型候选'))));
      if (row.ai_review) meta.append(element('span', {class: 'chip'}, 'AI：' + row.ai_review.label + ' ' + Math.round((row.ai_review.confidence || 0) * 100) + '%'));
      card.append(meta);
      if (row.ai_review?.canonical) card.append(element('p', {class: 'row-note'}, 'AI所指人物：' + row.ai_review.canonical));
      if (row.ai_review?.person_types?.length) card.append(element('p', {class: 'row-note'}, 'AI人物序列候选：' + row.ai_review.person_types.join('、')));
      if (row.ai_review?.evidence) card.append(element('p', {class: 'row-note'}, 'AI依据：' + row.ai_review.evidence));
      if (row.rejection_reason) card.append(element('p', {class: 'row-note'}, '排除依据：' + row.rejection_reason));
      if (row.context_review_note) card.append(element('p', {class: 'row-note'}, '原文复核：' + row.context_review_note));
      for (const example of row.examples || []) card.append(element('blockquote', {}, (example.chapter ? '《' + example.chapter + '》：' : '') + (example.context || example.original_form || '')));
      for (const id of row.chapter_ids || []) card.append(button('打开 #' + (id + 1) + ' ' + model.view(id).chapter, () => chooseChapter(id, true)));
      if (!(row.chapter_ids || []).length) card.append(element('p', {class: 'row-note'}, '当前审核后人物／地点表未关联到篇目，需先回看原始候选例句。'));
      list.append(card);
    }
    if (!matches.length) list.append(element('p', {}, '无符合的候选词。'));
  }
  function renderBookSynthesis() {
    const out = $('book-synthesis-content');
    out.replaceChildren();
    const chapters = model.ids.map(id => model.view(id)), terms = new Map(), places = new Map(), axes = new Map();
    const add = (map, key) => map.set(key, (map.get(key) || 0) + 1);
    for (const c of chapters) {
      const words = [...new Set(c.space_words || [])];
      for (const word of words) add(terms, word);
      for (const name of new Set(c.places.map(p => model.name(p.word)))) {
        if (!places.has(name)) places.set(name, {chapters:0, words:new Map()});
        const place = places.get(name); place.chapters++;
        for (const word of words) add(place.words, word);
      }
      for (const group of [...(c.realms_present || []), ...Object.keys(c.event_types || {})]) {
        if (!axes.has(group)) axes.set(group, new Map());
        for (const word of words) add(axes.get(group), word);
      }
    }
    const sorted = map => [...map].sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0]));
    out.append(element('p', {class:'muted'}, '每词每篇计一次，以已保存修订为准；共现关系待原文核对。'));
    const chips = element('div', {class:'chips'});
    for (const [label, value] of [['篇目', chapters.length], ['有空间词篇目', chapters.filter(c => c.space_words?.length).length], ['地点词', places.size], ['空间词', terms.size]]) chips.append(element('span', {class:'chip'}, label + '：' + value));
    out.append(chips);
    const top = element('details'); top.open = true; top.append(element('summary', {}, '常见空间词（按涉及篇数）'));
    top.append(element('p', {}, sorted(terms).slice(0,40).map(([w,n]) => w + '：' + n + '篇').join('、') || '暂无空间词'));
    out.append(top);
    const rel = element('details'); rel.append(element('summary', {}, '地点—空间词关系（共现，不等于事发地）'));
    for (const [name, row] of [...places].sort((a,b) => b[1].chapters-a[1].chapters || a[0].localeCompare(b[0]))) {
      const item = element('details'); item.append(element('summary', {}, name + ' · ' + row.chapters + '篇'), element('p', {}, sorted(row.words).map(([w,n]) => w + '：' + n + '篇').join('、') || '暂无空间词')); rel.append(item);
    }
    out.append(rel);
    const groups = element('details'); groups.append(element('summary', {}, '三界与异事类型的空间特点'));
    for (const [group, values] of axes) groups.append(element('p', {}, group + '：' + (sorted(values).slice(0,30).map(([w,n]) => w + ' ' + n + '篇').join('、') || '暂无空间词')));
    out.append(groups);
    const themes = new Map(), analysed = chapters.filter(c => c.narrative_analysis);
    for (const c of analysed) for (const motif of c.narrative_analysis.motifs) {
      if (!themes.has(motif.label)) themes.set(motif.label, []);
      themes.get(motif.label).push(c);
    }
    if (analysed.length) {
      const topics = element('details'); topics.append(element('summary', {}, '篇目之间的情节主题 · AI已分析 ' + analysed.length + '篇'), element('p', {class:'muted'}, '统计仅限有全文 AI 草稿的篇目，不是全书主题分布；主题及解读待核，可逐篇对照空间路径。'));
      for (const [topic, members] of [...themes].sort((a,b) => b[1].length-a[1].length)) {
        const group = element('details'); group.append(element('summary', {}, topic + ' · ' + members.length + '篇'));
        for (const c of members) group.append(button(c.chapter, () => { if (chooseChapter(c.chapter_id)) reveal('research-hub'); }));
        topics.append(group);
      }
      out.append(topics);
    }
    const questions = element('details'); questions.append(element('summary', {}, '研究线索'));
    for (const claim of base.book_synthesis?.research_claims || []) questions.append(element('p', {}, claim));
    out.append(questions);
  }
  function renderResearch(chapter, preview = false) {
    const place = allPlaces().find(p => p.id === state.place);
    const group = place ? model.atPlace(place,aggregatePlaces()) : model.ids.map(id => model.view(id));
    const query = model.simplify($('research-search').value.trim()), pathFilter = $('research-path-filter').value;
    const filtered = group.filter(c => (!$('event-filter').value || Object.hasOwn(c.event_types || {}, $('event-filter').value)) &&
      (!query || model.simplify(c.chapter).includes(query)) && (!pathFilter || (pathFilter === 'ai-pending' ? !c.narrative_analysis : (pathFilter === 'has') === !!c.narrative_events?.length)));
    const annotated = filtered.filter(c => (c.narrative_events || []).length);
    $('research-chapter-select').replaceChildren(...filtered.map(c => element('option', {value:c.chapter_id}, c.chapter + ' · ' + (c.narrative_events || []).length + '步')));
    if (!filtered.some(c => c.chapter_id === chapter.chapter_id)) $('research-chapter-select').append(element('option', {value:chapter.chapter_id}, chapter.chapter + ' · 当前篇（范围外）'));
    $('research-chapter-select').value = String(chapter.chapter_id);
    $('research-all').hidden = !place && !$('event-filter').value && !query && !pathFilter;
    $('research-scope').textContent = (place ? place.name : '全书') + '：' + filtered.length + ' 篇' + ($('event-filter').value ? ' · 异事：' + $('event-filter').value : '') + (query ? ' · 搜索：'+query : '') + (pathFilter ? ' · '+({has:'已有路径',missing:'尚无路径','ai-pending':'AI待完成'}[pathFilter]) : '') + '，其中 ' + annotated.length + ' 篇有情节标注。当前：《' + chapter.chapter + '》' + (preview ? ' · 未保存预览' : ' · 已保存资料') + (!filtered.some(c => c.chapter_id === chapter.chapter_id) ? ' · 当前篇不在比较范围内' : '') + (base.narrative_coverage ? ' · 全文AI分析 ' + base.narrative_coverage.ai_read + '/' + base.narrative_coverage.total + ' 篇，余 ' + base.narrative_coverage.pending.length + ' 篇待完成。' : '');
    $('research-chapters').replaceChildren(...annotated.map(c => button(c.chapter + ' · ' + c.narrative_events.length + '步', () => chooseChapter(c.chapter_id))));
    message('research-list-status', '有路径标注的篇目：' + annotated.length + '篇；点击空间词可查看相关篇目。');
    const comparison = $('research-comparison'); comparison.replaceChildren();
    const terms = new Map();
    for (const c of filtered) for (const word of new Set(c.space_words || [])) terms.set(word, (terms.get(word) || 0) + 1);
    comparison.append(element('h3', {}, '地区／全书空间比较'), element('p', {class:'muted'}, '当前范围 ' + filtered.length + ' 篇，按涉及篇数统计；场景所属地区待核。'));
    const badges = element('div', {class:'chips'});
    for (const [word, count] of [...terms].sort((a,b) => b[1]-a[1]).slice(0,20)) badges.append(button(word + ' · ' + count + '篇', () => {
      const matches = filtered.filter(c => (c.space_words || []).includes(word));
      $('research-chapters').replaceChildren(...matches.map(c => button(c.chapter + ' · ' + (c.narrative_events || []).length + '步', () => chooseChapter(c.chapter_id))));
      message('research-list-status', '空间词「' + word + '」：' + matches.length + '篇');
    })); comparison.append(badges);
    const out = $('research-network'); out.replaceChildren();
    out.append(button('在地图查看本篇人物路线与空间解读',()=>{ $('movement-scope').value='chapter';renderMovement();reveal('map-section');paintMap(); }));
    const rows = chapter.narrative_events || [];
    const analysis = chapter.narrative_analysis;
    out.append(element('p', {class:'muted'}, preview ? '未保存的路径预览。' : model.hasEdit(chapter.chapter_id) ? '路径以已应用的人工修订为准；' + (analysis ? '下方 AI 综合解读仍基于原始全文。' : '此篇尚无通过核验的全文 AI 综合解读。') : chapter.narrative_status === 'close_reading_pilot' ? '三篇精读试点；AI 全文分析作为补充。' : analysis ? 'AI 全文分析草稿：引句已通过原文核验，解释、身份与主题仍待人工核定。' : '尚未取得通过原文核验的 AI 分析。'));
    if (analysis) {
      const overview = element('details'); overview.open = true;
      overview.append(element('summary', {}, '本篇空间机制 · AI 解读待核'), element('p', {}, analysis.summary));
      if (analysis.caution) overview.append(element('p', {class:'muted'}, '需注意：' + analysis.caution));
      for(const note of chapter.narrative_editorial_notes || []) overview.append(element('p',{class:'muted'},'AI辅助原文核读修订：'+note));
      overview.append(element('p', {}, '主题：' + analysis.motifs.map(m => m.label).join('、'))); out.append(overview);
    }
    const related = $('chapter-relations-content'); related.replaceChildren();
    const matches = model.related(chapter.chapter_id);
    related.append(element('p', {class:'muted'}, '全书 ' + matches.length + ' 篇有共同特征；显示关联度较高的前 12 篇。'));
    for (const match of matches.slice(0,12)) {
      const item = element('details'); item.append(element('summary', {}, '《' + match.chapter + '》 · ' + match.reasons.slice(0,3).map(r => r.kind + '：' + r.label).join(' / ')));
      item.append(button('阅读《' + match.chapter + '》路径', () => chooseChapter(match.chapter_id)));
      const other = model.view(match.chapter_id), contrast = element('details');
      contrast.append(element('summary', {}, '对照两篇的空间机制与结局'));
      for (const c of [chapter,other]) {
        contrast.append(element('h4', {}, '《' + c.chapter + '》'), element('p', {}, c.narrative_analysis?.summary || '尚无全文AI综合解读；请查看原文与人工路径。'));
        const movement = (c.narrative_events || []).filter(r => r.transition_kind === 'movement');
        contrast.append(element('p', {class:'muted'}, '当前路径中的明确移动：' + (movement.map(r => r.from_space + ' → ' + r.to_space).join('；') || '暂无明确移动标注，不表示原文没有移动。')));
      }
      contrast.append(element('p', {class:'muted'}, '综合解读为AI草稿；请比较共同主题在不同场景中的作用，以及人物进入、退出空间后的关系或身份差异。共同词不能代替这一判断。')); item.append(contrast);
      for (const reason of match.reasons.slice(0,6)) {
        item.append(element('p', {}, reason.kind + '：' + reason.label));
        for (const [title, evidence] of [[chapter.chapter, reason.left], [match.chapter, reason.right]]) if (evidence) {
          item.append(element('p', {class:'muted'}, '《' + title + '》 · 单位 ' + evidence.unit + (evidence.role ? ' · AI地点作用：' + {event:'事件地点',origin:'籍贯',mentioned:'提及／待核'}[evidence.role] : '')),
            element('blockquote', {}, evidence.quote));
          if (evidence.interpretation) item.append(element('p', {}, evidence.interpretation));
        }
      }
      related.append(item);
    }
    if (!rows.length) { out.append(element('p', {class:'research-empty'}, '《' + chapter.chapter + '》尚无通过核验的路径分析；不等于没有空间变化。可点击“修改本篇路径”人工记录，后续AI批次不会覆盖已保存人工修订。')); return; }
    const counts = new Map(), sequence = element('div', {class:'research-sequence', 'aria-label':'情节路径，按叙述顺序排列'});
    rows.forEach((row, index) => {
      const card = element('details', {class:'research-step'}); card.open = index === 0;
      const kind = row.transition_kind || 'mention';
      const route = kind === 'movement' ? row.from_space + ' → ' + row.to_space : kind === 'plot' && row.from_space && row.to_space ? row.from_space + ' ⇢ ' + row.to_space : row.space;
      const title = element('summary'); title.append(element('strong', {}, route), element('span', {class:'chip'}, {movement:'人物移动',plot:'情节转换',mention:'场景记录／待核'}[kind]), element('span', {class:'step-event'}, row.event));
      card.append(title,
        element('p', {}, '人物：' + row.actors + ' · 身份：' + (row.identity || '待核')),
        element('p', {class:'muted'}, '叙述步骤 ' + (index + 1) + ' · 事件时间：' + (row.temporal_order || '待核') + ' · ' + (row.location || '地点角色待核') + (row.boundary_medium ? ' · 边界／媒介：' + row.boundary_medium : '') + (row.narrative_role ? ' · 叙事功能：' + row.narrative_role : '')),
        element('blockquote', {}, row.quote), element('p', {class:'muted'}, '原文单位 ' + row.unit + (row.unit_end ? '—' + row.unit_end : '')), element('p', {}, '文学解读：' + (row.interpretation || '待补充')),
        button('对照完整原文', () => { reveal('narrative-panel'); $('original-text').focus(); const units = chapter.source_units, pos = units.findIndex(u => u.unit === row.unit), end = units.findIndex(u => u.unit === (row.unit_end ?? row.unit)); const start = units.slice(0,pos).map(u => u.text).join('').length; $('original-text').setSelectionRange(start, start + units.slice(pos,end+1).map(u => u.text).join('').length); }));
      sequence.append(card);
      const spaces = [...new Set(kind === 'movement' ? [row.from_space, row.to_space] : [row.space])].filter(Boolean);
      const actors = N.actors(chapter, row);
      for (const actor of actors) for (const space of spaces) {
        const key = JSON.stringify([actor, space]); counts.set(key, (counts.get(key) || 0) + 1);
      }
    });
    out.append(element('h3', {}, '空间节点与叙述顺序'), sequence);
    const table = element('table'), head = element('tr');
    for (const name of ['人物','空间','步骤数']) head.append(element('th', {scope:'col'}, name)); table.append(head);
    for (const [key, count] of counts) { const tr = element('tr'); for (const value of [...JSON.parse(key), count]) tr.append(element('td', {}, value)); table.append(tr); }
    const scroll = element('div', {class:'table-scroll'}); scroll.append(table);
    const relations = element('details'); relations.append(element('summary', {}, '人物—空间关系 · ' + counts.size + ' 组（展开查看步骤数）'), scroll); out.append(relations);
  }
  $('edit-research').addEventListener('click', () => reveal('narrative-panel'));
  $('research-chapter-select').addEventListener('change', () => {
    if (!chooseChapter(Number($('research-chapter-select').value))) $('research-chapter-select').value = String(state.chapter);
  });
  $('research-search').addEventListener('input', () => renderResearch(model.view(state.chapter)));
  $('research-path-filter').addEventListener('change', () => renderResearch(model.view(state.chapter)));
  $('research-all').addEventListener('click', () => {
    $('event-filter').value = ''; $('map-search').value = ''; $('research-search').value=''; $('research-path-filter').value=''; choosePlace(''); updateResults();
  });
  $('preview-research').addEventListener('click', () => {
    try {
      const draft = collectChanges(); renderResearch({...model.view(state.chapter), narrative_events:draft.narrative_events}, true);
      message('research-preview-status', '已预览未保存内容。请保存本篇后再备份。'); reveal('research-hub');
    } catch (error) { message('research-preview-status', error.message, true); }
  });
  const library = $('research-documents');
  const latestAudits=(embedded.research_documents || []).filter(d=>d.title.startsWith('方位与地名逐词复核'));
  for (const doc of [...latestAudits,...(base.research_documents || []).filter(d=>!latestAudits.some(a=>a.title===d.title))]) {
    const card = element('details'); card.append(element('summary', {}, doc.title), element('pre', {class:'research-document'}, doc.content)); library.append(card);
  }
  function choosePlace(id) {
    state.place = id || null; $('place-select').value = id || '';
    const selected = allPlaces().find(p => p.id === id);
    if (selected && projection) {
      const anchor = G.screen(projection([selected.lon, selected.lat]), state.transform);
      if (anchor[0] < 24 || anchor[1] < 24 || anchor[0] > drawWidth() - 24 || anchor[1] > state.height - 24) {
        state.transform.x += drawWidth() / 2 - anchor[0];
        state.transform.y += state.height / 2 - anchor[1];
      }
    }
    $('chronology-place').value = selected?.name || ''; renderChronology();
    renderMovement(); renderPlace(); renderRealms(); paintMap();
    renderResearch(model.view(state.chapter));
  }
  function dateRole(r) { return r.ai_review?.time_role || r.time_role || '待核'; }
  function renderChronology() {
    const data = base.chronology, out = $('chronology-list'); out.replaceChildren();
    if (!data) return;
    const place = $('chronology-place').value;
    const role = $('chronology-role').value, review = $('chronology-review').value;
    const selected = allPlaces().find(p=>p.id===state.place && p.name===place);
    const placeNames=selected && aggregatePlaces() ? [selected,...model.descendants(selected)].map(p=>p.name) : [place];
    const rows = data.records.filter(r => (!place || r.places.some(p=>placeNames.includes(p))) && ($('chronology-undated').checked || r.year_start !== null) &&
      (!role || dateRole(r) === role) && (!review || (r.ai_review?.label || 'uncertain') === review));
    message('chronology-count', rows.length + ' 条纪年记录');
    message('chronology-note', (place ? '当前地点：' + place + (placeNames.length>1?'（关联区域汇总）':'')+'。' : '全书年表。') + data.note + ' 日期性质优先展示 AI 判断（仍需复核）；人物经历、背景和讲述日期不能直接用作异事发生年。人工修改地点后，年表地点关系仍须逐条复核。');
    for (const r of rows) {
      const tr = element('tr'), chapterCell = element('td'), evidenceCell = element('td');
      chapterCell.append(button(r.chapter, () => chooseChapter(r.chapter_id, true)), element('p', {}, r.places.join('、')));
      evidenceCell.append(element('p', {}, '原文单位 ' + r.unit + '：' + r.excerpt));
      if (r.ai_review) {
        const ai=r.ai_review, labels={confirmed:'AI支持纪年解释',uncertain:'AI待核',reject:'AI排除纪年解释'};
        evidenceCell.append(element('p', {class:'chip'}, (labels[ai.label] || 'AI待核')+' · '+Math.round(ai.confidence*100)+'%'),
          element('p', {}, '日期性质：'+ai.time_role+'；'+ai.reason));
        if (ai.evidence) evidenceCell.append(element('blockquote', {}, ai.evidence));
        if (ai.places?.length) evidenceCell.append(element('p', {}, 'AI地点建议：'+ai.places.map(p=>p.name+'（'+p.role+'）').join('、')));
        if (ai.suggested_year_start !== null && ai.suggested_year_start !== undefined)
          evidenceCell.append(element('p', {class:'muted'}, 'AI建议年份（待确认）：'+ai.suggested_year_start+'—'+ai.suggested_year_end));
      }
      tr.append(element('td', {}, r.date_label), element('td', {}, r.expression), chapterCell,
        element('td', {}, [dateRole(r), r.place_relation, r.method, r.review_note].filter(Boolean).join('；')),
        evidenceCell);
      out.append(tr);
    }
    if (!rows.length) message('chronology-note', (place ? place + '：' : '') + '当前条件无纪年记录，可按“查看全书年表”清除年表筛选。');
  }
  function refreshChronologyPlaces() {
    const previous=$('chronology-place').value;
    const words=[...new Set([...allPlaces().map(p=>p.name),...(base.chronology?.records || []).flatMap(r=>r.places)])].sort();
    $('chronology-place').replaceChildren(element('option',{value:''},'全部地点'),...words.map(p=>element('option',{value:p},p)));
    $('chronology-place').value=previous;
  }
  refreshChronologyPlaces();
  $('chronology-place').addEventListener('change', renderChronology);
  $('chronology-undated').addEventListener('change', renderChronology);
  $('chronology-role').addEventListener('change', renderChronology);
  $('chronology-review').addEventListener('change', renderChronology);
  $('chronology-reset').addEventListener('click', () => {
    $('chronology-place').value = ''; $('chronology-role').value = ''; $('chronology-review').value = '';
    $('chronology-undated').checked = true; renderChronology();
  });
  let movementRows = [];
  function renderMovement() {
    const mode=movementMode(),selected=allPlaces().find(p=>p.id===state.place);
    $('movement-chapter').replaceChildren(...model.ids.map(id=>element('option',{value:id},model.view(id).chapter)));
    $('movement-chapter').value=String(state.chapter);
    const routeAggregate=routeAggregatePlaces(), directIds=selected ? new Set(model.atPlace(selected,false).map(c=>c.chapter_id)) : new Set();
    const chapters=mode==='place' ? selected ? model.atPlace(selected,routeAggregate) : [] : [model.view(state.chapter)];
    const type=$('event-filter').value;
    const all=N.rows(model,chapters.filter(c=>!type || c.event_types[type]>0),allPlaces()).map(row=>({...row,route_scope:mode==='place' && routeAggregate && !directIds.has(row.chapter_id)?'descendant':'direct'}));
    const old=restoredRouteActor || $('movement-actor').value,actorChoices=[...new Set(all.flatMap(r=>r.actorsList.map(a=>r.chapter_id+'|'+a)))];restoredRouteActor='';
    $('movement-actor').replaceChildren(element('option',{value:''},'全部人物'),...actorChoices.map(key=>{
      const split=key.indexOf('|'),id=Number(key.slice(0,split));return element('option',{value:key},(mode==='place'?'《'+model.view(id).chapter+'》 · ':'')+key.slice(split+1));
    }));
    $('movement-actor').value=actorChoices.includes(old)?old:'';
    const actor=$('movement-actor').value;
    try{if(typeof sessionStorage!=='undefined') sessionStorage.setItem(routeViewKey,JSON.stringify({chapter:state.chapter,place:state.place,scope:$('movement-scope').value,actor}));}catch(_){}
    movementRows=mode && mode!=='off' ? all.filter(r=>!actor || r.actorsList.some(a=>r.chapter_id+'|'+a===actor)) : [];
    const moves=movementRows.filter(r=>r.transition_kind==='movement'),mapped=moves.filter(r=>r.from && r.to).length;
    const step=$('movement-step').value;
    $('movement-step').replaceChildren(...moves.map(r=>element('option',{value:r.chapter_id+':'+r.index},'《'+r.chapter+'》第'+(r.index+1)+'步 '+r.from_space+' → '+r.to_space)));
    $('movement-step').value=moves.some(r=>r.chapter_id+':'+r.index===step)?step:moves.length?moves[0].chapter_id+':'+moves[0].index:'';
    $('movement-next').disabled=moves.length<2;
    message('movement-status',!mode || mode==='off' ? '选择当前篇或所选地点，查看人物路线、空间作用与时间关联。' : mode==='place' && !selected ? '请先在地图上选择一个地点。' :
      (mode==='place'?selected.name+' · '+(routeAggregate?'区域汇总（含下辖地点）':'直接提及')+' · '+chapters.length+'篇关联篇目':'《'+model.view(state.chapter).chapter+'》')+'：'+moves.length+'步人物移动，'+mapped+'步可画地理参考线。区域汇总中，实线为直接提及，虚线为下辖地点；地图下缘显示所选步骤的空间示意。颜色按'+(mode==='place'?'篇目':'人物称呼')+'区分。路线标注显示篇名与人物，点击可查看具体步骤；步骤按叙述顺序排列。AI路线与空间判断待核，人工修订优先。');
    const legend=$('movement-legend');legend.replaceChildren();
    const keys=[...new Map(moves.map(r=>[mode==='place'?r.chapter_id:actor || r.chapter_id+'|'+r.actorsList.join('、'),(mode==='place' && r.route_scope==='descendant'?'下辖 · ':'')+(mode==='place'?'《'+r.chapter+'》':actor?actor.slice(actor.indexOf('|')+1):r.actorsList.join('、'))])).entries()];
    for(const [key,label] of keys) {const chip=element('span',{class:'chip'},label);chip.style.borderColor=N.color(key);chip.style.color=N.color(key);legend.append(chip);}
    const paths=$('movement-paths');paths.replaceChildren();
    paths.append(element('p',{class:'muted'},'空间使用方式（私人／公共等）与所属世界分开判定。词汇线索均待核，寺庙、书斋或庭院须结合谁能进入、观看及控制空间判断。未定位场景保留名称，不借用籍贯坐标。'));
    const counts=new Map();for(const r of movementRows) counts.set(r.classification.access,(counts.get(r.classification.access)||0)+1);
    if(movementRows.length) paths.append(element('p',{},'本范围情节步骤分类（含待核线索，非词频）：'+[...counts].map(([label,n])=>label+' '+n+'步').join('；')+'。异境线索／标注 '+movementRows.filter(r=>r.classification.realm==='异境').length+'步，可展开每一步比较人物身份与故事转折。'));
    const appendRows=(start=0)=>{
      for(const row of movementRows.slice(start,start+30)) {
        const c=model.view(row.chapter_id),s=row.classification,card=element('details',{'data-movement-row':row.chapter_id+':'+row.index});
        card.append(element('summary',{},'《'+row.chapter+'》 第'+(row.index+1)+'步 · '+row.actorsList.join('、')+' · '+(row.from_space && row.to_space?row.from_space+' → '+row.to_space:row.space)));
        if(row.transition_kind==='movement') {
          const diagram=svg('svg',{viewBox:'0 0 700 64',role:'img','aria-label':row.from_space+'到'+row.to_space});diagram.style.width='100%';diagram.style.maxHeight='90px';
          for(const [x,label] of [[5,row.from_space],[440,row.to_space]]) {diagram.append(svg('rect',{x,y:8,width:250,height:42,rx:8,fill:'#edf1eb',stroke:'#82998c'}));const t=svg('text',{x:x+10,y:34,'font-size':14},label.slice(0,16));t.append(svg('title',{},label));diagram.append(t);}
          diagram.append(svg('path',{d:'M265,29 H428 M417,21 L428,29 L417,37',stroke:N.color(row.chapter_id),fill:'none','stroke-width':2}));card.append(diagram);
        }
        const before={access:row.from_access||row.endpoint_review?.from_access||'待核',realm:row.from_realm||row.endpoint_review?.from_realm||'待核'};
        card.append(element('p',{},'人物身份阶段：'+(row.identity || '待核')+'；到达／当前空间使用方式：'+s.access+(s.accessAiReviewed?'（DeepSeek核查）':s.accessReviewed?'（人工标注）':'（词汇线索，待核）')+'；所属世界：'+s.realm+(s.realmAiReviewed?'（DeepSeek核查）':s.realmReviewed?'（人工标注）':'（词汇线索，待核）')),
          element('p',{class:'muted'},row.transition_kind==='movement'?'变化线索：'+before.access+' → '+s.access+'；'+before.realm+' → '+s.realm+'。请核对人物进入后的身份、权力、亲密关系及离开条件。':'请核对谁可以进入、观看与支配此空间，以及此处发生的关系变化。'),
          element('p',{},'事件：'+row.event),element('p',{},'空间与人物／情节：'+(s.interpretation || '请结合人物言行补充解读。')),
          element('p',{class:'muted'},'事件时间：'+(row.temporal_order || '待核')+'；原文时间词：'+(Object.keys(c.years || {}).filter(w=>row.quote?.includes(w)).join('、') || '本步未提取')+'；原文单位 '+row.unit+(row.unit_end?'—'+row.unit_end:'')+'；地理绑定：'+(row.from?.name || '出发点未定位')+' → '+(row.to?.name || '到达点未定位')),
          element('blockquote',{},row.quote));
        card.append(button('阅读／修订本篇',()=>{if(chooseChapter(row.chapter_id,true)) showEditor('narrative-panel');}));paths.append(card);
      }
      if(start+30<movementRows.length) {const more=button('继续显示后续步骤（共'+movementRows.length+'步）',()=>{more.remove();appendRows(start+30);});paths.append(more);}
    };appendRows();
    const relations=$('movement-relations');relations.replaceChildren(element('p',{class:'muted'},'同篇同一情节步骤是人物关系的阅读线索；跨篇共同地点与纪年只表示可比较性，不证明人物相遇、亲缘或影响。相对时间如“翌日”不用于跨篇排序，籍贯也不充当事发地点。'));
    for(const row of movementRows.filter(r=>r.actorsList.length>1)) {
      const item=element('details');item.append(element('summary',{},'同一情节步骤（同场待核）：《'+row.chapter+'》 '+row.actorsList.join('、')+' · '+row.space),element('blockquote',{},row.quote));relations.append(item);
    }
    const pairs=N.relations(movementRows,selected,base);
    relations.append(element('p',{},selected?'经明确路线端点关联到'+selected.name+'的跨篇步骤对：'+pairs.length+'组。':'选择地点并切换“所选地点的多篇路线”，查看同地人物与时间线索。'));
    const showPairs=(start=0)=>{
      for(const pair of pairs.slice(start,start+30)) {
        const item=element('details');item.append(element('summary',{},'《'+pair.a.chapter+'》'+pair.a.actorsList.join('、')+' ／《'+pair.b.chapter+'》'+pair.b.actorsList.join('、')+'：'+pair.time));
        for(const [row,dates] of [[pair.a,pair.datesA],[pair.b,pair.datesB]]) item.append(element('p',{},'《'+row.chapter+'》：'+row.from_space+' → '+row.to_space+'；'+(dates.map(d=>d.expression+'（'+d.date_label+'）').join('、') || '这一步缺少可核定年份')),element('blockquote',{},row.quote));
        relations.append(item);
      }
      if(start+30<pairs.length) {const more=button('查看更多同地关联',()=>{more.remove();showPairs(start+30);});relations.append(more);}
    };showPairs();
  }
  $('movement-scope').addEventListener('change',()=>{renderMovement();paintMap();});
  $('movement-place-scope').addEventListener('change',()=>{renderMovement();paintMap();});
  $('movement-step').addEventListener('change',paintMap);
  $('movement-next').addEventListener('click',()=>{const options=[...$('movement-step').children],index=options.findIndex(o=>o.value===$('movement-step').value);if(options.length)$('movement-step').value=options[(index+1)%options.length].value;paintMap();});
  $('movement-actor').addEventListener('change',()=>{renderMovement();paintMap();});
  $('movement-chapter').addEventListener('change',()=>{if(chooseChapter(Number($('movement-chapter').value))){$('movement-scope').value='chapter';$('movement-actor').value='';}renderMovement();paintMap();});
  $('movement-edit').addEventListener('click',()=>{reveal('workspace');showEditor('narrative-panel');});
  let reportRows=null, reportPage=0, reportDraft=false, reportMatches=[],reportActive=null;
  const R=GhostMapReports;
  const reportStatuses={retained:'现有（未人工确认）',pending:'待核候选',accepted:'人工保留',rejected:'人工排除',excluded:'已核对排除',corrected:'已修正／改类',removed:'当前修订已移除'};
  function reportData(){if(!reportRows) reportRows=R.rows(base,model);return reportRows;}
  function reportBars(container,values){
    container.replaceChildren();const max=Math.max(1,...values.map(v=>v[1]));
    for(const [label,value] of values){const bar=element('div',{class:'report-bar'});bar.append(element('span',{},label),element('meter',{min:0,max,value,'aria-label':label+' '+value}),element('span',{},String(value)));container.append(bar);}
    if(!values.length) container.append(element('p',{class:'muted'},'当前范围暂无数据。'));
  }
  function reportPie(container,values,title='路径步骤类型占比'){
    container.replaceChildren(); const total=values.reduce((sum,item)=>sum+item[1],0);
    if(!total){container.append(element('p',{class:'muted'},'当前范围暂无数据。'));return;}
    const colors=['#7042b8','#d85e00','#008477','#176bb0','#b88627','#657668']; let cursor=0;
    const segments=values.map(([label,value],index)=>{const start=cursor;cursor+=value/total*100;return colors[index%colors.length]+' '+start+'% '+cursor+'%';});
    const pie=element('div',{class:'report-pie',role:'img','aria-label':title});pie.style.background='conic-gradient('+segments.join(',')+')';container.append(pie);
    const legend=element('div',{class:'report-pie-legend'});values.forEach(([label,value],index)=>{const item=element('span');const swatch=element('i');swatch.style.background=colors[index%colors.length];item.append(swatch,element('span',{},label+' '+value+'（'+(value/total*100).toFixed(1)+'%）'));legend.append(item);});container.append(legend);
  }
  let pathPage=0,pathMatches=[],pathContext='',pathRowsCache=null;
  const pathKinds={movement:'人物移动',plot:'情节转换',mention:'空间提及',scene:'场景标注'};
  function renderPathReport(){
    const scope=$('path-scope')?.value||'all', chapter=$('report-chapter')?.value||'';
    const query=model.simplify($('path-search').value||'').trim(),metric=$('path-metric').value||'chapters';
    const context=JSON.stringify([scope,chapter,query]);if(pathContext!==context){pathPage=0;pathContext=context;}
    if(!pathRowsCache) pathRowsCache=R.pathRows(base,model);
    let rows=pathRowsCache.filter(row=>(!chapter||row.chapter_id===Number(chapter))&&(!query||model.simplify([row.chapter,row.actors,row.space,row.from_space,row.to_space,row.quote,row.location].join(' ')).includes(query)));
    if(scope==='movement') rows=rows.filter(row=>row.has_movement); else if(scope==='scene') rows=rows.filter(row=>!row.has_movement);
    pathMatches=rows;
    const grouped=R.aggregatePaths(rows);
    const normalized=$('path-normalized');normalized.replaceChildren();
    for(const item of grouped.normalized) {
      const detail=element('details');detail.append(element('summary',{},item.label+' · '+item.chapters+'篇 / '+item.count+'步'));
      for(const row of rows.filter(row=>row.normalized_transition===item.label).slice(0,5)) detail.append(element('p',{},'《'+row.chapter+'》 '+row.from_space+' → '+row.to_space),element('blockquote',{},row.quote),button('核对路径',()=>{if(!reportDraft&&chooseChapter(row.chapter_id,true)) reveal('narrative-panel');}));
      normalized.append(detail);
    }
    if(!grouped.normalized.length) normalized.append(element('p',{},'当前范围尚无双端类型明确的核查记录。'));
    const auditText=items=>items.map(item=>item.label+' '+item.count+'步').join('；');
    $('path-audit').textContent='分类来源（按当前步骤统计）：使用方式：'+auditText(grouped.accessAudit)+'。所属世界：'+auditText(grouped.realmAudit)+'。AI阅读过篇目，不代表其中每个新增步骤均已完成分类。';
    const allTransitions=$('path-all-transitions');allTransitions.replaceChildren();
    const transitionTable=element('table'),transitionHead=element('tr');
    for(const title of ['具体转移','涉及篇数','步骤次数','原文核对']) transitionHead.append(element('th',{},title));
    transitionTable.append(transitionHead);
    for(const item of grouped.transitions.slice().sort((a,b)=>b[metric]-a[metric]||b.count-a.count)) {
      const tr=element('tr'),links=element('td'),matches=rows.filter(row=>row.has_movement&&row.from_space+' → '+row.to_space===item.label),seen=new Set();
      for(const row of matches) if(!seen.has(row.chapter_id)&&seen.size<3) {seen.add(row.chapter_id);links.append(button('《'+row.chapter+'》',()=>{if(!reportDraft&&chooseChapter(row.chapter_id,true)) reveal('narrative-panel');}));}
      tr.append(element('td',{},item.label),element('td',{},item.chapters),element('td',{},item.count),links);transitionTable.append(tr);
    }
    allTransitions.append(element('p',{class:'muted'},'共 '+grouped.transitions.length+' 种具体转移。'),transitionTable);
    $('path-summary').replaceChildren(...[grouped.chapters+' 篇有路径',grouped.steps+' 个步骤',grouped.movementSteps+' 个移动步骤',grouped.spaces.length+' 个空间表达'].map(text=>element('span',{class:'chip'},text)));
    const ranked=items=>items.slice().sort((a,b)=>b[metric]-a[metric]||b.chapters-a.chapters||b.count-a.count||a.label.localeCompare(b.label,'zh'));
    for(const [id,items] of [['path-space-chart',grouped.spaces],['path-transition-chart',grouped.transitions],['path-location-chart',grouped.locations]]) reportBars($(id),ranked(items).slice(0,12).map(item=>[item.label,item[metric]]));
    reportPie($('path-kind-chart'),grouped.kinds.map(item=>[pathKinds[item.label]||'类型待核',item.count]));
    reportPie($('path-access-chart'),grouped.access.map(item=>[item.label,item.count]),'空间使用方式占比');
    reportPie($('path-realm-chart'),grouped.realms.map(item=>[item.label,item.count]),'人间与异境标注占比');
    const common=ranked(grouped.patterns.filter(item=>item.chapters>1));
    const top=ranked(grouped.spaces)[0],unknown=grouped.access.find(item=>item.label==='待核')?.count||0;
    $('path-insights').textContent=rows.length?(top?'当前最常见的空间表达为“'+top.label+'”，涉及 '+top.chapters+' 篇、'+top.count+' 个步骤。':'当前未提取可排名的空间表达。')+' 共有 '+common.length+' 种跨篇空间使用方式转移模式；'+unknown+' 个步骤的使用方式待核。排名按'+(metric==='chapters'?'涉及篇数':'步骤次数')+'，饼图统一按步骤次数。':'当前筛选没有路径，请更换篇目或清空路径搜索。';
    const patterns=$('path-patterns');patterns.replaceChildren();
    for(const item of common.slice(0,8)){
      const detail=element('details');detail.append(element('summary',{},item.label+' · '+item.chapters+'篇 / '+item.count+'步'));
      const seen=new Set();for(const row of rows.filter(r=>r.access_transition===item.label)) if(!seen.has(row.chapter_id)&&seen.size<5){seen.add(row.chapter_id);detail.append(element('blockquote',{},'《'+row.chapter+'》第'+row.step+'步：'+row.quote),button('核对《'+row.chapter+'》路径',()=>{if(!reportDraft&&chooseChapter(row.chapter_id,true)) reveal('narrative-panel');}));}
      patterns.append(detail);
    }
    if(!common.length) patterns.append(element('p',{class:'muted'},'当前范围尚无涉及两篇以上的同类转移模式。'));
    const pages=Math.max(1,Math.ceil(rows.length/30));pathPage=Math.max(0,Math.min(pathPage,pages-1));
    message('path-page','第 '+(pathPage+1)+' / '+pages+' 页 · 共 '+rows.length+' 步');$('path-prev').disabled=pathPage===0;$('path-next').disabled=pathPage>=pages-1;
    const table=element('table'),head=element('tr');for(const label of ['篇目／步骤','人物','空间路径','类型／使用方式','参考地点','原文／修订']) head.append(element('th',{},label));table.append(head);
    for(const row of rows.slice(pathPage*30,pathPage*30+30)){const tr=element('tr'),path=row.from_space&&row.to_space?row.from_space+' → '+row.to_space:row.space||'未标明空间',evidence=element('td'),category=element('td'),a=row.classification.accessAiReviewed?'DeepSeek核查':row.classification.accessReviewed?'保存标注':'词汇线索，待核',r=row.classification.realmAiReviewed?'DeepSeek核查':row.classification.realmReviewed?'保存标注':'词汇线索，待核';category.append(element('span',{},pathKinds[row.transition_kind]||'待核'),element('p',{class:'muted'},row.classification.access+'（'+a+'） / '+row.classification.realm+'（'+r+'）'));evidence.append(element('blockquote',{},row.quote||'本步未附引句'),button('阅读与修订路径',()=>{if(!reportDraft&&chooseChapter(row.chapter_id,true)) reveal('narrative-panel');}));tr.append(element('td',{},'《'+row.chapter+'》第'+row.step+'步'),element('td',{},row.actors||'未标人物'),element('td',{},path),category,element('td',{},row.places.join('、')||'未匹配参考点'),evidence);table.append(tr);}
    if(!rows.length){const tr=element('tr');tr.append(element('td',{colspan:6},'当前范围暂无路径步骤。'));table.append(tr);}
    $('path-table').replaceChildren(table);
  }
  function reportEditor(row){
    const box=element('div',{class:'report-editor','data-report-editor':row.chapter_id+':'+row.key});
    box.append(element('p',{class:'muted'},'本行仅修改《'+model.view(row.chapter_id).chapter+'》'));
    if(row.rejection_reason) box.append(element('p',{class:'muted'},'已核对排除：'+row.rejection_reason));
    if(row.candidate?.context_review_note) box.append(element('p',{class:'muted'},'原文复核：'+row.candidate.context_review_note));
    const field=(name,label,value,options)=>{const wrap=element('label',{},label),input=element(options?'select':name==='note'?'textarea':'input',{'data-field':name,...(!options?{type:'text'}:{})});if(options) for(const [v,label] of options) input.append(element('option',{value:v},label));input.value=value;wrap.append(input);box.append(wrap);return input;};
    const word=field('word','修订词语',row.word),kind=field('kind','修订分类',row.kind,Object.entries(R.KINDS));
    const conclusion=field('status','判定',row.status==='rejected'?'rejected':'accepted',[['accepted','保留修订后的词'],['rejected','排除此词'],['pending','标为待核（保留现有数据）']]);
    const canonical=field('canonical','所指人物（单字人物必填）',row.person?.canonical||'');
    const types=element('div',{class:'checkboxes'});checkboxes(types,['人','鬼','妖','神'],Object.keys(row.person?.person_types||{}));box.append(types);
    const note=field('note','审核依据 / 修订说明',row.review?.note||row.person?.evidence||'');
    const toggle=()=>{canonical.parentNode.hidden=kind.value!=='people';types.hidden=kind.value!=='people';};toggle();kind.addEventListener('change',toggle);
    const context=element('blockquote',{},row.context||'请核对本篇原文后新增。');box.append(context);
    const controls=['report-kind','report-chapter','report-state','report-type','report-search','report-sort','report-view','report-prev','report-next','report-add'];
    const lock=value=>{reportDraft=value;reportActive=value?box:null;syncSaveStatus();for(const id of controls) $(id).disabled=value;for(const n of $('reports-screen').querySelectorAll('[data-report-picker]')) n.disabled=value;for(const other of $('reports-screen').querySelectorAll('[data-report-editor]')) if(other!==box) for(const tag of ['input','textarea','select','button']) for(const n of other.querySelectorAll(tag)) n.disabled=value;};
    box.addEventListener('input',()=>lock(true));box.addEventListener('change',()=>lock(true));
    const close=()=>{lock(false);$('report-new').replaceChildren();renderReports();};
    box.append(button('保存此行',()=>{
      if(state.dirty){message('report-status','请先保存或取消「文本与修订」中的草稿，再保存报表。',true);return;}
      try{
        const proposed=M.create(base);proposed.importDocument(model.document());
        const doc=R.revise(proposed,row,{word:word.value,kind:kind.value,status:conclusion.value,canonical:canonical.value,types:checked(types),note:note.value});
        const durable=persist(doc);lock(false);$('report-new').replaceChildren();reportRows=null;
        renderChapter();updateResults();renderReports();
        message('report-status',durable?'已保存《'+model.view(row.chapter_id).chapter+'》的修订，表格、地图与篇目数据已同步。':'已应用于当前页面；本机存储不可用，请下载总资料包。',!durable);
      }catch(error){message('report-status','未保存：'+error.message,true);}
    },'primary'),button('取消本行输入',close),button('阅读全文 / 修改分词',()=>{if(reportDraft){message('report-status','请先保存或取消本行输入。',true);return;}if(chooseChapter(row.chapter_id,true)) reveal('segmentation-panel');}));
    box.querySelector('button').setAttribute('data-report-save','');
    return box;
  }
  function renderReports(){
    if(reportDraft) return;
    $('report-new').replaceChildren();
    const ids=model.ids,old=$('report-chapter').value;
    $('report-chapter').replaceChildren(element('option',{value:''},'全书'),...ids.map(id=>element('option',{value:String(id)},'#'+(id+1)+' '+model.view(id).chapter)));$('report-chapter').value=old||'';
    const kind=$('report-kind').value||'spaces',chapter=$('report-chapter').value,q=model.simplify($('report-search').value||'').trim(),status=$('report-state').value||'active',type=$('report-type').value;
    $('report-type').disabled=kind!=='people';
    if($('report-type').parentNode) $('report-type').parentNode.hidden=kind!=='people';
    reportMatches=reportData().filter(r=>r.kind===kind && (!chapter||r.chapter_id===Number(chapter)) && (!q||[r.word,r.chapter,r.review?.note||''].some(s=>s.includes(q))) &&
      (status==='all'||status==='active'&&r.present||status==='pending'&&r.status==='pending'||status==='reviewed'&&(!!r.review||r.status==='removed')) &&
      (kind!=='people'||!type||(type==='unknown'?!Object.keys(r.person?.person_types||{}).length:r.person?.person_types?.[type]>0)));
    const sort=$('report-sort').value||'frequency';
    reportMatches.sort((a,b)=>sort==='word'?a.word.localeCompare(b.word,'zh')||a.chapter_id-b.chapter_id:sort==='chapter'?a.chapter_id-b.chapter_id||b.frequency-a.frequency:(b[sort]||0)-(a[sort]||0)||b.mentions-a.mentions||a.chapter_id-b.chapter_id);
    const grouped=R.aggregate(reportMatches), wordView=$('report-view').value==='words';
    if(sort==='word') grouped.sort((a,b)=>a.word.localeCompare(b.word,'zh'));
    if(sort==='mentions') grouped.sort((a,b)=>b.mentions-a.mentions);
    const displayed=wordView?grouped:reportMatches,pages=Math.max(1,Math.ceil(displayed.length/30));reportPage=Math.max(0,Math.min(reportPage,pages-1));
    $('report-summary').replaceChildren(...[reportMatches.length+' 条篇内记录',grouped.length+' 个不同词语',new Set(reportMatches.map(r=>r.chapter_id)).size+' 篇',grouped.reduce((s,r)=>s+r.frequency,0)+' 次完整分词命中'].map(t=>element('span',{class:'chip'},t)));
    reportBars($('report-frequency-chart'),[...grouped].sort((a,b)=>b.frequency-a.frequency).slice(0,12).map(g=>[g.word,g.frequency]));
    const categories=kind==='people'?['人','鬼','妖','神','未标注'].map(t=>[t,reportMatches.filter(r=>t==='未标注'?!Object.keys(r.person?.person_types||{}).length:r.person?.person_types?.[t]>0).length]):Object.entries(reportStatuses).map(([k,v])=>[v,reportMatches.filter(r=>r.status===k).length]);
    reportBars($('report-category-chart'),categories);renderPathReport();message('report-page','第 '+(reportPage+1)+' / '+pages+' 页 · 每页30条');$('report-prev').disabled=reportPage===0;$('report-next').disabled=reportPage>=pages-1;
    const body=$('report-list');body.replaceChildren();
    for(const row of displayed.slice(reportPage*30,reportPage*30+30)){
      const tr=element('tr',{'data-report-row':row.chapter_id+':'+row.key});
      if(wordView){
        const members=reportMatches.filter(r=>r.word===row.word),cell=element('td'),details=element('details'),summary=element('summary',{},'选择篇目并修改'),picker=element('select',{'aria-label':'选择'+row.word+'的篇目','data-report-picker':''}),editor=element('div');
        picker.append(...members.map((r,i)=>element('option',{value:String(i)},'#'+(r.chapter_id+1)+' '+r.chapter+' · '+reportStatuses[r.status])));picker.value='0';
        const load=()=>{if(reportDraft){message('report-status','请先保存或取消正在编辑的行。',true);return;}editor.replaceChildren(reportEditor(members[Number(picker.value)||0]));};
        picker.addEventListener('change',load);summary.addEventListener('click',()=>{if(!editor.children.length) load();});
        details.append(summary,picker,editor);cell.append(details);
        tr.append(element('td',{},row.word),element('td',{},row.chapters+' 篇'),element('td',{},String(row.frequency)),element('td',{},String(row.mentions)),element('td',{},R.KINDS[row.kind]+' · 按篇核对'),cell);body.append(tr);continue;
      }
      tr.append(element('td',{},row.word),element('td',{},'#'+(row.chapter_id+1)+' '+row.chapter),element('td',{},String(row.frequency)),element('td',{},String(row.mentions)),element('td',{},R.KINDS[row.kind]+' · '+(row.person?Object.keys(row.person.person_types||{}).join('／')+' · ':'')+reportStatuses[row.status]));
      const cell=element('td'),detail=element('details');detail.append(element('summary',{},'核对与修改'),reportEditor(row));
      if(row.candidate?.ai_review) detail.append(element('p',{class:'muted'},'AI参考：'+row.candidate.ai_review.label+'；'+(row.candidate.ai_review.evidence||'')));
      if(row.rejection_reason) detail.append(element('p',{class:'muted'},'排除依据：'+row.rejection_reason));
      cell.append(detail,button('打开原文',()=>{if(!reportDraft&&chooseChapter(row.chapter_id,true)) reveal('workspace');}));
      if(row.kind==='places') cell.append(button('定位与层级',()=>{if(!reportDraft && row.present) openLocation(row.word);else message('report-status','请先保留此地点词，再补充定位。',true);}));
      tr.append(cell);body.append(tr);
    }
    if(!reportMatches.length){const tr=element('tr');tr.append(element('td',{colspan:6},'当前条件没有数据；可切换「待核候选」或选择其他篇目。'));body.append(tr);}
  }
  for(const id of ['report-kind','report-chapter','report-state','report-type','report-sort','report-view']) $(id).addEventListener('change',()=>{reportPage=0;renderReports();});
  $('report-search').addEventListener('input',()=>{reportPage=0;renderReports();});
  $('path-scope').addEventListener('change',renderPathReport);
  $('path-metric').addEventListener('change',renderPathReport);
  $('path-search').addEventListener('input',renderPathReport);
  for(const [id,step] of [['path-prev',-1],['path-next',1]]) $(id).addEventListener('click',()=>{pathPage+=step;renderPathReport();});
  $('path-export').addEventListener('click',()=>{
    if(reportDraft){message('report-status','请先保存或取消本行输入，再导出路径。',true);return;}
    const safe=v=>'"'+String(v??'').replace(/^[=+@-]/,"'$&").replace(/"/g,'""')+'"';
    const lines=[['篇号','篇名','步骤','人物','出发空间','到达空间','场景','步骤类型','使用方式','世界分类','分类依据','参考地点','边界／媒介','空间叙事功能','原文','稳定步骤标识','出发使用方式','出发世界','出发类型','到达类型','双端证据'],...pathMatches.map(r=>[r.chapter_id+1,r.chapter,r.step,r.actors,r.from_space,r.to_space,r.space,pathKinds[r.transition_kind]||'待核',r.classification.access,r.classification.realm,'使用方式：'+r.classification.accessStatus+'；世界：'+r.classification.realmStatus,r.places.join('、'),r.boundary_medium||'',r.narrative_role||'',r.quote,r.step_id,r.from_access,r.from_realm,r.from_type,r.to_type,r.endpoint_review?.reason||''])];
    const url=URL.createObjectURL(new Blob(['\ufeff'+lines.map(r=>r.map(safe).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));const a=element('a',{href:url,download:'聊斋空间路径.csv'});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  for(const [id,step] of [['report-prev',-1],['report-next',1]]) $(id).addEventListener('click',()=>{reportPage+=step;renderReports();});
  $('report-add').addEventListener('click',()=>{const id=$('report-chapter').value;if(id===''){message('report-status','请先选择要新增词语的具体篇目。',true);return;}$('report-new').replaceChildren(reportEditor({chapter_id:Number(id),kind:$('report-kind').value||'spaces',key:($('report-kind').value||'spaces')+':新增',word:'',status:'pending'}));});
  window.addEventListener('beforeunload',e=>{if(reportDraft){e.preventDefault();e.returnValue='';}});
  $('report-export').addEventListener('click',()=>{
    if(reportDraft){message('report-status','请先保存或取消本行输入，再导出表格。',true);return;}
    const safe=v=>'"'+String(v??'').replace(/^[=+@-]/,"'$&").replace(/"/g,'""')+'"';
    const grouped=R.aggregate(reportMatches),sort=$('report-sort').value;
    if(sort==='word') grouped.sort((a,b)=>a.word.localeCompare(b.word,'zh'));if(sort==='mentions') grouped.sort((a,b)=>b.mentions-a.mentions);
    const lines=$('report-view').value==='words' ? [['词语','类别','篇数','分词词频','原文次数'],...grouped.map(r=>[r.word,R.KINDS[r.kind],r.chapters,r.frequency,r.mentions])] :
      [['词语','类别','篇号','篇名','分词词频','原文次数','人物序列','审核状态','原文片段'],...reportMatches.map(r=>[r.word,R.KINDS[r.kind],r.chapter_id+1,r.chapter,r.frequency,r.mentions,Object.keys(r.person?.person_types||{}).join('／'),reportStatuses[r.status],r.context])];
    const url=URL.createObjectURL(new Blob(['\ufeff'+lines.map(r=>r.map(safe).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));const a=element('a',{href:url,download:'聊斋数据报表.csv'});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  });
  $('report-locations').addEventListener('click',()=>{
    const container=$('report-reference');container.replaceChildren();const table=element('table'),head=element('tr');for(const s of ['地点','现代参考 / 区域','层级','坐标','修改']) head.append(element('th',{},s));table.append(head);
    const words=[...new Set(reportData().filter(r=>r.kind==='places'&&r.present).map(r=>r.word))].sort((a,b)=>a.localeCompare(b,'zh'));
    for(const word of words){const p=model.placeInfo(word),tr=element('tr');tr.append(element('td',{},word),element('td',{},p.modern_name+' '+p.region_description),element('td',{},M.LEVELS[p.admin_level]),element('td',{},p.lon===null?'未定位':p.lon+', '+p.lat));const td=element('td');td.append(button('修改定位',()=>openLocation(word)));tr.append(td);table.append(tr);}container.append(table);
  });
  $('report-dates').addEventListener('click',()=>{
    const container=$('report-reference');container.replaceChildren(element('p',{class:'muted'},'以下为有来源的纪年换算基线；原标注地点与时间性质仍需对照当前篇目修订核对。'));
    const table=element('table'),head=element('tr');for(const s of ['公元年 / 范围','时间词','篇目','原标注地点','时间性质 / 原文证据','修改']) head.append(element('th',{},s));table.append(head);
    const chapter=$('report-chapter').value;
    for(const r of (base.chronology?.records||[]).filter(r=>!chapter||r.chapter_id===Number(chapter))){const tr=element('tr'),td=element('td');
      td.append(button('核对时间词',()=>{if(!reportDraft&&chooseChapter(r.chapter_id,true)) reveal('time-panel');}));
      tr.append(element('td',{},r.date_label),element('td',{},r.expression),element('td',{},r.chapter),element('td',{},(r.places||[]).join('、')),element('td',{},dateRole(r)+'；'+r.excerpt),td);table.append(tr);
    }container.append(table);
  });
  function updateResults() {
    reportRows = null;
    pathRowsCache = null;
    if (!$('reports-screen').hidden) renderReports();
    const places = currentPlaces().sort((a,b)=>G.levelRank(a)-G.levelRank(b) || a.name.localeCompare(b.name,'zh'));
    const symbols={province:'◇ ',settlement:'○ ',natural:'△ ',cultural:'□ ',ambiguous:'□ '};
    $('place-select').replaceChildren(element('option', {value: ''}, '选择地点'), ...places.map(p => element('option', {value: p.id}, (symbols[p.scale_category] || '')+p.name + '〔'+(p.level_label || M.LEVELS[G.placeLevel(p)])+(p.location_audit?.status==='ambiguous'?'；同名待核':'')+'〕 · ' + p.chapters.length + ' 篇')));
    $('place-select').value = state.place || '';
    const missing = unmappedPlaces().length;
    $('overview').replaceChildren(...[model.ids.length + ' 篇原文', allPlaces().length + ' 个地名参考点', missing + ' 个未定位地点词',
      (base.chronology?.records.length || 0) + ' 条纪年', model.document().overrides.length + ' 篇人工修订'].map(s => element('span', {class: 'chip'}, s)));
    $('overview').append(button('审核未定位地点',()=>reveal('unmapped-panel'),'chip'));
    if(state.place && !allPlaces().some(p=>p.id===state.place)) state.place=null;
    refreshLocationOptions(); refreshChronologyPlaces();
    renderMovement(); renderPlace(); renderRealms(); resize(); paintMap(); unmappedList(); renderResearch(model.view(state.chapter)); renderBookSynthesis();
  }
  $('place-select').addEventListener('change', () => choosePlace($('place-select').value));
  $('map-search').addEventListener('input', updateResults);
  $('event-filter').addEventListener('change', updateResults);
  $('place-layer').addEventListener('change',()=>{
    const selected=allPlaces().find(p=>p.id===state.place);
    if(selected && !matchesLayer(selected)) {
      state.place=null; $('chronology-place').value=''; renderChronology();
    }
    updateResults();
  });
  $('place-count-scope').addEventListener('change',()=>{updateResults();renderChronology();});
  $('unmapped-search').addEventListener('input', unmappedList);
  $('candidate-kind').addEventListener('change', () => { state.candidatePage = 0; renderCandidateList(); });
  $('candidate-search').addEventListener('input', () => { state.candidatePage = 0; renderCandidateList(); });
  for (const [id, step] of [['candidate-prev', -1], ['candidate-next', 1]]) $(id).addEventListener('click', () => {
    state.candidatePage += step; renderCandidateList(); $('candidate-list').scrollTop = 0;
  });
  $('clear-map-filters').addEventListener('click', () => {
    $('map-search').value = ''; $('event-filter').value = ''; state.place = null;
    $('place-layer').value=''; $('place-count-scope').value='direct';
    $('chronology-place').value = ''; renderChronology(); updateResults();
  });
  $('show-labels').addEventListener('change', paintMap);
  $('show-region-boundaries').addEventListener('change', () => { drawBackground(); paintMap(); });

  // Geographic geometry is transformed separately from fixed screen-space controls.
  const map = $('map'), defs = svg('defs'), clip = svg('clipPath', {id: 'geo-clip'}), clipRect = svg('rect');
  clip.append(clipRect); defs.append(clip); map.append(defs);
  const clipped = svg('g', {'clip-path': 'url(#geo-clip)'}), scene = svg('g', {class: 'geo-scene', 'pointer-events': 'none'});
  const graticule = svg('g', {stroke: '#d0dbd0', 'stroke-width': '.6', fill: 'none'}), countries = svg('g', {stroke: '#98aea0', 'stroke-width': '.8', fill: '#dfe8da'}), regionBoundaries = svg('g', {class: 'region-boundaries', 'pointer-events': 'none'});
  scene.append(countries, regionBoundaries, graticule); clipped.append(scene); map.append(clipped);
  const routes = svg('g', {class: 'realm-link-layer', 'pointer-events': 'none'}), leaders = svg('g', {'pointer-events': 'none'}), labels = svg('g', {'pointer-events': 'none'}), points = svg('g', {class: 'point-layer'}), hubs = svg('g', {class: 'realm-hub'});
  const movementLayer=svg('g',{class:'movement-layer','clip-path':'url(#geo-clip)','pointer-events':'none'});
  const arrow=svg('marker',{id:'movement-arrow',viewBox:'0 0 10 10',refX:9,refY:5,markerWidth:5,markerHeight:5,orient:'auto-start-reverse'});arrow.append(svg('path',{d:'M0,0 L10,5 L0,10 Z',fill:'#243d39'}));defs.append(arrow);
  const movementDiagram=svg('g',{class:'movement-diagram',role:'group','aria-label':'篇内空间示意，非地理坐标'});
  map.append(routes, movementLayer, leaders, labels, points, hubs,movementDiagram);
  const drawWidth = () => Math.max(200, state.width - 96);
  const path = coords => coords.map((coord, i) => (i ? 'L' : 'M') + projection(coord).join(',')).join('');
  function drawBackground() {
    countries.replaceChildren(...rings.map(ring => svg('path', {d: path(ring) + 'Z', 'vector-effect': 'non-scaling-stroke'})));
    regionBoundaries.replaceChildren(...($('show-region-boundaries').checked ? regionRings.map((ring, index) => {
      const boundary = svg('path', {class: 'region-boundary', d: path(ring), fill: 'none', 'vector-effect': 'non-scaling-stroke', 'data-region-boundary': String(index)});
      boundary.append(svg('title', {}, '省域参考虚线（阿里云 DataV 现代省界，非清代疆界）'));
      return boundary;
    }) : []));
    const lines = [];
    for (let lon = 75; lon <= 140; lon += 5) lines.push(Array.from({length: 46}, (_, i) => [lon, i + 10]));
    for (let lat = 10; lat <= 55; lat += 5) lines.push(Array.from({length: 66}, (_, i) => [i + 75, lat]));
    graticule.replaceChildren(...lines.map(coords => svg('path', {d: path(coords), 'vector-effect': 'non-scaling-stroke'})));
  }
  function arc(type) {
    const index = M.EVENTS.indexOf(type), step = 360 / M.EVENTS.length, start = (index * step + 4) * Math.PI / 180, end = ((index + 1) * step - 4) * Math.PI / 180, radius = 9;
    const a = [Math.sin(start) * radius, -Math.cos(start) * radius], b = [Math.sin(end) * radius, -Math.cos(end) * radius];
    return 'M' + a.join(',') + 'A9,9 0 0 1 ' + b.join(',');
  }
  function paintMap() {
    if (!projection) return;
    scene.setAttribute('transform', 'translate(' + state.transform.x + ',' + state.transform.y + ') scale(' + state.transform.k + ')');
    $('zoom-value').textContent = state.transform.k.toFixed(1) + '×';
    $('zoom-in').disabled = state.transform.k >= 12; $('zoom-out').disabled = state.transform.k <= 1;
    const matched = currentPlaces();
    const expandAll = Boolean($('place-layer').value || $('map-search').value.trim());
    const visible = G.visiblePoints(matched.map(p => ({...p, xy: projection([p.lon, p.lat])})), state.transform, drawWidth(), state.height, state.place,{expandAll});
    const scope = expandAll ? '显示所选层级／搜索结果。' : state.transform.k < 1.8 ? '总览：省域与文化区域。' : state.transform.k < 3 ? '展开至府／州与山川。' : state.transform.k < 5 ? '展开至县／散州。' : '展开至村镇与待核层级。';
    message('map-count', scope+' 当前显示 ' + visible.length + ' 个地点，符合筛选的共 ' + matched.length + ' 个。搜索或选单可直接选择下级地点。' +
      ' 当前统计：'+(aggregatePlaces()?'区域汇总（含已关联下级地点）。':'直接提及篇目。'));
    const ids = new Set(visible.map(p => p.id));
    for (const [id, node] of pointNodes) if (!ids.has(id)) { node.remove(); pointNodes.delete(id); }
    leaders.replaceChildren();
    for (const p of visible) {
      let node = pointNodes.get(p.id);
      if (!node) {
        node = svg('g', {class: 'map-point', role: 'button', tabindex: '0'});
        node.append(svg('title'), svg('circle', {class: 'core', r: 5, stroke: '#fff', 'stroke-width': 1.5}));
        for (const type of M.EVENTS) node.append(svg('path', {'data-type': type, d: arc(type), stroke: G.COLORS[type], 'stroke-width': 3, fill: 'none', 'pointer-events': 'none'}));
        node.append(svg('path',{class:'scale-symbol',stroke:'#fff','stroke-width':1.5}));
        node.append(svg('circle', {class: 'hit', r: 13}));
        node.addEventListener('click', event => { event.stopPropagation(); if (!suppressClick) choosePlace(p.id); });
        node.addEventListener('keydown', event => {
          if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); choosePlace(p.id); }
        });
        pointNodes.set(p.id, node); points.append(node);
      }
      node.setAttribute('transform', 'translate(' + p.display.join(',') + ')');
      const types = M.EVENTS.filter(t => p.chapters.some(c => c.event_types[t] > 0));
      node.setAttribute('aria-label', p.name + '，'+(p.level_label || M.LEVELS[G.placeLevel(p)])+(p.location_audit?.status==='ambiguous'?'，同名位置待核':'')+'，' + p.chapters.length + '篇，异事类型：' + (types.join('、') || '未标记'));
      node.setAttribute('aria-pressed', String(state.place === p.id)); node.querySelector('title').textContent = node.getAttribute('aria-label');
      node.querySelector('.core').setAttribute('fill', state.place === p.id ? '#152d29' : '#82998c');
      node.querySelector('.core').setAttribute('r', G.levelRank(p) <= 2 ? 6 : G.levelRank(p) === 3 ? 4.5 : 3);
      const symbol=node.querySelector('.scale-symbol'), category=p.scale_category || 'settlement';
      symbol.setAttribute('d',category==='province'?'M0,-5.5 L5.5,0 L0,5.5 L-5.5,0 Z':category==='natural'?'M0,-5.5 L5,3.5 L-5,3.5 Z':'M-4,-4 H4 V4 H-4 Z');
      symbol.setAttribute('fill',state.place===p.id?'#152d29':'#82998c');symbol.style.display=category==='settlement'?'none':'';
      node.querySelector('.core').style.display=category==='settlement'?'':'none';
      for (const type of M.EVENTS) node.querySelector('[data-type="' + type + '"]').style.display = types.includes(type) ? '' : 'none';
      if (Math.hypot(p.anchor[0] - p.display[0], p.anchor[1] - p.display[1]) > 1) leaders.append(svg('line', {x1: p.anchor[0], y1: p.anchor[1], x2: p.display[0], y2: p.display[1], stroke: '#789485', 'stroke-width': 1}));
    }
    const placeLabels=$('show-labels').checked ? G.labels(visible,drawWidth(),state.height,state.place):[];
    labels.replaceChildren(...placeLabels.map(l=>{
      const group=svg('g',{class:'place-label',role:'button',tabindex:'0','data-place-label':l.id,'aria-label':'地名标签：'+l.text,'aria-pressed':String(state.place===l.id),'pointer-events':'all'});
      group.append(svg('rect',{x:l.rect[0],y:l.rect[1],width:l.rect[2],height:l.rect[3],fill:'transparent','pointer-events':'all'}),svg('text',{class:'map-label',x:l.x,y:l.y},l.text));
      group.addEventListener('click',event=>{event.stopPropagation();if(!suppressClick)choosePlace(l.id);});
      group.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();choosePlace(l.id);}});
      if(l.leader) leaders.append(svg('line',{class:'label-leader','data-label-for':l.id,x1:l.leader.from[0],y1:l.leader.from[1],x2:l.leader.to[0],y2:l.leader.to[1],stroke:'#526f61','stroke-width':1.2}));
      return group;
    }));
    hubs.replaceChildren(svg('text', {x: drawWidth() + 9, y: 82}, '文本三界'));
    const anchors = {天界: [state.width - 48, state.height * .28], 地界: [state.width - 48, state.height * .75]};
    const place = allPlaces().find(p => p.id === state.place), source = visible.find(p => p.id === state.place);
    const links = place ? model.links(place, new Set(filteredChapters(place).map(c => c.chapter_id))) : globalRealmLinks();
    routes.replaceChildren();
    movementLayer.replaceChildren();
    movementDiagram.replaceChildren();
    const mode=movementMode();
    const current=movementRows.find(r=>r.chapter_id+':'+r.index===$('movement-step').value);
    const routeAnnotations=[], namedEndpoints=new Set(placeLabels.map(l=>l.id));
    const addEndpoint=(place,xy,color,priority=2)=>{
      if(namedEndpoints.has(place.id)) return;
      namedEndpoints.add(place.id);routeAnnotations.push({id:'endpoint-'+place.id,text:place.name,anchor:xy,color,priority,title:place.name+'（区域参考点）'});
    };
    if(current) {
      for(const place of [current.from,current.to].filter(Boolean)) {
        const xy=projection([place.lon,place.lat]).map((v,i)=>v*state.transform.k+(i?state.transform.y:state.transform.x));
        movementLayer.append(svg('circle',{cx:xy[0],cy:xy[1],r:7,fill:'#fff',stroke:N.color(current.chapter_id),'stroke-width':3}));
        addEndpoint(place,xy,N.color(current.chapter_id),3);
      }
      const w=drawWidth()-20,y=state.height-108;
      movementDiagram.append(svg('rect',{x:10,y,width:w,height:100,rx:8,fill:'#fff',stroke:'#94aaa0',opacity:.96}));
      movementDiagram.append(svg('text',{x:20,y:y+18,'font-size':12},'篇内空间示意（非坐标） · 《'+current.chapter+'》第'+(current.index+1)+'步'));
      const summary=current.from_space+' → '+current.to_space;
      movementDiagram.append(svg('text',{x:20,y:y+43,'font-size':14},summary.slice(0,Math.max(15,Math.floor(w/14)))));
      const caption=current.actorsList.join('、')+' · '+current.classification.access+' / '+current.classification.realm+'（未人工标注者待核）';
      movementDiagram.append(svg('text',{x:20,y:y+65,'font-size':12},caption.slice(0,Math.max(15,Math.floor(w/12)))));
      const view=svg('g',{role:'button',tabindex:0,'aria-label':'查看此步原文与空间解读','pointer-events':'all'});
      view.append(svg('rect',{x:18,y:y+72,width:170,height:23,rx:3,fill:'#e6eee8'}),svg('text',{x:24,y:y+88,'font-size':12},'查看此步原文与空间解读'));
      const open=()=>{
        const panel=$('movement-path-panel');panel.open=true;
        let card=$('movement-paths').querySelector('[data-movement-row="'+current.chapter_id+':'+current.index+'"]');
        if(!card) {card=element('details',{'data-movement-row':current.chapter_id+':'+current.index});card.append(element('summary',{},'《'+current.chapter+'》第'+(current.index+1)+'步 '+current.actorsList.join('、')),element('p',{},current.from_space+' → '+current.to_space),element('p',{},current.event),element('p',{},current.classification.interpretation),element('blockquote',{},current.quote));$('movement-paths').append(card);}
        card.open=true;card.scrollIntoView({block:'start'});
      };view.addEventListener('click',open);view.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}});movementDiagram.append(view);
    }
    for(const [index,row] of movementRows.filter(r=>r.transition_kind==='movement' && r.from && r.to).entries()) {
      const a=projection([row.from.lon,row.from.lat]).map((v,i)=>v*state.transform.k+(i?state.transform.y:state.transform.x));
      const b=projection([row.to.lon,row.to.lat]).map((v,i)=>v*state.transform.k+(i?state.transform.y:state.transform.x));
      const color=N.color(mode==='place'?row.chapter_id:$('movement-actor').value || row.chapter_id+'|'+row.actorsList.join('、'));
      const control=[(a[0]+b[0])/2,(a[1]+b[1])/2-12-(index%4)*6];
      const line=svg('path',{class:'character-route',role:'button',tabindex:0,'aria-label':'《'+row.chapter+'》第'+(row.index+1)+'步 '+row.actorsList.join('、')+' '+row.from_space+'到'+row.to_space,'pointer-events':'stroke',d:'M'+a.join(',')+' Q'+((a[0]+b[0])/2)+','+((a[1]+b[1])/2-12-(index%4)*6)+' '+b.join(','),fill:'none',stroke:color,'stroke-width':row.route_scope==='descendant'?1.8:2.8,'stroke-dasharray':row.route_scope==='descendant'?'7 5':'none','opacity':row.route_scope==='descendant' ? .76 : 1,'marker-end':'url(#movement-arrow)'});
      const selectRoute=()=>{if(!suppressClick && chooseChapter(row.chapter_id)){$('movement-step').value=row.chapter_id+':'+row.index;paintMap();}};
      line.addEventListener('click',e=>{e.stopPropagation();selectRoute();});line.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();selectRoute();}});
      line.append(svg('title',{},'《'+row.chapter+'》 第'+(row.index+1)+'步 '+row.actorsList.join('、')+'：'+row.from_space+' → '+row.to_space+'；'+row.quote));movementLayer.append(line);
      for(const [point,place] of [[a,row.from],[b,row.to]]) {
        movementLayer.append(svg('circle',{cx:point[0],cy:point[1],r:4,fill:color}));
        addEndpoint(place,point,color);
      }
      const actorText=row.actorsList.join('、')||'人物待核',actorChars=[...actorText],actorLines=[];
      for(let i=0;i<actorChars.length;i+=16) actorLines.push(actorChars.slice(i,i+16).join(''));
      routeAnnotations.push({id:row.chapter_id+':'+row.index,text:(row.route_scope==='descendant'?'下辖 · ':'')+'《'+row.chapter+'》 · '+actorText,lines:[(row.route_scope==='descendant'?'下辖 · ':'')+'《'+row.chapter+'》',...actorLines],anchor:[(a[0]+2*control[0]+b[0])/4,(a[1]+2*control[1]+b[1])/4],color,priority:row===current?4:1,title:(row.route_scope==='descendant'?'下辖地点路线；':'直接地点路线；')+'《'+row.chapter+'》 第'+(row.index+1)+'步 '+actorText+'：'+row.from_space+' → '+row.to_space,select:selectRoute});
    }
    const obstacles=[...placeLabels.map(l=>l.rect),...visible.map(p=>[p.display[0]-9,p.display[1]-9,18,18]),[0,0,240,54]];
    for(const row of movementRows.filter(r=>r.transition_kind==='movement')) for(const place of [row.from,row.to].filter(Boolean)){const xy=G.screen(projection([place.lon,place.lat]),state.transform);obstacles.push([xy[0]-9,xy[1]-9,18,18]);}
    if(current) obstacles.push([10,state.height-108,drawWidth()-20,100]);
    const routeLayout=G.routeLabels(routeAnnotations,drawWidth(),state.height,obstacles);
    const annotationLeaders=svg('g',{'pointer-events':'none'});movementLayer.append(annotationLeaders);
    for(const label of routeLayout){
      const group=svg('g',{class:'route-annotation','data-route-label':label.id,'data-label-rect':label.rect.join(','),...(label.select?{role:'button',tabindex:0,'pointer-events':'all','aria-label':label.title}:{'pointer-events':'none'})});
      annotationLeaders.append(svg('line',{x1:label.anchor[0],y1:label.anchor[1],x2:label.edge[0],y2:label.edge[1],stroke:label.color,'stroke-width':1,opacity:.7}));
      const text=svg('text',{x:label.x,y:label.y,'font-size':12,fill:label.color});
      label.lines.forEach((line,i)=>text.append(svg('tspan',{x:label.x,y:label.y+i*16},line)));
      group.append(svg('title',{},label.title),svg('rect',{x:label.rect[0],y:label.rect[1],width:label.rect[2],height:label.rect[3],rx:4,fill:'#fff',stroke:label.color,'stroke-width':1}),text);
      if(label.select){group.addEventListener('click',e=>{e.stopPropagation();label.select();});group.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();label.select();}});}
      movementLayer.append(group);
    }
    message('route-label-status',routeAnnotations.length>routeLayout.length?'拥挤或视野外的部分标注已暂时隐藏；放大地图可展开，悬停或点选路线仍可查看篇目与步骤。':'');
    for (const realm of ['天界', '地界']) {
      const relevant = links.filter(e => e.realm === realm), [x, y] = anchors[realm], group = svg('g', {class: 'realm-hub', role: 'button', tabindex: 0, 'aria-label': '查看' + realm + '原文证据', transform: 'translate(' + x + ',' + y + ')'});
      const openRealm = () => $(realm === '天界' ? 'realm-sky' : 'realm-underworld').scrollIntoView({behavior: 'smooth', block: 'nearest'});
      group.addEventListener('click', openRealm);
      group.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openRealm(); } });
      group.append(svg('rect', {x: -36, y: -24, width: 72, height: 64, rx: 8, fill: realm === '天界' ? '#dfebe2' : '#ece2f5', stroke: '#a8b9ab'}), svg('text', {x: 0, y: -2, 'text-anchor': 'middle'}, realm), svg('text', {x: 0, y: 20, 'text-anchor': 'middle'}, new Set(relevant.map(e => e.space)).size + ' 证据词'));
      hubs.append(group);
      if (!source || !relevant.length) continue;
      // Separate confirmed chapter-level crossings from mere lexical co-occurrence.
      for (const kind of ['mention', 'crossing']) {
        if (!relevant.some(e => e.review.kind === kind)) continue;
        const sy = source.display[1] + (kind === 'crossing' ? 3 : -3), ty = y + (kind === 'crossing' ? 5 : -5);
        routes.append(svg('path', {class: 'realm-link', d: 'M' + source.display[0] + ',' + sy + 'Q' + (source.display[0] + x) / 2 + ',' + sy + ' ' + (x - 38) + ',' + ty,
          stroke: realm === '天界' ? '#24745e' : '#79519c', 'stroke-dasharray': kind === 'mention' ? '5 5' : 'none'}));
      }
    }
  }
  function resize() {
    if ($('map-section').hidden) return;
    const width = Math.max(300, map.clientWidth), height = Math.max(320, map.clientHeight);
    const placeSignature=JSON.stringify(allPlaces().map(p=>[p.id,p.lon,p.lat]));
    if (width === state.width && height === state.height && placeSignature===projectionPlaces) return;
    projectionPlaces=placeSignature;
    const center = projection ? projection.invert([(drawWidth() / 2 - state.transform.x) / state.transform.k, (state.height / 2 - state.transform.y) / state.transform.k]) : null;
    state.width = width; state.height = height; map.setAttribute('viewBox', '0 0 ' + width + ' ' + height);
    clipRect.setAttribute('width', drawWidth()); clipRect.setAttribute('height', height);
    projection = G.projection(allPlaces().length?allPlaces().map(p => [p.lon, p.lat]):[[75,10],[140,55]], drawWidth(), height, 36);
    if (center) { const p = projection(center); state.transform.x = drawWidth() / 2 - p[0] * state.transform.k; state.transform.y = height / 2 - p[1] * state.transform.k; }
    drawBackground(); paintMap();
  }
  function mapXY(event) {
    const rect = map.getBoundingClientRect(); return [(event.clientX - rect.left) * state.width / rect.width, (event.clientY - rect.top) * state.height / rect.height];
  }
  map.addEventListener('click',event=>{
    if(!pickingLocation || suppressClick || !projection) return;
    const point=mapXY(event);if(point[0]>drawWidth()) return;
    event.preventDefault();event.stopPropagation();event.stopImmediatePropagation?.();
    const [lon,lat]=projection.invert([(point[0]-state.transform.x)/state.transform.k,(point[1]-state.transform.y)/state.transform.k]);
    $('location-lon').value=lon.toFixed(5);$('location-lat').value=lat.toFixed(5);$('location-kind').value='approximate';
    if(!$('location-note').value) $('location-note').value='人工在地图上选择的区域近似点；县域与古代边界待核。';
    locationDirty=true;pickingLocation=false;$('cancel-pick-location').hidden=true;map.style.cursor='';
    $('location-coordinates').open=true;reveal('location-panel');message('location-status','已选近似位置，请核对区域说明后保存定位信息。');
  },true);
  map.addEventListener('wheel', event => {
    if (event.ctrlKey) return;
    const anchor = mapXY(event); if (anchor[0] > drawWidth()) return;
    event.preventDefault(); state.transform = G.zoomAt(state.transform, Math.exp(-event.deltaY * .0015), anchor); paintMap();
  }, {passive: false});
  map.addEventListener('pointerdown', event => {
    if (event.button !== 0 || mapXY(event)[0] > drawWidth()) return;
    suppressClick = false; drag = {id: event.pointerId, start: mapXY(event), transform: {...state.transform}, moved: false};
  });
  window.addEventListener('pointermove', event => {
    if (!drag || event.pointerId !== drag.id) return;
    const point = mapXY(event), dx = point[0] - drag.start[0], dy = point[1] - drag.start[1];
    if (Math.hypot(dx, dy) > 4) drag.moved = true;
    if (drag.moved) { suppressClick = true; state.transform = {...drag.transform, x: drag.transform.x + dx, y: drag.transform.y + dy}; paintMap(); }
  });
  const endDrag = event => { if (drag && drag.id === event.pointerId) { suppressClick = drag.moved; drag = null; } };
  window.addEventListener('pointerup', endDrag); window.addEventListener('pointercancel', endDrag);
  for (const [id, factor] of [['zoom-in', 1.5], ['zoom-out', 1 / 1.5]]) $(id).addEventListener('click', () => {
    suppressClick = false; state.transform = G.zoomAt(state.transform, factor, [drawWidth() / 2, state.height / 2]); paintMap();
  });
  $('fit-map').addEventListener('click', () => { suppressClick = false; state.transform = {k: 1, x: 0, y: 0}; paintMap(); });
  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(resize).observe(map);
  else window.addEventListener('resize', resize);
  renderChapter(); showEditor(currentEditor); renderBookSynthesis(); unmappedList(); renderCandidateList(); renderChronology(); resize(); updateResults();
  showScreen('map-section'); routeHash();

  // Optional backgrounds only. No CDN script is needed for interaction or editing.
  // The province layer is a modern reference outline; it must never be read as
  // a reconstruction of Qing administrative borders.
  const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 10000);
  const regionController = new AbortController(), regionTimeout = setTimeout(() => regionController.abort(), 10000);
  const worldLoad = fetch('https://cdn.jsdelivr.net/npm/world-atlas@2.0.2/countries-110m.json', {signal: controller.signal})
    .then(response => { if (!response.ok) throw new Error('背景边界载入失败'); return response.json(); })
    .then(topology => { rings = G.topologyRings(topology); backgroundReady = true; drawBackground(); })
    .catch(() => { backgroundReady = false; });
  const regionLoad = fetch('https://geo.datav.aliyun.com/areas_v3/bound/geojson?code=100000_full', {signal: regionController.signal})
    .then(response => { if (!response.ok) throw new Error('省域边界载入失败'); return response.json(); })
    .then(geojson => {
      regionRings = G.geoJSONRings(geojson);
      if (!regionRings.length) throw new Error('省域边界为空');
      regionBoundaryReady = true; regionBoundaryRemote = true; drawBackground();
    })
    .catch(() => { regionBoundaryReady = regionRings.length > 0; regionBoundaryRemote = false; drawBackground(); });
  Promise.allSettled([worldLoad, regionLoad]).then(() => {
    clearTimeout(timeout); clearTimeout(regionTimeout);
    message('map-status', (backgroundReady ? '背景国界已载入（现代示意）。' : '背景国界未载入；已使用经纬网离线模式。') +
      (regionBoundaryReady ? ' 省域虚线已载入（阿里云 DataV 现代省界，本地副本可离线使用）；不是清代疆界。' : ' 省域虚线暂未载入；地点、路线与地名仍可使用。') +
      ' 地点及地名文字均可点击；细线连接标签与地点。');
  });
})();
