"""Display historical reference levels with separately attributed containment.

Keep lexical chapter membership and modern spatial aggregation independent.
Ambiguous geography is deliberately not forced into a hierarchy.
"""
from audit_place_locations import LEVEL_NAMES, RANK, NORMAL
LABELS = {'province':'省域参考', 'settlement':'城镇／府县名（历史层级待核）',
          'natural':'山川水域', 'cultural':'文化地理区域', 'ambiguous':'地名／水域歧义待核'}
PROVINCES = {'山东','湖南','河南','江西','陕西','云南'}
SOURCES = {
    '山东':'https://tjj.jl.gov.cn/tjsj/tjbz/200805/t20080520_5118059.html',
    '河南':'https://tjj.jl.gov.cn/tjsj/tjbz/200805/t20080520_5118059.html',
    '湖南':'https://hunan.gov.cn/hnszf/jxxx/szmp/zss/szmp.html',
    '江西':'https://www.nc.gov.cn/ncszf/mjls/2021_nav_wztt.shtml',
    '陕西':'https://wap.miit.gov.cn/ztzl/lszt/gjgyyxzdlxcs/csmd/art/2020/art_bffe0a42c2344d86a8308f3ed093ca43.html',
}
MEMBERS = {
    '山东':['济南','青州','诸城','胶州','泰安','莱芜','临朐','淄川','莱州','东昌','安丘','沂水','长山'],
    '湖南':['长沙'], '河南':['南阳','洛阳'], '江西':['南昌'], '陕西':['西安'],
}


def annotate(places):
    names = {p['name']:p for p in places}
    edges = []
    for p in places:
        category = ('province' if p['name'] in PROVINCES or p.get('admin_level') == 'province'
                    else 'cultural' if p['name'] in {'江南', '江北'} or p.get('admin_level') == 'region' and p['type'] == 'region'
                    else 'natural' if p['type'] in {'mountain','lake','river','sea'} else 'settlement')
        p['scale_category'] = category
        p['scale_label'] = LABELS[category]
        p.setdefault('admin_level', 'province' if category == 'province' else 'natural' if category == 'natural' else 'region' if category == 'cultural' else 'unknown')
        p['level_rank'] = RANK[p['admin_level']]
        p['level_label'] = p.get('historical_type_label') or LEVEL_NAMES[p['admin_level']]
        p['min_zoom'] = {'province': 1, 'prefecture': 1.8, 'county': 3, 'town': 5,
                         'village': 7, 'natural': 1.8, 'region': 1, 'unknown': 5}[p['admin_level']]
        p['scale_label'] = p['level_label']
        p['historical_level_status'] = '未按故事年代核定，不将现代等级等同古代府州县'
        if p.get('admin_level')=='county': p['historical_level_status']='县级按用户及资料核对；未按故事年代核定完整县域边界。'
        p['parent_id'] = None
        if category in {'cultural','natural','ambiguous'}:
            p['containment_note'] = '文化区域、跨域自然地理或歧义地名，未建立可靠范围，不自动纳入行政包含汇总。'
    # Only connect parents from a validated source slice and matching identity.
    # Parent labels from time series can preserve earlier dynastic affiliations.
    aliases = {p['name']: p for p in places}
    for p in places:
        match = p.get('level_history_match') or p.get('selected_history_match') or {}
        label = NORMAL(match.get('name', ''))
        if label and label not in aliases: aliases[label] = p
    for p in places:
        if p.get('historical_parent_warning'): continue
        parent = aliases.get(p.get('historical_parent_name', ''))
        match = p.get('level_history_match') or p.get('selected_history_match') or {}
        if not parent or parent is p or parent['level_rank'] >= p['level_rank']: continue
        if match.get('years') != '1820 ~ 1820': continue
        p['parent_id'] = parent['id']
        edges.append({'parent_id': parent['id'], 'child_id': p['id'], 'kind': 'historical_reference_contains',
                      'year': 1820, 'source_url': p.get('level_source_url') or p['source_url'],
                      'note': 'CHGIS 1820参考年库载隶属；不自动代替该篇故事年代。'})
    for parent, children in MEMBERS.items():
        if parent not in names: continue
        for name in children:
            if name not in names: continue
            if names[name]['parent_id']: continue
            names[name]['parent_id'] = names[parent]['id']
            edges.append({'parent_id':names[parent]['id'],'child_id':names[name]['id'],
                          'kind':'modern_reference_contains','source_url':SOURCES[parent],
                          'note':'现代对照地所在省域；仅作辅助汇总，不证明故事时代隶属或事发位置。'})
    return {'categories':LABELS, 'edges':edges,
            'basis':'以CHGIS 1820参考年库载隶属优先，缺项另标现代省域对照；不是清代全部故事年代的统一疆域图。包含边注明年代及依据；未定位词及范围待核地名不自动纳入。',
            'historical_source':'https://chgis.fas.harvard.edu/pages/intro/'}
