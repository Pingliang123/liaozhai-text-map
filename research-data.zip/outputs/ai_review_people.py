"""DeepSeek review of source-reviewed person candidates.

The adapter reviews the conservative, source-context-filtered person inventory
instead of sending every raw NER fragment.  It never edits the corpus and a
missing or uncertain answer is rejected from the reviewed person list.
"""
import argparse
import json
import os
import time
from pathlib import Path
from urllib import error, request

ROOT = Path(__file__).parent
OUTPUT = ROOT / 'ghost_map'
DEFAULT_URL = 'https://api.deepseek.com/chat/completions'
LABELS = {'person', 'place', 'time', 'ordinary', 'uncertain'}
TYPES = {'人', '鬼', '妖', '神'}


def candidate_items():
    payload = json.loads((OUTPUT / '人物詞表_高置信表層候選.json').read_text(encoding='utf-8'))
    return [
        {'word': row['word'], 'mentions': row.get('mentions', 0),
         'chapters': row.get('chapters', 0),
         'methods': row.get('methods', []), 'examples': row.get('examples', [])[:3],
         'identity_links': row.get('identity_links', [])[:8]}
        for row in payload.get('candidates', [])
    ]


def prompt_for(items):
    return ('请对《聊斋志异》人物候选做严格的原文语境甄别。候选来自规则初筛，仍可能是称谓、动作短语、地名、普通词或分词错误。'
            '只有明确指向故事中一个人物、鬼、妖或神（仙）的词形才给 label=person；单字姓氏只有在例句确实作人物指代时才保留。'
            'person_types 可多选且只能是 人、鬼、妖、神：人指人类，鬼指死者／鬼魂／冥府鬼使，妖指狐妖精怪等，神指神仙、神祇、龙君等。'
            '不要因为篇名或一个孤立字面推断身份；证据不足给 uncertain。只输出 JSON：'
            '{"reviews":[{"word":"候选词","label":"person|place|time|ordinary|uncertain",'
            '"person_types":["人"],"canonical":"篇内明确所指的完整人物名，没有则空串，'
            '"confidence":0.0,"evidence":"不超过40字的原文依据"}]}。\n\n' +
            json.dumps(items, ensure_ascii=False))


def call_deepseek(items, api_key, url=DEFAULT_URL, model='deepseek-chat', timeout=90):
    body = json.dumps({'model': model, 'messages': [
        {'role': 'system', 'content': '你是古汉语数字人文校勘助手。严格依据输入，输出 JSON。'},
        {'role': 'user', 'content': prompt_for(items)},
    ], 'temperature': 0, 'response_format': {'type': 'json_object'},
        'max_tokens': max(500, len(items) * 80)}).encode('utf-8')
    req = request.Request(url, data=body, headers={
        'Content-Type': 'application/json', 'Authorization': 'Bearer ' + api_key}, method='POST')
    with request.urlopen(req, timeout=timeout) as response:
        return json.loads(json.loads(response.read().decode('utf-8'))['choices'][0]['message']['content'])


def validate_reviews(payload, requested):
    if not isinstance(payload, dict) or not isinstance(payload.get('reviews'), list):
        raise ValueError('DeepSeek 回应不是 reviews JSON 数组')
    result, seen = [], set()
    for row in payload['reviews']:
        if not isinstance(row, dict) or row.get('word') not in requested or row['word'] in seen:
            continue
        if row.get('label') not in LABELS:
            continue
        try:
            confidence = float(row.get('confidence', 0))
        except (TypeError, ValueError):
            continue
        if not 0 <= confidence <= 1:
            continue
        types = [t for t in row.get('person_types', []) if t in TYPES]
        result.append({'word': row['word'], 'label': row['label'],
                       'person_types': types if row['label'] == 'person' else [],
                       'canonical': str(row.get('canonical', ''))[:200],
                       'confidence': confidence, 'evidence': str(row.get('evidence', ''))[:300],
                       'reviewer': 'deepseek'})
        seen.add(row['word'])
    return result


def main():
    parser = argparse.ArgumentParser(description='Use DeepSeek to review textual person candidates.')
    parser.add_argument('--batch-size', type=int, default=20)
    parser.add_argument('--limit', type=int, default=0, help='0 = all candidates')
    parser.add_argument('--model', default=os.getenv('DEEPSEEK_MODEL', 'deepseek-chat'))
    parser.add_argument('--url', default=os.getenv('DEEPSEEK_BASE_URL', DEFAULT_URL))
    parser.add_argument('--output', type=Path, default=OUTPUT / '人物詞表_AI审核.json')
    args = parser.parse_args()
    key = os.getenv('DEEPSEEK_API_KEY')
    if not key:
        raise SystemExit('未设置 DEEPSEEK_API_KEY；密钥不会写入仓库。')
    items = candidate_items()[:args.limit or None]
    reviews = []
    for start in range(0, len(items), args.batch_size):
        batch = items[start:start + args.batch_size]
        for attempt in range(3):
            try:
                reviews.extend(validate_reviews(call_deepseek(batch, key, args.url, args.model),
                                                {r['word'] for r in batch}))
                break
            except (error.URLError, TimeoutError, ValueError, KeyError, json.JSONDecodeError):
                if attempt == 2:
                    raise
                time.sleep(2 ** attempt)
        print(f'reviewed {min(start + len(batch), len(items))}/{len(items)}', flush=True)
    args.output.write_text(json.dumps({
        'status': 'deepseek_context_review', 'model': args.model,
        'source': '人物詞表_高置信表層候選.json', 'count': len(reviews), 'reviews': reviews,
        'policy': '仅 label=person 且 confidence>=0.8 才进入 AI 人物列表；其余保留为待审。',
    }, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
