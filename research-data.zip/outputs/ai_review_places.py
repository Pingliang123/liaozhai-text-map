"""AI-assisted, source-scoped review of place candidates.

This is an optional DeepSeek adapter. It sends candidate words plus short source
contexts, never the full corpus. It never edits the corpus or silently promotes
an uncertain answer to a place.
"""
import argparse
import json
import os
import time
from pathlib import Path
from urllib import error, request

ROOT = Path(__file__).parent
INPUT = ROOT / 'nlp_dictionary'
OUTPUT = ROOT / 'ghost_map'
DEFAULT_URL = 'https://api.deepseek.com/chat/completions'
LABELS = {'place', 'person', 'time', 'ordinary', 'uncertain'}


def candidate_items():
    candidates = json.loads((INPUT / 'entity_space_candidates.json').read_text(encoding='utf-8'))
    return [
        {'word': row['word'], 'methods': row.get('methods', []), 'mentions': row.get('mentions', 0),
         'examples': row.get('examples', [])}
        for row in candidates if row['kind'] == 'place'
    ]


def prompt_for(items):
    return ('请对《聊斋志异》的地点候选做原文语境甄别。你不是在猜地名；必须依据给出的篇名、原文上下文和模型来源判断。\n'
            '每项只能给 label：place（确实是地名或篇内明确空间名）、person（人物/称谓）、'
            'time（时间词）、ordinary（普通词/动作/物品/虚词）、uncertain（证据不足）。\n'
            '只输出 JSON，格式为 {"reviews":[{"word":"候选词","label":"...",'
            '"confidence":0.0,"evidence":"不超过30字的原文依据"}]}。不要补造原文没有的地名。\n\n'
            + json.dumps(items, ensure_ascii=False))


def call_deepseek(items, api_key, url=DEFAULT_URL, model='deepseek-chat', timeout=90):
    body = json.dumps({
        'model': model,
        'messages': [
            {'role': 'system', 'content': '你是古汉语数字人文校勘助手。严格依据输入，输出 JSON。'},
            {'role': 'user', 'content': prompt_for(items)},
        ],
        'temperature': 0,
        'response_format': {'type': 'json_object'},
        'max_tokens': max(500, len(items) * 80),
    }).encode('utf-8')
    req = request.Request(url, data=body, headers={
        'Content-Type': 'application/json', 'Authorization': 'Bearer ' + api_key}, method='POST')
    with request.urlopen(req, timeout=timeout) as response:
        payload = json.loads(response.read().decode('utf-8'))
    content = payload['choices'][0]['message']['content']
    return json.loads(content)


def validate_reviews(payload, requested):
    if not isinstance(payload, dict) or not isinstance(payload.get('reviews'), list):
        raise ValueError('DeepSeek 回应不是 reviews JSON 数组')
    allowed = set(requested)
    result = []
    seen = set()
    for row in payload['reviews']:
        if not isinstance(row, dict) or row.get('word') not in allowed or row['word'] in seen:
            continue
        if row.get('label') not in LABELS:
            continue
        confidence = float(row.get('confidence', 0))
        if not 0 <= confidence <= 1:
            continue
        result.append({'word': row['word'], 'label': row['label'], 'confidence': confidence,
                       'evidence': str(row.get('evidence', ''))[:200], 'reviewer': 'deepseek'})
        seen.add(row['word'])
    return result


def load_ai_rejections(path=None):
    path = Path(path or OUTPUT / '地点词表_AI审核.json')
    if not path.exists():
        return {}, []
    payload = json.loads(path.read_text(encoding='utf-8'))
    reviews = validate_reviews(payload, {r['word'] for r in payload.get('reviews', [])})
    return {r['word']: r for r in reviews}, reviews


def main():
    parser = argparse.ArgumentParser(description='Use DeepSeek to review textual place candidates.')
    parser.add_argument('--batch-size', type=int, default=20)
    parser.add_argument('--limit', type=int, default=0, help='0 = all candidates')
    parser.add_argument('--model', default=os.getenv('DEEPSEEK_MODEL', 'deepseek-chat'))
    parser.add_argument('--url', default=os.getenv('DEEPSEEK_BASE_URL', DEFAULT_URL))
    parser.add_argument('--output', type=Path, default=OUTPUT / '地点词表_AI审核.json')
    args = parser.parse_args()
    key = os.getenv('DEEPSEEK_API_KEY')
    if not key:
        raise SystemExit('未设置 DEEPSEEK_API_KEY；请在当前终端设置后再运行，密钥不会写入仓库。')
    items = candidate_items()[:args.limit or None]
    reviews = []
    for start in range(0, len(items), args.batch_size):
        batch = items[start:start + args.batch_size]
        for attempt in range(3):
            try:
                response = call_deepseek(batch, key, args.url, args.model)
                reviews.extend(validate_reviews(response, {r['word'] for r in batch}))
                break
            except (error.URLError, TimeoutError, ValueError, KeyError, json.JSONDecodeError):
                if attempt == 2:
                    raise
                time.sleep(2 ** attempt)
        print(f'reviewed {min(start + len(batch), len(items))}/{len(items)}', flush=True)
    args.output.write_text(json.dumps({
        'status': 'deepseek_context_review', 'model': args.model,
        'source': 'entity_space_candidates.json', 'count': len(reviews), 'reviews': reviews,
        'policy': '仅 label=place 且 confidence>=0.8 才可进入地点统计；其余保留为待审。',
    }, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
