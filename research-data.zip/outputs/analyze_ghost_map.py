"""Reproducible whole-book word-cloud, entity inventory and ghost-map analysis.

The output deliberately distinguishes model candidates from reviewed place
hotspots. A hotspot is a textual co-occurrence signal, not a geocoded fact.
"""
import hashlib
import json
import math
import random
import re
from collections import Counter, defaultdict
from pathlib import Path
from opencc import OpenCC
NORMALIZE = OpenCC('t2s').convert

from liaozhai_nlp import CJK, jsonl_read, json_write

ROOT = Path(__file__).parent
INPUT = ROOT / 'nlp_dictionary'
OUTPUT = ROOT / 'ghost_map'
SOURCE_SHA = '28bc2dcf34612ca44c4dccadd0351edea130cca135dfd41bccb144660fc6e665'

# Reference notebook stopword idea, expanded for Classical-Chinese function
# words and narrative fillers. This list is for visualization only; it never
# deletes corpus tokens or entity candidates. Because the historical tokenizer
# sometimes retains a function word inside a compound token (例如「既而」、
# 「之外」), any token containing a reviewed stopword character is also hidden
# from the word cloud.
STOPWORDS = set('的了在是不而其之也有為为以於于與与及或又乃則则若而已矣者所此彼何其吾我汝君公人一二三四五六七八九十曰云言謂谓遂因故既既后後忽俄未曾方更仍但亦皆皆甚尤即及至自從从向將将欲可得能無无莫非如若還还見见聞闻使令便復复乃於于乎哉兮去出入来來归歸上下中外时時年日问問')
# User-reviewed boundary: retain 「女」, so the eight higher-frequency tokens
# immediately before it in the full-corpus ranking are excluded from the
# word-cloud display. This affects only the word cloud and cleaned frequency.
WORDCLOUD_STOPWORDS = {'的','他','在','不','了','是','之','曰','而','一','以','有','其'}
PUNCT = re.compile(r'^[\W_]+$', re.UNICODE)
YEAR_RE = re.compile(r'(?:前|後)?(?:康熙|雍正|乾隆|嘉慶|道光|咸豐|同治|光緒|宣統|民國|漢|唐|宋|元|明|清)?[一二三四五六七八九十百千〇零兩0-9]{1,8}(?:年|載|歲|月|日|甲子|甲寅|乙卯|丙辰|丁巳|戊午|己未|庚申|辛酉|壬戌|癸亥)')
EVENT_WORDS = set('鬼怪妖狐精魅仙神異怪夢冥幽魂魄死屍尸變化形幻靈祟魅魔龍蛇虎狐花怪'.replace(' ', ''))
EVENT_LABELS = {'鬼':'鬼','魂':'鬼','魄':'鬼','屍':'鬼','尸':'鬼','冥':'鬼',
                '妖':'妖','狐':'妖','精':'妖','魅':'妖','魔':'妖','怪':'妖',
                '仙':'神','神':'神','龍':'神'}
REALM_REVIEW = {
    '花姑子':('人間','「天庭」在此篇是身體部位，不能按字面判為天界'),
    '羅刹海市':('天界','文本中的羅刹國是跨海進入的異域仙境，不能落到現代地圖座標'),
    '罗刹海市':('天界','文本中的羅刹國是跨海進入的異域仙境，不能落到現代地圖座標'),
    '羅剎海市':('天界','文本中的羅剎國是跨海進入的異域仙境，不能落到現代地圖座標'),
    '罗剎海市':('天界','文本中的羅剎國是跨海進入的異域仙境，不能落到現代地圖座標'),
    '仙人島':('天界','篇名與文本明示仙人所居的島嶼，屬仙境空間'),
    '安期島':('天界','文本明示神仙所居，海上島嶼只保留為仙境意象'),
    '考城隍':('地界','死後受城隍任用，故事把人間官職轉換為陰間秩序'),
    '三生':('地界','人物死後到陰司執卷訟事'),
    '王蘭':('地界','閻王勘誤與鬼魂轉生'),
    '小二':('地界','地府司隸與太山帝君的幽冥官署'),
    '席方平':('地界','城隍與冥府司法空間'),
    '王十':('地界','冥府閻王與奈河、十八獄'),
    '酆都御史':('地界','酆都與閻羅署的地獄空間'),
    '棋鬼':('地界','走無常、幽冥勾役'),
    '鬼作筵':('地界','幽冥往返與鬼事'),
}
REALM_KEYWORDS = {
    '天界':('仙界','天宮','天庭','玉皇','上帝','仙人','神仙','天堂','仙境','羅刹國','罗刹国'),
    '地界':('冥府','地府','陰司','阴司','閻王','阎王','城隍','幽冥','地獄','地狱','陰間','阴间','酆都','奈河'),
}
REALM_SPACES = {
    '天界':('仙界','天宮','天庭','仙境','羅刹國','大羅刹國'),
    '地界':('冥府','地府','陰司','閻王','城隍','幽冥','地獄','陰間','酆都','奈河'),
}
PERSON_TYPE_LABELS = ('人','鬼','妖','神')
PERSON_CANONICAL = {
    '王桂菴': {'王':'王樨','王樨':'王樨','桂庵':'王樨','桂菴':'王樨'},
}

# Obvious NER false positives found in the candidate inventory. This is a
# display/hotspot filter, not a deletion from the all-candidate inventory.
PLACE_NOISE = set('俄日美金越中外内上下面前後左右東西南北此彼何某一二三四五六七八九十'.replace(' ', '')) | {'公子','佳人','俄顷','俄頃','益惧','益懼','诘旦','詰旦','邑邑','付生','窃喜','長跪','长跪','窃笑','長嘆','长叹'}
PLACE_REVIEW_REJECTIONS = {
    '俄頃', '俄顷', '越', '日', '武答', '萬一可免', '万一可免',
    '遠小人', '远小人', '武所', '詰旦', '诘旦', '武長', '武长',
    '武他', '武益恚', '武已', '俄', '杨', '客', '以', '中',
    '丰隆', '刍束', '金', '妾',
}
GENERIC_PLACE_WORDS = set('山城江寺庙廟门門家室屋房园園墓坟墳冢路道桥橋街村里'.replace(' ', ''))
PLACE_SUFFIXES = ('州','府','縣','郡','山','河','江','湖','海','城','京','陵','陽','陰','鎮','村','里','店','寺','宮','殿','關','門','臺','島','峰','洞','谷','原','莊','家')
# Explicitly reviewed against the source text: these are function/time words,
# kinship or discourse terms, or a geographic name—not person surfaces.
PERSON_NOISE = STOPWORDS | {'乃','有','今','耶','金陵','公','君','某','仆','汝','卿','妇','婦','翁','妾','婿','小生','窥','窺','非','殷勤','王怒','刘曰','劉曰','翁曰','王孙','王孫','青衣'}
PERSON_REVIEW_EXCLUSIONS = {
    '郎君','翁媪','老夫','仆人','舍宇','秀才','兄','姊夫','相公','福相','老僧',
    '王命','王亦','王乃','王笑','王问','王喜','王大悦','王故','王果','王召',
    '李曰','李喜','李亦','李乃','刘自','刘喜','刘因','刘恐','刘视之','刘述',
    '张乃','张筵','张许之','张闻','张惧','张皇','刘惊','刘笑','刘问','朱曰',
    '朱惧','朱归','李笑','李惧','徐乃','徐问','马问','马喜','杨大怒','杨诺',
    '翁乃','蒙君','王妃','王有','王自','王入','王成','王素','王告','王笑曰',
    '乃奔','乃脱','云云','日暮','怏怏','怏怏而归','久之无声','久不归','久之不动',
    '何必生','何福泽','莫知所为','款宴','劝令','劝令归','劫掠一空','心向往之',
    '果尔','讶之','讶问','倍益','杨柳','丁丁','兰麝香','舍宇','金钏','陈设',
    '静听','食后','高如人','长山人','吴王庙','吴门','九山','章丘','东海','兰若',
    '云栖','杨柳','康熙','弓矢','离婚书','病良已','瘢痕','石投犬','非汝','汝志',
    '汝姑','焉置','皆取','尤艳绝','张氏者','张目','彼云','把手','付嘱','何取焉',
    '何如哉','何决绝','何憔悴','何见疑','何许人','何遽','倏忽','光明','其健',
    '兰麝香','凌波','萧索','藏镪','郭间','陈设','仆出','仆欲','王所','王拒之',
    '王敬诺','王至','王述','王闻之','王窥','王窥既','王朗吟','王恐其','朱槛','李从之','李以','李方','李白','李诺之',
    '烦君','然君','王一日','王不觉','王于是','翁大惧','莫能起','石闻之','顾诺',
    '黄诺之','万石于','万石惧','仲诺','杨喜','梅曰','梅笑','刘益','刘亦','刘始',
    '刘某','刘氏','赵以','周固','周备','周村','周给','唐太史济武','奔而入',
    '尺许','幸兄贤','彭离席','揭之','方凝','朱大悦','刘宗玉','李白','王妃',
    '大异','疾行','翁姑','谢过','田产','谓宗曰','涓吉','王邸','痴郎','邹平',
    '顺天人','石疑','余姻','利津','君诚','周强','唐突','大男','天明','姊姊',
    '婢子','孟浪','家阿','小传','小婢','小狐','小郎','常格','广平','弟三郎',
    '张呼','张弓','张目曰','张翁','徐妻','徐疑','挽颈','方昼寝','施锦裀',
    '徐白山','上仙','龙君','帝君','岳帝'
}
PERSON_REVIEW_BAD_PREFIXES = ('乃','倘','何','勿','非','惟','莫','久','倍','怏','劝','劫','心','病','高','静','食','仆','把','抚','拾','讶','诘','款','殷','皆','焉','彼','汝')
PERSON_REVIEW_BAD_SUFFIXES = ('乃','亦','自','笑','问','惧','惊','怒','果','故','入','出','来','去','告','视','述','恐','始','喜','悦','诺','诺之','之','以','所','于','即','从之','拒之','闻之','不觉','于是','有','大悦','大怒','大惧','异','行','过','姑','邸','吉','疑','产','宴','人')
PERSON_CONTEXT_RE = re.compile(r'(?:姓|曰|呼|稱|称|謂|谓|問|问|見|见|告|語|语|訪|访|迎|使|送|娶|妻|夫|女|子|郎|公|先生|太守|秀才|人也|生，|生,|氏，|氏,)')


def cleaned_frequency(units):
    counts = Counter()
    for u in units:
        for t in u['tokens']:
            w = t['word']
            if not w or PUNCT.match(w) or w in STOPWORDS or not CJK.search(w):
                continue
            if len(w) == 1 and w in STOPWORDS:
                continue
            counts[w] += 1
    return counts


def classify_event_types(text):
    """Conservative lexical candidates, NOT reviewed story classifications.

    No hit does not establish a human-only story. Such a decision needs reading.
    """
    text = NORMALIZE(text)
    cues = {'鬼': ('鬼', '亡魂', '游魂', '阴魂', '阴司', '冥府', '地府', '地狱', '幽冥', '尸变'),
            '妖': ('妖', '狐', '精怪', '妖精', '鬼魅', '魔', '罗刹'),
            '神': ('神仙', '仙人', '仙女', '仙翁', '仙境', '仙界', '天帝', '玉皇', '龙王', '龙君', '城隍', '神祇', '神灵')}
    return sorted(label for label, words in cues.items() if any(w in text for w in words))


def classify_person_type(word, text, start=None, end=None):
    """Classify from the mention window, not every character in its clause."""
    context=text[max(0,(start or 0)-10):min(len(text),end if end is not None else len(text))+10]
    if any(k in word or k in context for k in ('鬼','魂','幽鬼','亡魂','閻王','城隍','冥使','判官')):
        return '鬼'
    if any(k in word or k in context for k in ('狐','妖','精','魅','魔','羅刹')):
        return '妖'
    deity_cue=re.search(r'(?:仙|神仙|龍君|帝君|玉皇|上帝|城隍)(?!志|情|色|態|采)', context)
    if any(k in word for k in ('神','仙','龍君','帝君','玉皇','上帝')) or deity_cue:
        return '神'
    return '人'


def classify_realm(chapter, text):
    if chapter in REALM_REVIEW:
        primary, reason=REALM_REVIEW[chapter]
        present=['人間',primary]
        spaces=list(REALM_SPACES.get(primary,()))
        return {'realm':primary,'realms_present':present,'realm_spaces':spaces,'review_status':'ai_content_reviewed_chapter_override','review_reason':reason}
    scores={realm:sum(text.count(k) for k in words) for realm,words in REALM_KEYWORDS.items()}
    present=['人間']+[realm for realm,score in scores.items() if score]
    spaces=[space for realm in scores for space in REALM_SPACES[realm] if any(text.count(k) for k in REALM_SPACES[realm])]
    primary=max(scores,key=scores.get) if any(scores.values()) else '人間'
    return {'realm':primary,'realms_present':present,'realm_spaces':spaces,'review_status':'lexical_realm_candidate','review_reason':'篇內關鍵詞計數，需人工回看上下文'}


def wordcloud_figure(freq, output):
    from wordcloud import WordCloud
    font_path = r'C:\Windows\Fonts\STSONG.TTF'
    if not Path(font_path).exists():
        font_path = r'C:\Windows\Fonts\NotoSerifSC-VF.ttf'
    cloud = WordCloud(font_path=font_path, colormap='plasma', max_words=500,
                      width=2400, height=1200, background_color='white',
                      collocations=False)
    cloud.generate_from_frequencies(dict(freq))
    # The attachment displays the cloud in matplotlib but the cloud itself is
    # configured as a 2400x1200 raster; write that raster directly to avoid
    # turning the attachment's 100-inch/1200-dpi display canvas into a huge
    # 120,000-pixel export.
    cloud.to_file(output)


def attachment_wordcloud_frequency(units):
    """Reproduce weirenmin cell 6: THULAC POS filter + six stopwords."""
    counts = Counter()
    for unit in units:
        for token in unit['tokens']:
            if token['pos'] in {'x','w','m'} or token['word'].strip() in {'','「','」'}:
                continue
            if token['word'] in WORDCLOUD_STOPWORDS or any(stop in token['word'] for stop in WORDCLOUD_STOPWORDS):
                continue
            counts[token['word']] += 1
    return counts


def candidate_inventory(candidates, kind):
    rows = [r for r in candidates if r['kind'] == kind]
    rows.sort(key=lambda r: (-r.get('mentions', 0), -r.get('chapters', 0), r['word']))
    return {'kind': kind, 'status': 'model_candidate_unreviewed', 'count': len(rows), 'candidates': rows}


def review_place_candidates(candidates, ai_reviews=None):
    """Reject source-scoped NER/POS false positives before story aggregation.

    The model inventory is retained separately for audit; rejected rows must
    never become a textual place or a map point.
    """
    accepted, rejected = [], []
    ai_reviews = ai_reviews or {}
    for row in candidates:
        ai = ai_reviews.get(row['word'])
        ai_reject = ai and (ai.get('label') != 'place' or ai.get('confidence', 0) < 0.8)
        ai_missing = bool(ai_reviews) and row['kind'] == 'place' and ai is None
        if row['kind'] == 'place' and (row['word'] in PLACE_REVIEW_REJECTIONS or ai_reject or ai_missing):
            if ai_missing:
                reason = 'AI未返回该候选，按不确定处理。'
            elif ai:
                reason = 'AI语境复核：' + str(ai.get('label')) + '，置信度 ' + str(ai.get('confidence'))
            else:
                reason = '原文核对为时间词、虚词短语，或人物与相邻词粘连；模型GPE/ns误报。'
            record = {**row, 'review_status': 'rejected_false_place', 'reason': reason}
            if ai:
                record['ai_review'] = ai
            rejected.append(record)
        else:
            accepted.append(row)
    return accepted, rejected


def high_confidence_people(candidates, units=None, ai_reviews=None):
    context_score=Counter()
    chapter_mentions=defaultdict(set)
    if units is not None:
        for u in units:
            for m in u.get('mentions',[]):
                if m['kind']!='person': continue
                context=u['text'][max(0,m['start']-8):min(len(u['text']),m['end']+10)]
                context_score[m['word']]+=bool(PERSON_CONTEXT_RE.search(context))
                chapter_mentions[m['word']].add(u['chapter_id'])
    candidate_chapters={word:set(chapters) for word,chapters in chapter_mentions.items()}
    multi_words=[]
    for candidate in candidates:
        if candidate['kind']!='person' or len(candidate['word'])<2: continue
        other=candidate['word']
        if other in PERSON_REVIEW_EXCLUSIONS or any(other.startswith(x) for x in PERSON_REVIEW_BAD_PREFIXES): continue
        if any(other.endswith(x) for x in PERSON_REVIEW_BAD_SUFFIXES): continue
        if context_score[other]==0 and 'opening_biography_candidate' not in candidate.get('methods',[]): continue
        multi_words.append(other)
    rows=[]; rejected=[]
    ai_reviews = ai_reviews or {}
    for r in candidates:
        if r['kind']!='person' or r['word'] in PERSON_NOISE: continue
        w=r['word']; reason=None
        if len(w)==1:
            links=[]
            for other in multi_words:
                if not other.startswith(w) or other==w: continue
                shared=chapter_mentions.get(w,set()) & candidate_chapters.get(other,set())
                if shared:
                    links.append({'surface':other,'chapters':sorted(shared)})
            links=sorted(links,key=lambda x:(-len(x['chapters']),x['surface']))[:40]
            if not links:
                reason='單字姓氏／單字人名沒有同篇複姓名或稱謂線索'
            else:
                ai = ai_reviews.get(w)
                if ai_reviews and (ai is None or ai.get('label') != 'person' or ai.get('confidence', 0) < 0.8):
                    rejected.append({**r, 'review_status': 'rejected_by_deepseek',
                                     'review_reason': 'DeepSeek未确认人物或置信度不足',
                                     'ai_review': ai or {'label': 'uncertain', 'confidence': 0}})
                    continue
                rows.append({**r,'review_status':'single_character_surname_with_local_identity_links',
                    'identity_status':'same_chapter_lexical_links_not_resolved_coreference',
                    'identity_links':links,'identity_link_count':len(links),
                    **({'ai_review': ai} if ai else {})})
                continue
        elif w in PERSON_REVIEW_EXCLUSIONS:
            reason='原文回看為功能短語、動作短語、普通名詞或空間詞'
        elif any(w.startswith(x) for x in PERSON_REVIEW_BAD_PREFIXES):
            reason='詞首是高頻功能詞或動作詞'
        elif any(w.endswith(x) for x in PERSON_REVIEW_BAD_SUFFIXES):
            reason='詞尾是高頻功能詞或動作詞'
        elif context_score[w] == 0 and 'opening_biography_candidate' not in r.get('methods',[]):
            reason='原文例句沒有可核對的人物語境'
        if reason:
            rejected.append({**r,'review_status':'rejected_after_source_review','review_reason':reason,
                             'person_context_score':context_score[w]})
            continue
        ai = ai_reviews.get(w)
        if ai_reviews and (ai is None or ai.get('label') != 'person' or ai.get('confidence', 0) < 0.8):
            rejected.append({**r, 'review_status': 'rejected_by_deepseek',
                             'review_reason': 'DeepSeek未确认人物或置信度不足',
                             'ai_review': ai or {'label': 'uncertain', 'confidence': 0}})
            continue
        rows.append({**r,'review_status':'high_confidence_surface_person_candidate',
                     'identity_status':'surface_person_candidate_not_coreference_gold',
                     **({'ai_review': ai} if ai else {})})
    rows.sort(key=lambda r:(-r.get('mentions',0),-r.get('chapters',0),r['word']))
    return {'kind':'person','status':'source_reviewed_surface_person_candidates_not_coreference_gold',
            'count':len(rows),'excluded_noise_terms':sorted(PERSON_NOISE),
            'review_rules':{'single_character':'excluded_to_manual_review','context_evidence':'requires_local_person_context_or_biographical_formula',
                            'deepseek':'label=person and confidence>=0.8 required when AI review file exists'},
            'rejected_count':len(rejected),'rejected_candidates':rejected,'candidates':rows}


def year_inventory(units):
    rows = []
    for u in units:
        for m in YEAR_RE.finditer(u['original']):
            rows.append({'value': m.group(), 'unit': u['unit'], 'chapter_id': u['chapter_id'],
                         'chapter': u['chapter'], 'original': u['original'],
                         'start': m.start(), 'end': m.end()})
    counts = Counter(r['value'] for r in rows)
    for r in rows: r['frequency_in_document'] = counts[r['value']]
    year_rows=[r for r in rows if '年' in r['value'] or '載' in r['value']]
    return {'status':'regex_candidate_unreviewed', 'pattern':YEAR_RE.pattern,
            'mentions':len(rows), 'forms':len(counts), 'counts':dict(counts), 'occurrences':rows}


def time_candidate_inventory(units):
    """Find time expressions from the tokenizer plus explicit year/date regex.

    This is deliberately broader than ``year_inventory``: THULAC's ``t``
    tokens include relative time, day/night, seasons and durations.  It still
    remains a candidate list because words such as 日、周、春 can be ambiguous.
    """
    records = defaultdict(lambda: {'mentions': 0, 'chapter_ids': set(), 'chapters': set(),
                                   'methods': set(), 'examples': []})
    for unit in units:
        seen = set()
        for token in unit['tokens']:
            word = token['word']
            if token.get('pos') != 't' and not YEAR_RE.fullmatch(word):
                continue
            method = 'thulac_t' if token.get('pos') == 't' else 'year_regex'
            key = (word, token['start'], token['end'])
            if key in seen:
                continue
            seen.add(key)
            row = records[word]
            row['mentions'] += 1; row['chapter_ids'].add(unit['chapter_id']); row['chapters'].add(unit['chapter'])
            row['methods'].add(method)
            if len(row['examples']) < 3:
                row['examples'].append({'chapter': unit['chapter'], 'unit': unit['unit'],
                                        'original_form': word, 'context': unit['original']})
    rows=[]
    for word, row in records.items():
        rows.append({'kind':'time','word':word,'mentions':row['mentions'],
                     'chapters':len(row['chapter_ids']),'chapter_ids':sorted(row['chapter_ids']),
                     'methods':sorted(row['methods']),'examples':row['examples'],
                     'review_status':'time_candidate_unreviewed'})
    return {'kind':'time','status':'token_pos_and_year_regex_candidate_unreviewed',
            'count':len(rows),'candidates':sorted(rows,key=lambda r:(-r['mentions'],r['word']))}


def token_occurrences(units, words):
    by_word = defaultdict(list)
    for u in units:
        for i,t in enumerate(u['tokens']):
            if t['word'] in words:
                a,b = t['start'],t['end']
                oa,ob = u['alignment'][a],u['alignment'][b]
                by_word[t['word']].append({'unit':u['unit'],'chapter_id':u['chapter_id'],
                    'chapter':u['chapter'],'token_index':i,'original_form':u['original'][oa:ob],
                    'original':u['original']})
    return by_word


def place_hotspots(units, candidates):
    # Candidate words must be at least two chars or be a known spatial suffix;
    # one-character NER guesses such as 俄/日 are retained elsewhere only.
    place_records = {r['word']:r for r in candidates if r['kind']=='place'}
    person_words = {r['word'] for r in candidates if r['kind']=='person'}
    words = {r['word'] for r in place_records.values()
             if r['word'] not in PLACE_NOISE
             and (len(r['word']) >= 2 or r['word'].endswith(PLACE_SUFFIXES))
             and r.get('mentions',0) >= 2
             and not (r['word'] in person_words and not r['word'].endswith(PLACE_SUFFIXES))
             and (set(r.get('methods',[])) & {'thulac_ns','spacy_GPE','spacy_LOC'}
                  or r['word'].endswith(PLACE_SUFFIXES))}
    occurrences = token_occurrences(units, words)
    chapter_order = {}
    for u in units: chapter_order.setdefault(u['chapter_id'], u['unit'])
    result=[]
    for word, occs in occurrences.items():
        event_occs=[]
        for o in occs:
            text=o['original']
            labels=classify_event_types(text)
            if labels or any(c in EVENT_WORDS for c in text):
                event_occs.append({**o,'event_labels':labels})
        if not event_occs:
            continue
        chapters=Counter(o['chapter_id'] for o in event_occs)
        sequences=[]
        for cid in sorted(chapters, key=lambda x: chapter_order[x]):
            evs=sorted((o for o in event_occs if o['chapter_id']==cid), key=lambda x:x['unit'])
            sequences.append({'chapter_id':cid,'chapter':evs[0]['chapter'],
                'events':[{'unit':e['unit'],'event_labels':e['event_labels'],
                           'excerpt':e['original']} for e in evs]})
        result.append({'place':word,'candidate_mentions':len(occs),
            'candidate_methods':place_records[word].get('methods',[]),
            'event_mentions':len(event_occs),'event_chapters':len(chapters),
            'hotspot_score':len(event_occs)*math.log1p(len(chapters)),
            'event_types':dict(Counter(label for o in event_occs for label in o['event_labels']),),
            'first_unit':min(o['unit'] for o in occs),'last_unit':max(o['unit'] for o in occs),
            'ordered_events':sequences,
            'interpretation_status':'textual hotspot; same-place link is lexical co-occurrence, not geocoded identity'})
    return sorted(result,key=lambda r:(-r['hotspot_score'],-r['event_chapters'],r['place']))


def build_map_edges(hotspots):
    edges=[]
    for h in hotspots:
        sequences=h.get('ordered_chapters',[])
        for seq in sequences:
            for event in seq['event_units']:
                edges.append({'place':h['place'],'chapter_id':seq['chapter_id'],'chapter':seq['chapter'],
                              'unit':event['unit'],'event_labels':event['labels'],
                              'excerpt':event['excerpt'],'people':seq['people'],
                              'years':seq['years'],'place_mentions_in_chapter':seq['place_mentions']})
    return edges


def chapter_profiles(units, candidates, ai_reviews=None):
    """Build one record per story/chapter; the primary analysis unit."""
    reviewed_people=high_confidence_people(candidates, units, ai_reviews)['candidates']
    people={r['word'] for r in reviewed_people}
    people_meta={r['word']:r for r in reviewed_people}
    places={r['word'] for r in candidates if r['kind']=='place'}
    rows={}
    for u in units:
        cid=u['chapter_id']
        row=rows.setdefault(cid, {'chapter_id':cid,'chapter':u['chapter'],'first_unit':u['unit'],
            'last_unit':u['unit'],'units':0,'people':Counter(),'places':Counter(),
            'event_types':Counter(),'event_units':[],'years':[],'realm_counts':Counter(),
            'realms_present':set(),'realm_spaces':set(),'person_types':defaultdict(Counter),'person_aliases':defaultdict(set),
            'realm_review':classify_realm(u['chapter'],u['original'])})
        row['last_unit']=u['unit']; row['units']+=1
        labels=classify_event_types(u['original'])
        row['event_types'].update(labels)
        realm_info=classify_realm(u['chapter'],u['original'])
        row['realm_counts'][realm_info['realm']]+=1
        row['realms_present'].update(realm_info['realms_present'])
        row['realm_spaces'].update(realm_info['realm_spaces'])
        if labels or any(c in EVENT_WORDS for c in u['original']):
            row['event_units'].append({'unit':u['unit'],'labels':labels,'excerpt':u['original']})
        row['years'].extend(m.group() for m in YEAR_RE.finditer(u['original']))
        # Require a person mention in this passage. A word classified as a
        # person in another story is not evidence that every token is a name.
        person_spans=set()
        for mention in u.get('mentions',[]):
            if mention['kind']=='person' and mention['word'] in people:
                span=(mention['start'],mention['end'],mention['word'])
                if span not in person_spans:
                    canonical=PERSON_CANONICAL.get(u['chapter'],{}).get(mention['word'],mention['word'])
                    row['people'][canonical]+=1
                    if canonical != mention['word']: row['person_aliases'][canonical].add(mention['word'])
                    ai = people_meta.get(canonical, {}).get('ai_review', {})
                    labels = ai.get('person_types') or [classify_person_type(canonical,u['original'],mention['start'],mention['end'])]
                    for label in labels:
                        row['person_types'][canonical][label] += 1
                    person_spans.add(span)
        # Membership in a book-wide lexicon is not a local entity annotation.
        for start, end, word in {(m['start'], m['end'], m['word']) for m in u.get('mentions', [])
                                  if m['kind'] == 'place' and m['word'] in places}:
            row['places'][word] += 1
    output=[]
    for cid in sorted(rows):
        r=rows[cid]
        r['person_aliases']={k:sorted(v) for k,v in r['person_aliases'].items()}
        realm=sorted(r['realm_counts'],key=lambda x:(-r['realm_counts'][x],x))[0] if r['realm_counts'] else '人間'
        output.append({**r,'realm':realm,'realms_present':sorted(r['realms_present']) or ['人間'],'realm_spaces':sorted(r['realm_spaces']),
            'realm_review_status':r['realm_review']['review_status'],'realm_review_reason':r['realm_review']['review_reason'],
            'people':[{'word':w,'mentions':n,'person_types':dict(r['person_types'][w]),
            **({'aliases':r['person_aliases'].get(w,[])} if r['person_aliases'].get(w) else {}) ,
            **({'identity_links':people_meta[w]['identity_links'],
                'identity_status':people_meta[w]['identity_status']} if 'identity_links' in people_meta[w] else {})}
            for w,n in r['people'].most_common()],
            'places':[{'word':w,'mentions':n} for w,n in r['places'].most_common()],
            'event_types':dict(r['event_types']),'event_units':r['event_units'],
            'years':dict(Counter(r['years']))})
    from ghost_map_chapter_review import apply_chapter_review
    return [apply_chapter_review(profile) for profile in output]


def chapter_place_hotspots(profiles, candidates):
    """Relate a place to all people/events in the same story, not one clause."""
    records={r['word']:r for r in candidates if r['kind']=='place'}
    person_words={r['word'] for r in candidates if r['kind']=='person'}
    allowed={r['word'] for r in records.values()
        if r['word'] not in PLACE_NOISE and r.get('mentions',0)>=2
        and (len(r['word'])>=2 or r['word'].endswith(PLACE_SUFFIXES))
        and not (r['word'] in person_words and not r['word'].endswith(PLACE_SUFFIXES))
        and (set(r.get('methods',[])) & {'thulac_ns','spacy_GPE','spacy_LOC'} or r['word'].endswith(PLACE_SUFFIXES))}
    result=[]
    for word in sorted(allowed):
        seq=[]
        for p in profiles:
            if not p['event_units'] or not any(x['word']==word for x in p['places']):
                continue
            mentions=next(x['mentions'] for x in p['places'] if x['word']==word)
            seq.append({'chapter_id':p['chapter_id'],'chapter':p['chapter'],
                'place_mentions':mentions,'people':p['people'][:20],
                'years':p['years'],'event_types':p['event_types'],
                'realm':p['realm'],'realms_present':p['realms_present'],
                'realm_spaces':p.get('realm_spaces',[]),
                'event_units':p['event_units'][:8],
                'unit_range':[p['first_unit'],p['last_unit']]})
        if not seq: continue
        ev_mentions=sum(len(x['event_units']) for x in seq)
        result.append({'place':word,'candidate_methods':records[word].get('methods',[]),
            'event_chapters':len(seq),'event_mentions':ev_mentions,
            'place_mentions_in_event_chapters':sum(x['place_mentions'] for x in seq),
            'hotspot_score':sum(x['place_mentions'] for x in seq)*math.log1p(len(seq)),
            'event_types':dict(Counter(k for x in seq for k in x['event_types'] for _ in range(x['event_types'][k]))),
            'ordered_chapters':seq,
            'interpretation_status':'chapter-level textual association; not same-sentence causality or GIS identity'})
    return sorted(result,key=lambda r:(-r['hotspot_score'],-r['event_chapters'],r['place']))


def main():
    manifest=json.loads((INPUT/'manifest.json').read_text(encoding='utf-8'))
    if manifest['source_sha256'] != SOURCE_SHA:
        raise ValueError('Outputs are tied to the inspected text edition.')
    units=jsonl_read(INPUT/'segmented_units.jsonl.gz')
    raw_candidates=json.loads((INPUT/'entity_space_candidates.json').read_text(encoding='utf-8'))
    ai_reviews = {}
    ai_path = OUTPUT/'地点词表_AI审核.json'
    if ai_path.exists():
        from ai_review_places import validate_reviews
        ai_payload=json.loads(ai_path.read_text(encoding='utf-8'))
        ai_reviews={r['word']:r for r in validate_reviews(ai_payload, {r['word'] for r in raw_candidates if r['kind']=='place'})}
    candidates, rejected_places=review_place_candidates(raw_candidates, ai_reviews)
    OUTPUT.mkdir(exist_ok=True)
    freq=attachment_wordcloud_frequency(units)
    json_write(OUTPUT/'清洗後詞頻.json', {'stopword_count':len(WORDCLOUD_STOPWORDS),'stopwords':sorted(WORDCLOUD_STOPWORDS),'cleaning_rules':[
        'weirenmin: exclude THULAC POS x/w/m and 「」','existing stopwords retained: 的/他/在/了/是','user boundary: add the eight tokens ranked before 女: 不/之/曰/而/一/以/有/其','hide compound tokens containing a reviewed stopword character, such as 既而／之外','retain corpus tokens unchanged'],
        'token_count':sum(freq.values()),'word_types':len(freq),'frequencies':dict(freq)})
    wordcloud_figure(freq, OUTPUT/'全書詞雲.png')
    json_write(OUTPUT/'人物詞表_全量模型候選.json', candidate_inventory(candidates,'person'))
    people_ai_path = OUTPUT/'人物詞表_AI审核.json'
    people_ai_reviews = {}
    if people_ai_path.exists():
        from ai_review_people import validate_reviews as validate_people_reviews
        people_payload=json.loads(people_ai_path.read_text(encoding='utf-8'))
        people_ai_reviews={r['word']:r for r in validate_people_reviews(
            people_payload, {r['word'] for r in raw_candidates if r['kind']=='person'})}
    reviewed_people=high_confidence_people(candidates, units, people_ai_reviews)
    json_write(OUTPUT/'人物詞表_高置信表層候選.json', reviewed_people)
    json_write(OUTPUT/'人物詞表_人工審核排除.json', {'source_sha256':SOURCE_SHA,
        'status':'source_context_review_rejected_candidates','count':reviewed_people['rejected_count'],
        'review_rules':reviewed_people['review_rules'],'candidates':reviewed_people['rejected_candidates']})
    json_write(OUTPUT/'地點詞表_全量模型候選.json', candidate_inventory(candidates,'place'))
    json_write(OUTPUT/'地點詞表_人工審核排除.json', {
        'status': 'source_context_review_rejected_false_places',
        'count': len(rejected_places), 'candidates': rejected_places,
        'ai_review_count': len(ai_reviews),
        'rule': '仅排除已按原文核实的误报；未经核对的模型候选仍保留为候选，不等于全书地名金标准。'})
    years=year_inventory(units); years['year_occurrences']=[r for r in years['occurrences'] if '年' in r['value'] or '載' in r['value']]
    years['year_only_mentions']=len(years['year_occurrences'])
    json_write(OUTPUT/'年份詞表.json',years)
    json_write(OUTPUT/'時間詞表_全量模型候選.json', time_candidate_inventory(units))
    profiles=chapter_profiles(units,candidates,people_ai_reviews)
    json_write(OUTPUT/'篇目人物地點年份分析.json', {'unit':'chapter/story','chapters':profiles,
        'status':'candidate mentions grouped by complete story/chapter; no cross-story coreference'})
    sentence_hotspots=place_hotspots(units,candidates)
    hotspots=chapter_place_hotspots(profiles,candidates)
    named=[h for h in hotspots if h['place'] not in GENERIC_PLACE_WORDS and len(h['place']) >= 2]
    json_write(OUTPUT/'異事地點熱點.json', {'method':'place candidate + event trigger anywhere in the same chapter; ranked by chapter place mentions*log1p(event_chapters)',
        'event_lexicon':sorted(EVENT_WORDS),'place_filter':{'minimum_candidate_mentions':2,'excluded_one_char_noise':sorted(PLACE_NOISE)},
        'hotspots':hotspots,'named_hotspots':named,
        'generic_spatial_hotspots':[h for h in hotspots if h['place'] in GENERIC_PLACE_WORDS],
        'sentence_level_comparison':sentence_hotspots})
    json_write(OUTPUT/'鬼怪地圖事件序列.json', {'edges':build_map_edges(hotspots),
        'ordering':'source chapter order, then unit order inside each chapter; not historical chronology unless a year is explicitly present',
        'scope':'Textual lexical map, not physical GIS map'})
    meta={'source_sha256':SOURCE_SHA,'segmentation_cache_sha256':hashlib.sha256((INPUT/'segmented_units.jsonl.gz').read_bytes()).hexdigest(),
          'segmentation_input':'nlp_dictionary','user_dictionary':manifest['user_dictionary'],
          'chapters':manifest['chapter_units'],'clauses':manifest['clauses'],'original_cjk':manifest['cjk_characters'],
          'cleaned_tokens':sum(freq.values()),'cleaned_word_types':len(freq),'person_candidate_types':len([r for r in candidates if r['kind']=='person']),
          'high_confidence_person_surface_types':len(reviewed_people['candidates']),
          'deepseek_person_review_types':len(people_ai_reviews),
          'raw_place_candidate_types':len([r for r in raw_candidates if r['kind']=='place']),
          'rejected_false_place_types':len(rejected_places),
          'place_candidate_types':len([r for r in candidates if r['kind']=='place']),'year_mentions':years['mentions'],'year_only_mentions':years['year_only_mentions'],
          'hotspot_count':len(hotspots),'chapter_profiles':len(profiles),'status':'Candidates and textual hotspots are not complete manual entity/event annotation.'}
    json_write(OUTPUT/'manifest.json',meta)
    print(json.dumps(meta,ensure_ascii=False))


if __name__=='__main__': main()
