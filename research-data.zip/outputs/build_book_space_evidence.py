"""Build explicitly manual narrative annotations and our reproducible notebook."""
import json
import sys
from pathlib import Path
from analyze_book_space import INPUT, OUTPUT, SOURCE_SHA
from liaozhai_nlp import jsonl_read, json_write

# Each event is a selected close-reading anchor, NOT an automatically detected
# movement, an exhaustive event set, or an assignment of all characters' species.
CASES=[
    ('畫壁','觀看／進入／返回；欲望空間仍有禁令',[
        (152,'已到壁上','觀看畫面轉為進入畫中'),
        (157,'閉戶','閉戶隱藏與限制發聲'),
        (169,'藏匿下界人','異境內部有身分排斥與追查'),
        (182,'自壁而下','返回寺院現實層'),
        (185,'幻由人生','敘事以人的心念解釋幻境')]),
    ('勞山道士','牆的可穿透性有條件；不可等同取消一切界線',[
        (526,'牆壁所不能隔','王提出學習穿牆的願望'),
        (532,'虛若無物','在師處成功穿牆'),
        (534,'歸宜潔持','成功被置於持守條件之下'),
        (537,'頭觸硬壁','回家逞能時失敗；墳是額頭腫起，不是墓')]),
    ('山市','可見的城市不等於可以進入的世界',[
        (15411,'忽見山頭','樓上觀看者的視線'),
        (15412,'無此禪院','以附近既有地理提出懷疑'),
        (15414,'居然城郭','城郭形態被看見'),
        (15428,'遂不可見','縮小消失；未敘述人物進入'),
        (15429,'鬼市','轉述的別名，不直接證明鬼居民')]),
    ('賈奉雉','異境時差使同一故鄉失去原有家族與財產關係',[
        (24916,'其中別有天地','進入深山洞府'),
        (24958,'舊景全非','回到家門卻無人相識'),
        (24971,'百餘年','異境與人世不同時間尺度'),
        (25007,'橫占田宅','後裔權勢與地產侵占')]),
    ('遵化署狐','官署同時被官員與狐族主張為家',[
        (4491,'以為家','狐族住居的命名'),
        (4495,'勿相仇','狐請求避免衝突'),
        (4498,'巨炮','武力摧毀共同住居場域'),
        (4505,'妻子橫被殺戮','狐以冤屈和貪腐證据反擊')]),
    ('長治女子','官署既有司法功能，也包含可投生的家庭',[
        (12079,'至官廨','受術控制的女魂被派遣伏閣'),
        (12095,'官署即吾家','女子對家的認定'),
        (12097,'夫人生女','結尾投生解釋前句；不是長期佔署')]),
    ('錦瑟','園不只有景觀／情愛，也可組織救濟與勞動',[
        (31015,'給孤園','收養橫死無歸之鬼'),
        (31019,'穢臭熏人','救濟設施的物質環境'),
        (31020,'斷頭缺足','園內亡者的殘損身體'),
        (31113,'壁復合','離開後入口封閉')]),
    ('公孫九娘','合成里名和無法辨認的墓地保存集體暴力記憶',[
        (8936,'棲霞、萊陽','敘事明示被株連者的地域'),
        (9050,'萊霞里','鬼居里名'),
        (9051,'兩處新鬼','里名來由是兩地新死者'),
        (9054,'收兒骨歸葬','個人的歸葬請求'),
        (9068,'竟迷村路','千墳之中無法重返'),
        (9072,'迷目榛荒','墓地失去可辨識路標')]),
    ('鬼哭','清除屍血不等於清除死亡記憶；儀式效果以疑問收束',[
        (1162,'宦第皆為賊窟','戰亂改變宅邸的使用者'),
        (1164,'血至充門','宅院成為殺戮場所'),
        (1165,'滌血而居','主人清洗後恢復居住'),
        (1173,'笑之以鼻','鬼不受官員名位和仗劍震懾'),
        (1174,'水陸道場','轉向超度施食'),
        (1182,'果有益耶','結尾保留對儀式作用的疑問')]),
    ('地震','住所轉為危險，街道成為臨時集體避難與交流場',[
        (3068,'康熙七年','明示紀年'),
        (3069,'余適客稷下','敘述者在場位置，非震中座標'),
        (3075,'各疾趨出','逃離建築物'),
        (3077,'牆傾屋塌','庇護建築轉為威脅'),
        (3081,'男女裸聚','街道避難暫時打破日常身體遮蔽')]),
]


def build_cases(units):
    result=[]
    for title,interpretation,events in CASES:
        anchors=[]
        for uid,quote,label in events:
            unit=units[uid]
            if unit['chapter']!=title or quote not in unit['original']:
                raise ValueError(f'Anchor does not match this edition: {title} {uid} {quote}')
            start=unit['original'].index(quote)
            anchors.append({'unit':uid,'chapter_id':unit['chapter_id'],
                'quote':quote,'original_start':start,'original_end':start+len(quote),
                'original':unit['original'],'manual_event_label':label})
        result.append({'chapter':title,'manual_interpretation':interpretation,'anchors':anchors})
    return {'source_sha256':SOURCE_SHA,'annotation_status':'selected manual close-reading anchors; not full event or identity annotation',
            'cases':result}


def notebook():
    cells=[]
    def add(kind,source):
        c={'cell_type':kind,'id':f'book-space-{len(cells)+1}',
           'metadata':{},'source':source.splitlines(keepends=True)}
        if kind=='code': c.update(execution_count=None,outputs=[])
        cells.append(c)
    add('markdown','# 《聊齋志異》全書空間：詞族比較與敘事轉折\n\n先全書分詞，再從完整詞表和原文選取詞族；不是預設人鬼妖地圖。347 個選定詞位不代表全書所有空間。附件 Notebook 僅供方法參考，未執行其中代碼。')
    add('code',"from pathlib import Path\nimport json, sys, hashlib\nrepo = Path.cwd().resolve()\nfor candidate in [repo, *repo.parents]:\n    if (candidate/'outputs'/'analyze_book_space.py').exists():\n        repo = candidate\n        break\nelse:\n    raise RuntimeError('請在本倉庫或其子目錄啟動 Notebook')\nsys.path.insert(0, str(repo/'outputs'))\nfrom liaozhai_nlp import jsonl_read\nfrom analyze_book_space import collect_families, statistics, contexts_for_pair, TOKENIZATION_CAVEATS\nfolder = repo/'outputs'/'book_space'\nread = lambda name: json.loads((folder/name).read_text(encoding='utf-8'))\nmanifest = read('manifest.json')\nmanifest")
    add('code',"units = jsonl_read(repo/'outputs'/'nlp'/'segmented_units.jsonl.gz')\nassert hashlib.sha256((repo/'outputs'/'nlp'/'segmented_units.jsonl.gz').read_bytes()).hexdigest() == manifest['segmentation_cache_sha256']\nspans, mentions, excluded = collect_families(units)\nassert len(mentions) == manifest['selected_mentions']\nstats, overlaps = statistics(units, mentions)\nassert stats == read('词族频率与篇章分布.json')\n[(r['family'], r['mentions'], r['chapters'], r['per_10000_cjk']) for r in stats]")
    add('markdown','## 詞義排除與分詞殘留\n\n腫起、三墳古籍、冢室正妻、署字動詞、人物高西園不可算空間。保留的「香水月寺／寄靈寺／讀書園／孤園」是模型詞形中的空間表達，不是可直接地理編碼的專名。')
    add('code',"[(r['unit'], r['word'], r['reason'], r['original']) for r in excluded]")
    add('code',"TOKENIZATION_CAVEATS")
    add('markdown','## 三尺度搭配\n\n窗口內 n 是去重後的搭配詞位；同分句模式 n 是分句數，不能當作同一計數單位。O/E 是觀察／期望，不是情節因果；檢驗為探索性，詞位不是獨立樣本。')
    add('code',"tables = {name: jsonl_read(folder/f'词族搭配_{name}.jsonl.gz') for name in ['window5','window10','sentence0']}\nevidence = read('重点词对原文证据.json')\npairs = {(r['target'],r['collocate']) for r in evidence}\n[(name,r['target'],r['collocate'],r['observed'],round(r['oe_ratio'],2),r['support_chapters']) for name,rows in tables.items() for r in rows if (r['target'],r['collocate']) in pairs]")
    add('code',"for r in evidence:\n    contexts = contexts_for_pair(units,spans[r['target']],r['collocate'],5)\n    assert contexts == r['contexts']\n    assert len(contexts) == r['observed']\n[(r['target'],r['collocate'],[(c['chapter'],c['original']) for c in r['contexts']]) for r in evidence]")
    add('markdown','## 相似與區別\n\n相似度包含「中、入、外」等位置語法及固定詞組。不能把最高餘弦值改寫成最相同的社會功能；同篇共現也不是鄰接或移動。')
    add('code',"read('词族搭配相似度.json')[:6]")
    add('code',"[r for r in overlaps if r['shared_chapters'] >= 4]")
    add('markdown','## 敘事转折：人工選例而非自動旅行路線\n\n每個引文保留篇名、分句 ID 和原文內字符跨度；按敘事順序排列，不假裝已完整標註全書人物物種／共指／事件。')
    add('code',"cases = read('人工敘事轉折證據.json')\nfor case in cases['cases']:\n    for anchor in case['anchors']:\n        original = units[anchor['unit']]['original']\n        assert original[anchor['original_start']:anchor['original_end']] == anchor['quote']\n[(c['chapter'],c['manual_interpretation'],[(a['quote'],a['manual_event_label']) for a in c['anchors']]) for c in cases['cases']]")
    add('markdown','## 圖形與研究結論\n\n![選定空間詞族搭配](空间词族搭配.png)\n\n詳見上級目錄《全書空間問題進階分析.md》。主要論點：空間以通行、住居、觀看、時間、記憶和照護等關係組織人物，而非將人鬼妖分配到互斥區域。')
    return {'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':sys.version.split()[0]}},'cells':cells}


def main():
    manifest=json.loads((INPUT/'manifest.json').read_text(encoding='utf-8'))
    if manifest['source_sha256']!=SOURCE_SHA:
        raise ValueError('Manual review requires the inspected edition.')
    OUTPUT.mkdir(exist_ok=True)
    units=jsonl_read(INPUT/'segmented_units.jsonl.gz')
    json_write(OUTPUT/'人工敘事轉折證據.json',build_cases(units))
    json_write(OUTPUT/'全書空間詞族分析.ipynb',notebook())
    print(f'Built {len(CASES)} manually selected cases and authored notebook.')


if __name__=='__main__': main()
