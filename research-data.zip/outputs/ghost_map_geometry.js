(function(root) {
  'use strict';
  const COLORS = {人: '#176bb0', 鬼: '#7042b8', 妖: '#d85e00', 神: '#008477'};
  const raw = ([lon, lat]) => [lon * Math.PI / 180, -Math.log(Math.tan(Math.PI / 4 + Math.max(-85, Math.min(85, lat)) * Math.PI / 360))];
  function projection(points, width, height, padding = 35) {
    const coords = points.map(raw), xs = coords.map(p => p[0]), ys = coords.map(p => p[1]);
    const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
    const scale = Math.min((width - padding * 2) / Math.max(maxX - minX, 0.01), (height - padding * 2) / Math.max(maxY - minY, 0.01));
    const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
    const project = coord => { const [x, y] = raw(coord); return [(x - cx) * scale + width / 2, (y - cy) * scale + height / 2]; };
    project.invert = ([x, y]) => [(cx + (x - width / 2) / scale) * 180 / Math.PI, (2 * Math.atan(Math.exp(-(cy + (y - height / 2) / scale))) - Math.PI / 2) * 180 / Math.PI];
    return project;
  }
  const screen = (p, t) => [p[0] * t.k + t.x, p[1] * t.k + t.y];
  function zoomAt(t, factor, anchor) {
    const k = Math.min(12, Math.max(1, t.k * factor)), ratio = k / t.k;
    return {k, x: anchor[0] - (anchor[0] - t.x) * ratio, y: anchor[1] - (anchor[1] - t.y) * ratio};
  }
  const placeLevel = p => p.admin_level || (p.scale_category === 'province' ? 'province' : p.scale_category === 'natural' ? 'natural' : p.scale_category === 'cultural' ? 'region' : 'unknown');
  const levelRank = p => ({province:1,region:1,prefecture:2,natural:2,county:3,town:4,village:5,unknown:6}[placeLevel(p)] || 6);
  const minimumZoom = p => ({province:1,region:1,prefecture:1.8,natural:1.8,county:3,town:5,village:7,unknown:5}[placeLevel(p)] || 5);
  function visiblePoints(points, transform, width, height, selected = null, options = {}) {
    // Thin in screen space instead of moving historical locations across the
    // map. Zooming separates the anchors naturally; selection always wins,
    // including two textual names which share a coordinate.
    const budget = Math.max(6, Math.min(60, Math.floor(width * height / 14000)));
    const ranked = points.map(p => ({...p, anchor: screen(p.xy, transform)}))
      .filter(p => p.id === selected || options.expandAll || p.min_zoom === undefined || transform.k >= minimumZoom(p))
      .filter(p => p.anchor.every(Number.isFinite) && p.anchor[0] >= 14 && p.anchor[1] >= 14 && p.anchor[0] <= width - 14 && p.anchor[1] <= height - 14)
      .sort((a, b) => Number(b.id === selected) - Number(a.id === selected) ||
        levelRank(a) - levelRank(b) ||
        (b.chapters?.length ?? b.chapter_ids?.length ?? 0) - (a.chapters?.length ?? a.chapter_ids?.length ?? 0) ||
        Number(a.mapping_source === 'historical_search_auto_promoted') - Number(b.mapping_source === 'historical_search_auto_promoted') ||
        String(a.id).localeCompare(String(b.id)));
    const visible = [];
    for (const p of ranked) {
      if (visible.length >= budget) break;
      if (visible.some(q => Math.hypot(q.anchor[0] - p.anchor[0], q.anchor[1] - p.anchor[1]) < 38)) continue;
      visible.push({...p, display: [...p.anchor]});
    }
    return visible;
  }
  function labels(points, width, height, selected) {
    const placed = [];
    const budget = Math.max(4, Math.min(24, Math.floor(width * height / 22000)));
    for (const p of [...points].sort((a, b) => (b.id === selected) - (a.id === selected))) {
      if (placed.length >= budget) break;
      const before=placed.length;
      const [x, y] = p.display, w = p.name.length * 13 + 2;
      const gap = 12;
      for (const [dx, dy] of [[gap,5],[-w-gap,5],[-w/2,-12],[-w/2,27],[gap,-10],[gap,25],[-w-gap,-10],[-w-gap,25]]) {
        const rect = [x + dx, y + dy - 13, w, 17];
        if (rect[0] < 2 || rect[1] < 2 || rect[0] + w > width || rect[1] + 17 > height) continue;
        if (points.some(q => q.id !== p.id && q.display[0] > rect[0] - 13 && q.display[0] < rect[0] + w + 13 && q.display[1] > rect[1] - 13 && q.display[1] < rect[1] + 30)) continue;
        if (placed.some(q => rect[0] < q.rect[0] + q.rect[2] + 3 && rect[0] + w + 3 > q.rect[0] && rect[1] < q.rect[1] + q.rect[3] + 2 && rect[1] + 17 + 2 > q.rect[1])) continue;
        const edge = [Math.max(rect[0],Math.min(x,rect[0]+w)), Math.max(rect[1],Math.min(y,rect[1]+17))];
        const distance = q => Math.hypot(q.display[0]-Math.max(rect[0],Math.min(q.display[0],rect[0]+w)),q.display[1]-Math.max(rect[1],Math.min(q.display[1],rect[1]+17)));
        const ambiguous = points.some(q => q.id !== p.id && distance(q) <= distance(p)+6);
        const length = Math.hypot(edge[0]-x,edge[1]-y);
        placed.push({id:p.id,text:p.name,x:rect[0],y:rect[1]+13,rect,
          leader:ambiguous || length > 12 ? {from:p.display,to:edge} : null}); break;
      }
      if(p.id===selected && placed.length===before) {
        const left=Math.max(2,Math.min(width-w-2,x+12)),top=Math.max(2,Math.min(height-19,y+8));
        placed.push({id:p.id,text:p.name,x:left,y:top+13,rect:[left,top,w,17],leader:{from:p.display,to:[left,top+8]}});
      }
    }
    return placed;
  }
  function routeLabels(items,width,height,obstacles=[]){
    const occupied=obstacles.map(r=>[...r]),placed=[];
    const overlaps=(a,b)=>a[0]<b[0]+b[2]+4&&a[0]+a[2]+4>b[0]&&a[1]<b[1]+b[3]+4&&a[1]+a[3]+4>b[1];
    for(const item of [...items].sort((a,b)=>(b.priority||0)-(a.priority||0))){
      const [x,y]=item.anchor;
      if(!Number.isFinite(x)||!Number.isFinite(y)||x<0||y<0||x>width||y>height) continue;
      const lines=item.lines?.length?item.lines:[item.text];
      const w=12+Math.max(...lines.map(line=>[...line].reduce((n,c)=>n+(/[\u0000-\u007f]/.test(c)?8:13),0))),h=lines.length*16+6;
      let best=null;
      for(const radius of [0,16,32,48,64,96,128]){
        for(const [dx,dy] of [[8+radius,-h-5],[-w-8-radius,-h-5],[8+radius,7],[-w-8-radius,7],[-w/2,-h-8-radius],[-w/2,8+radius],[8+radius,-h-5-radius],[-w-8-radius,-h-5-radius],[8+radius,7+radius],[-w-8-radius,7+radius]]){
          const rect=[x+dx,y+dy,w,h];
          if(rect[0]<3||rect[1]<3||rect[0]+w>width-3||rect[1]+h>height-3||occupied.some(r=>overlaps(rect,r))) continue;
          const edge=[Math.max(rect[0],Math.min(x,rect[0]+w)),Math.max(rect[1],Math.min(y,rect[1]+h))];
          const distance=Math.hypot(edge[0]-x,edge[1]-y);
          if(!best||distance<best.distance) best={...item,lines,rect,x:rect[0]+6,y:rect[1]+16,edge,distance};
        }
        if(best) break;
      }
      if(best){occupied.push(best.rect);placed.push(best);}
    }
    return placed;
  }
  function topologyRings(topology) {
    const arcs = topology.arcs.map(arc => {
      let x = 0, y = 0;
      return arc.map(p => {
        if (!topology.transform) return p;
        x += p[0]; y += p[1];
        return [x * topology.transform.scale[0] + topology.transform.translate[0], y * topology.transform.scale[1] + topology.transform.translate[1]];
      });
    });
    const ring = indices => indices.flatMap((index, i) => {
      const values = index < 0 ? [...arcs[~index]].reverse() : arcs[index];
      return i ? values.slice(1) : values;
    });
    return Object.values(topology.objects).flatMap(object => (object.geometries || [object]).flatMap(g =>
      g.type === 'Polygon' ? g.arcs.map(ring) : g.type === 'MultiPolygon' ? g.arcs.flatMap(p => p.map(ring)) : []));
  }
  function geoJSONRings(geojson) {
    const rings = [];
    const addGeometry = geometry => {
      if (!geometry) return;
      if (geometry.type === 'Polygon') rings.push(...(geometry.coordinates || []));
      else if (geometry.type === 'MultiPolygon') {
        for (const polygon of geometry.coordinates || []) rings.push(...polygon);
      }
    };
    if (geojson?.type === 'FeatureCollection') for (const feature of geojson.features || []) addGeometry(feature.geometry);
    else if (geojson?.type === 'Feature') addGeometry(geojson.geometry);
    else addGeometry(geojson);
    return rings.filter(ring => Array.isArray(ring) && ring.length >= 2 && ring.every(point => Array.isArray(point) && Number.isFinite(Number(point[0])) && Number.isFinite(Number(point[1]))));
  }
  const api = {COLORS, projection, screen, zoomAt, visiblePoints, labels, routeLabels, topologyRings, geoJSONRings, placeLevel, levelRank, minimumZoom};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.GhostMapGeometry = api;
})(globalThis);
