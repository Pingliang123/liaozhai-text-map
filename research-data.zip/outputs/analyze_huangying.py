"""Exploratory vocabulary and manually selected narrative anchors for 黃英."""
import argparse
import hashlib
import json
from pathlib import Path
from analyze_liaozhai import CJK, LEXICONS, hits, parse

GARDEN_WORDS = ['園', '圃', '畦', '院', '庭']
TERMS = ['菊', '花', '圃', '畦', '園', '院', '庭', '門', '牆', '舍',
         '貧', '富', '清', '濁', '市', '肆', '賣', '售', '賈', '歸', '金']
PLACES = ['順天', '金陵', '河朔', '東粵', '都中', '南第', '北院', '閨中']
ANCHORS = [
    ('寄居', '第南有荒圃'),
    ('生产交易', '聞其門囂喧如市'),
    ('住宅扩张', '舊日花畦，盡為廊舍'),
    ('跨宅管理', '於間壁開扉通南第'),
    ('两宅合并', '不分疆界矣'),
    ('重新分居', '於園中築茅茨'),
    ('重新合居', '遂復合居如初'),
    ('亲属照护', '攜入閨中'),
]


def analyze_case(chapters):
    story = next(c['story'] for c in chapters if c['title'] == '黃英')
    corpus = ''.join(c['story'] for c in chapters)
    length, total = len(CJK.findall(story)), len(CJK.findall(corpus))
    count, baseline = hits(story, GARDEN_WORDS), hits(corpus, GARDEN_WORDS)
    anchors = []
    for label, anchor in ANCHORS:
        start = story.index(anchor)
        anchors.append({'manual_label': label, 'anchor': anchor,
                        'character_offset': start,
                        'context': story[max(0, start-20):start+len(anchor)+45]})
    return {
        'title': '黃英', 'cjk_characters': length, 'corpus_cjk_characters': total,
        'terms': {term: story.count(term) for term in TERMS},
        'place_forms': {term: story.count(term) for term in PLACES},
        'garden_dictionary': GARDEN_WORDS, 'garden_count': count,
        'corpus_garden_count': baseline,
        'garden_per_10000_cjk': round(count / length * 10000, 2),
        'corpus_garden_per_10000_cjk': round(baseline / total * 10000, 2),
        'garden_rate_ratio': round((count / length) / (baseline / total), 2),
        'original_spatial_groups': {group: hits(story, words) for group, words in LEXICONS.items()},
        'manual_narrative_anchors': anchors,
        'limitations': [
            'Exploratory dictionary chosen after reading this story; not a significance test.',
            'Corpus baseline includes 黃英. Counts are literal strings, not semantic events.',
            'The 山 occurrence is in 玉山傾倒, a metaphor, not a geographic mountain.',
            '金 occurs inside 金陵; its frequency cannot be used as a wealth count.',
            'Manual labels and anchors describe interpretation, not automated relation extraction.',
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    data = args.source.read_bytes()
    result = analyze_case(parse(data.decode('utf-8-sig')))
    result['source_sha256'] = hashlib.sha256(data).hexdigest()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / 'huangying_data.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'title': result['title'], 'cjk_characters': result['cjk_characters'],
                      'garden_count': result['garden_count'], 'rate_ratio': result['garden_rate_ratio']}, ensure_ascii=True))


if __name__ == '__main__':
    main()
