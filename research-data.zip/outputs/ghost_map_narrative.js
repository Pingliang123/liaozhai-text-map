(function(root) {
  'use strict';
  const COLORS=['#176bb0','#a33b22','#7042b8','#008477','#8b6200','#b32973'];
  const color = key => COLORS[[...String(key)].reduce((n,c)=>(n*31+c.charCodeAt(0))>>>0,0)%COLORS.length];
  // Earlier close readings predate explicit transition fields. These exact
  // quotations identify movement without supplying an unmentioned origin.
  const LEGACY_MOVES = new Map([
    ['公力疾乘马从去，路甚生疎，至一城郭，如王者都。',['路（具体地名未明）','陌生城郭']],
    ['至安丘，遇雨，避身逆旅。',['出发地未明','安丘逆旅']],
    ['马欣动，即刻治装，从客至金陵。',['家（具体地名未明）','金陵']],
    ['于间壁开扉通南第，日过课其仆。',['马宅','南第']]
  ]);
  function movement(row) {
    const route=LEGACY_MOVES.get(row.quote);
    return row.transition_kind===undefined && route ? {...row,transition_kind:'movement',from_space:route[0],to_space:route[1]} : row;
  }
  function actorLabels(text) {
    const labels=[], stack=[]; let label='';
    const closing={'（':'）','(':')','[':']','【':'】'};
    for(const ch of text || '') {
      if(closing[ch]) stack.push(closing[ch]);
      else if(stack.length && ch===stack[stack.length-1]) stack.pop();
      if(!stack.length && /[、，,；;]/.test(ch)) { if(label.trim()) labels.push(label.trim()); label=''; }
      else label+=ch;
    }
    if(label.trim()) labels.push(label.trim());
    return [...new Set(labels)];
  }
  function actors(chapter,row) {
    return [...new Set(actorLabels(row.actors).map(label=>{
      const person=(chapter.people || []).find(p=>p.word===label && p.canonical);
      return person ? person.canonical : label;
    }))];
  }
  function space(row) {
    const label=(row.to_space || row.space || '').trim();
    let access='待核',realm='待核';
    if (/家|闺|卧|寝|内室|宅|私第/.test(label)) access='私人';
    else if (/街|市集|市场|朝堂|公堂|衙署|官署|考场/.test(label)) access='公共';
    else if (/寺|庙|客店|旅店|书斋|园|廊/.test(label)) access='混合';
    else if (/野|山|林|江|河|海|岸/.test(label)) access='开放自然';
    if (/阴司|阴间|冥司|冥府|冥间|地府|地狱|天宫|天庭|龙宫|仙境|仙岛|罗刹|海市|夜叉国/.test(label)) realm='异境';
    const accessSource=row.space_review_source || (row.space_access ? 'saved' : 'lexical');
    const realmSource=row.space_review_source || (row.space_realm ? 'saved' : 'lexical');
    return {access:row.space_access || access,realm:row.space_realm || realm,
      accessReviewed:!!row.space_access && accessSource !== 'deepseek',
      realmReviewed:!!row.space_realm && realmSource !== 'deepseek',
      accessAiReviewed:accessSource === 'deepseek', realmAiReviewed:realmSource === 'deepseek',
      accessSource,realmSource,label,
      accessStatus:row.space_review_source === 'deepseek' ? (row.space_access === '待核' ? 'AI核查后待核' : 'AI已分类') : row.space_access && row.space_access !== '待核' ? '保存标注' : access === '待核' ? '尚未完成分类' : '词汇推测',
      realmStatus:row.space_review_source === 'deepseek' ? (row.space_realm === '待核' ? 'AI核查后待核' : 'AI已分类') : row.space_realm && row.space_realm !== '待核' ? '保存标注' : realm === '待核' ? '尚未完成分类' : '词汇推测',
      interpretation:row.space_function || row.interpretation || ''};
  }
  function endpoint(label, binding, places, model) {
    if (binding) return places.find(p=>p.id===binding) || null;
    const term=model.name(model.simplify((label || '').trim()));
    // Never use a chapter's birthplace as a missing endpoint, or substring-match generic scenes.
    const exact=places.filter(p=>model.name(p.name)===term);
    if(exact.length===1) return {...exact[0],route_binding:'exact'};
    const candidates=places.filter(p=>{
      const word=model.name(p.name);
      const suffix=term.slice(word.length);
      return word.length>=2 && term.startsWith(word) && !/^(?:至|去|往|赴|离|出|自)/.test(suffix) && /^(?:府|县|城|家|宅|村|北郭|南郭|东郭|西郭|境内|故里|寓所|客店|旅舍|官署|寺|庙|山中|城外|城中|（|\(|[\p{Script=Han}]{1,4}(?:家|宅))/u.test(suffix);
    }).sort((a,b)=>b.name.length-a.name.length);
    if(candidates.length && (!candidates[1] || candidates[0].name.length>candidates[1].name.length)) return {...candidates[0],route_binding:'region'};
    return null;
  }
  function rows(model,chapters,places) {
    return chapters.flatMap(c=>(c.narrative_events || []).map((input,index)=>{
      let row=movement(input);
      let from=endpoint(row.from_space,row.from_place_id,places,model);
      const to=endpoint(row.to_space,row.to_place_id,places,model);
      // If a place occurs only once as “X人”, it establishes origin, not departure.
      if(from && !row.from_place_id && row.quote?.includes(from.name+'人') && row.quote.split(from.name).length===2) {
        row={...row,from_space:'出发地未明（'+from.name+'仅见籍贯）'};from=null;
      }
      return {...row,chapter_id:c.chapter_id,chapter:c.chapter,index,actorsList:actors(c,row),classification:space(row),from,to};
    }));
  }
  function eventDates(row,base,place) {
    return (base.chronology?.records || []).filter(d=>d.chapter_id===row.chapter_id && Number.isFinite(d.year_start) && Number.isFinite(d.year_end ?? d.year_start) &&
      d.unit>=row.unit && d.unit<=(row.unit_end ?? row.unit) && d.places?.some(p=>p===place.name) &&
      /事件|故事时代/.test(d.time_role || '') && !/背景|讲述|人物经历|引典|作者|待核/.test(d.time_role || '') && /已.*原文|人工.*确认/.test(d.review_status || '') && d.ai_review?.label!=='rejected');
  }
  function relations(rows,place,base) {
    if (!place) return [];
    const at=rows.filter(r=>(r.from?.id===place.id || r.to?.id===place.id) && r.transition_kind==='movement');
    const result=[];
    for(let i=0;i<at.length;i++) for(let j=i+1;j<at.length;j++) {
      const a=at[i],b=at[j];
      if(a.chapter_id===b.chapter_id) continue;
      const da=eventDates(a,base,place), db=eventDates(b,base,place);
      const overlap=da.some(x=>db.some(y=>x.year_start<=(y.year_end ?? y.year_start) && y.year_start<=(x.year_end ?? x.year_start)));
      const distinct=da.length && db.length && !overlap;
      result.push({a,b,time:overlap?'所引纪年范围重叠，待核是否同时':distinct?'所引纪年范围不重叠':'时间不足，无法判断同时',datesA:da,datesB:db});
    }
    return result;
  }
  const api={actorLabels,actors,space,endpoint,rows,relations,eventDates,color,movement};
  if(typeof module!=='undefined' && module.exports) module.exports=api;else root.GhostMapNarrative=api;
})(globalThis);
