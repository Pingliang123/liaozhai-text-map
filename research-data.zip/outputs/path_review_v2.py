"""Source-bound, resumable endpoint audits; shared remaining authorization."""
import argparse
import getpass
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib import request
import unicodedata

ROOT = Path(__file__).parent
DATA = ROOT / 'ghost_map'
OUT = DATA / '空间双端_AI审核.json'
BUDGET = DATA / '空间双端_AI预算.json'
ACCESS = {'私人', '公共', '混合', '开放自然', '待核'}
REALMS = {'人间', '异境', '待核'}
TYPES = {'家宅', '卧室内室', '书斋', '庭院园林', '道路街市', '官署考场', '寺观', '旅店', '自然山野', '水域', '异境场所', '城郭聚落', '其他', '待核'}
TYPE_ALIASES = {'官署': '官署考场', '府署': '官署考场', '考场': '官署考场', '寺庙': '寺观', '客店': '旅店', '庭院': '庭院园林', '园林': '庭院园林', '卧室': '卧室内室'}


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()


def identity(cid, event):
    return digest([cid, event.get('unit'), event.get('unit_end', event.get('unit')),
                   *[event.get(k, '') for k in ('quote', 'actors', 'from_space', 'to_space', 'space', 'event')]])


def source_hash(chapter):
    return digest([[u['unit'], u['text']] for u in chapter['source_units']])


def valid_review(row, event, chapter):
    return row.get('id') == identity(chapter['chapter_id'], event) and row.get('source_hash') == source_hash(chapter)


def prompt(chapter, events):
    items = [{'id': identity(chapter['chapter_id'], e), **{k: e.get(k, '') for k in
              ('actors', 'from_space', 'to_space', 'space', 'event', 'quote', 'transition_kind')}} for e in events]
    return ('逐步核查《聊斋志异》的空间。必须读篇内语境，给出转移出发端from与到达/当前端to的使用方式、世界和统一场所类型。'
            '私人指进入/控制受家庭或个人限制；公共指面向公众或制度活动；混合须确有兼具性质，不能凡寺庙书斋就混合；'
            '开放自然指山野水域等开放环境。有人鬼妖神出现不等于异境；人间闹鬼仍是人间。'
            '无法判断用待核；没有出发空间的非移动步骤from各字段均待核。保留原有空间名称，不改写事件，不新增事件。'
            '每个id都返回，id必须逐字复制；quote请从输入步骤quote中逐字复制一段连续短句（40字内），不能改写、不能用省略号拼接。JSON格式 {"reviews":[{"id":"输入id","from_access":"待核","to_access":"私人",'
            '"from_realm":"待核","to_realm":"人间","from_type":"待核","to_type":"家宅",'
            '"quote":"连续原文依据","reason":"40字内解释"}]}。'
            'access只用'+','.join(sorted(ACCESS))+'；realm只用'+','.join(sorted(REALMS))+
            '；type只用'+','.join(sorted(TYPES))+'。统一类型仅用于跨篇比较，不代表两个原文空间同一地点。'
            '\n篇名：'+chapter['chapter']+'\n步骤：'+json.dumps(items, ensure_ascii=False)+
            '\n全文：'+''.join(u['text'] for u in chapter['source_units']))


def validate(payload, chapter, events):
    requested = {identity(chapter['chapter_id'], e): e for e in events}
    full = ''.join(u['text'] for u in chapter['source_units'])
    result = {}
    for row in payload.get('reviews', []):
        if not isinstance(row, dict) or row.get('id') not in requested:
            continue
        row = dict(row)
        aliases = {}
        for side in ('from', 'to'):
            field = side+'_type'
            if row.get(field) in TYPE_ALIASES:
                aliases[field] = row[field]
                row[field] = TYPE_ALIASES[row[field]]
        if any(row.get(side+'_'+field) not in choices for side in ('from', 'to')
               for field, choices in [('access', ACCESS), ('realm', REALMS), ('type', TYPES)]):
            continue
        evidence = row.get('quote', '')
        if evidence and evidence not in full:
            # Restore punctuation only, retaining a unique continuous source
            # span; no synonym replacement or fabricated characters.
            compact = lambda text: ''.join(ch for ch in text if not ch.isspace() and not unicodedata.category(ch).startswith('P'))
            chars = [(i, ch) for i, ch in enumerate(full) if compact(ch)]
            flattened = ''.join(ch for i, ch in chars)
            needle = compact(evidence)
            hit = flattened.find(needle) if needle else -1
            if hit >= 0 and flattened.find(needle, hit+1) < 0:
                evidence = full[chars[hit][0]:chars[hit+len(needle)-1][0]+1]
        if not evidence or evidence not in full or not row.get('reason'):
            continue
        result[row['id']] = {k: row[k] for k in ('id', 'from_access', 'to_access', 'from_realm', 'to_realm', 'from_type', 'to_type', 'quote', 'reason')}
        result[row['id']].update(source_hash=source_hash(chapter), chapter_id=chapter['chapter_id'], reviewer='deepseek-flash')
        if aliases: result[row['id']]['type_aliases'] = aliases
        result[row['id']]['quote'] = evidence
        if not requested[row['id']].get('from_space'):
            for field in ('access', 'realm', 'type'): result[row['id']]['from_'+field] = '待核'
    return list(result.values())


def save(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def call(key, chapter, events, maximum):
    body = {'model': 'deepseek-flash', 'thinking': {'type': 'disabled'}, 'messages': [
        {'role': 'system', 'content': '依据古文全文核查空间，仅返回JSON。'},
        {'role': 'user', 'content': prompt(chapter, events)}], 'response_format': {'type': 'json_object'}, 'max_tokens': maximum}
    req = request.Request('https://api.deepseek.com/chat/completions', data=json.dumps(body, ensure_ascii=False).encode('utf-8'),
                          headers={'Content-Type': 'application/json', 'Authorization': 'Bearer '+key})
    with request.urlopen(req, timeout=180) as response:
        raw = json.loads(response.read())
    return raw


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--max-tokens', type=int, default=4000)
    parser.add_argument('--workers', type=int, default=6)
    parser.add_argument('--batch-size', type=int, default=8)
    args = parser.parse_args()
    if not 1 <= args.workers <= 8 or not 2000 <= args.max_tokens <= 10000 or not 1 <= args.batch_size <= 8:
        parser.error('worker/token limit')
    key = getpass.getpass('DeepSeek API key: ')
    data = json.loads((DATA/'歷史地名對照與文本地圖.json').read_text(encoding='utf-8'))
    cached = json.loads(OUT.read_text(encoding='utf-8')) if OUT.exists() else {'reviews': []}
    reviews = {r['id']: r for r in cached['reviews']}
    old = json.loads((DATA/'空间路径_AI审核_预算.json').read_text(encoding='utf-8'))
    prior = sum(a.get('cost_upper_bound_usd', a.get('reserved_usd', 0)) for a in old['attempts'])
    ledger = json.loads(BUDGET.read_text(encoding='utf-8')) if BUDGET.exists() else {'cap_total_usd': 5.95, 'prior_path_upper_bound_usd': prior, 'attempts': [], 'pricing_source': 'https://api-docs.deepseek.com/quick_start/pricing/', 'model': 'deepseek-flash'}
    used = prior + sum(a.get('cost_upper_bound_usd', a['reserved_usd']) for a in ledger['attempts'])
    jobs = []
    for c in data['chapter_overview']:
        needed = [e for e in c['narrative_events'] if (e.get('space_review_source') != 'deepseek' or e.get('transition_kind') == 'movement')
                  and not valid_review(reviews.get(identity(c['chapter_id'], e), {}), e, c)]
        for start in range(0, len(needed), args.batch_size): jobs.append((c, needed[start:start+args.batch_size]))
    print(f'jobs={len(jobs)} cached={len(reviews)} combined_upper=${used:.4f}/5.95', flush=True)
    # Reserve before dispatch, including in-flight calls. Unknown failures keep
    # the entire reservation. Accurate API usage refunds only known tokens.
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        pending = {}
        for chapter, events in jobs:
            reserve = (len(prompt(chapter, events).encode('utf-8'))*.3 + 2048*.3 + args.max_tokens*1.2)/1e6
            if used + reserve > 5.95:
                if not pending: break
            else:
                attempt = {'ids': [identity(chapter['chapter_id'], e) for e in events], 'source_hash': source_hash(chapter), 'reserved_usd': reserve, 'status': 'reserved'}
                ledger['attempts'].append(attempt); used += reserve; save(BUDGET, ledger)
                pending[pool.submit(call, key, chapter, events, args.max_tokens)] = (chapter, events, attempt)
            if len(pending) < args.workers: continue
            done = next(as_completed(pending))
            finish(done, pending, reviews, ledger)
            used = prior + sum(a.get('cost_upper_bound_usd', a['reserved_usd']) for a in ledger['attempts'])
        for done in as_completed(pending): finish(done, pending, reviews, ledger)
    print(f'cached={len(reviews)} combined_upper=${prior+sum(a.get("cost_upper_bound_usd",a["reserved_usd"]) for a in ledger["attempts"]):.4f}', flush=True)


def finish(done, pending, reviews, ledger):
    chapter, events, attempt = pending.pop(done)
    try:
        raw = done.result()
        usage = raw.get('usage', {})
        p, c = usage.get('prompt_tokens'), usage.get('completion_tokens')
        if type(p) is int and type(c) is int and p >= 0 and c >= 0:
            attempt['cost_upper_bound_usd'] = (p*.3+c*1.2)/1e6
        content = raw['choices'][0]['message']['content'].strip()
        if content.startswith('```'): content = content[content.find('\n')+1:].rsplit('```',1)[0]
        parsed = json.loads(content)
        rows = validate(parsed, chapter, events)
        accepted_ids = {r['id'] for r in rows}
        attempt['rejected_samples'] = [r for r in parsed.get('reviews', []) if isinstance(r, dict) and r.get('id') not in accepted_ids][:1]
        reviews.update({r['id']: r for r in rows}); attempt.update(status='accepted', accepted=len(rows), usage=usage)
    except Exception as exc:
        attempt.update(status='failed', error=type(exc).__name__)
    save(OUT, {'schema_version': 2, 'reviews': list(reviews.values())}); save(BUDGET, ledger)
    print(f'chapter={chapter["chapter_id"]} accepted={attempt.get("accepted",0)}/{len(events)} cached={len(reviews)} status={attempt["status"]}', flush=True)


if __name__ == '__main__': main()
