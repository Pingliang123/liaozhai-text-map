"""Audit coordinate identity separately from the existence of a gazetteer hit.

The narrative excerpts below explain editorial decisions. They are not an
automatic inference of journeys or event locations. Original matches survive.
"""
import math
import re
from opencc import OpenCC

NORMAL = OpenCC('t2s').convert
DOCS = 'https://chgis.hudci.org/tgw/'
LEVEL_NAMES = {'province': '省域', 'prefecture': '府／直隶州', 'county': '县／散州',
               'town': '村镇', 'village': '村落', 'natural': '山川水域',
               'region': '文化区域', 'unknown': '层级待核'}
RANK = {'province': 1, 'prefecture': 2, 'county': 3, 'town': 4, 'village': 5,
        'region': 1, 'natural': 2, 'unknown': 6}

# Directional/generic names and homonyms which contradict the excerpt. Do not
# transfer the place token to space_words without a chapter-level review.
WITHDRAW = {
    '东门': '《蕙芳》明确为“居青州东门内”，不能定位为施南府东门关。',
    '寺': '《房文淑》“游学至兖，寓败寺中”，是场景泛称，不能对应同州寺前镇。',
    '南湖': '《荷花三娘子》由湖州居所赴南湖采菱，不能用甘肃安西的同名村镇定位。具体湖泊待考。',
    '南村': '四篇的南村均缺少统一指向，不能把多个村庄汇成河南府南村关。',
    '西山': '《云翠仙》由岱山叙事至西山；另两篇未证同地。不能统一定位广东罗定。',
    '山南': '《农人》为“后数年，山南有贵家女”，未证对应甘州山南关。',
    '都城': '《白于玉》的都城是都邑称谓，未证对应广东罗定同名村。',
    '灵山': '《鸮鸟》“天上有灵山”属于歌谣文本空间，不能对应广西灵山县。',
    '辽城': '《辽阳军》“辽城陷”应在辽东战争语境核对，不能对应河南彰德辽城村。',
    '大佛寺': '《赌符》未交代该寺所在地，不能仅凭同名将其定位云南藏传寺院。',
    '平城': '《冷生》只言“平城冷生”，不足以确认甘肃凉州平城堡，需查注本。',
    '安村': '《雹神》“安村外有关圣祠”，未证对应杭州临安县同名村。',
    '苏溪': '《陆判》“苏溪杨大年”未证对应湖南宝庆府的唯一检索结果。',
    '龙窝': '《晚霞》出现的是人物称号“龙窝君”，不能据截词定位广东惠州龙窝村。',
    '龙津': '《老龙舡户》“源自老龙津，以达南海”“由此入粤”不支持江西饶州同名村；广东具体津渡待考。',
    '金山': '《晚霞》“至金山下，堕水死”指山水地标，不能直接认作上海金山县；山岳指向待考。',
    '蒙山': '《牛癀》“蒙山人”不能对应广西蒙山堡；山东、山西等同名山仍需注本核定。',
    '保定': '保定府、顺天府保定县是不同地名，两篇只言保定，原先任选县级结果的依据不足。',
    '东安': '《席方平》只言“东安人”，河北、湖南、广东均有同名县，不能任选河北。',
    '桃源': '《刘夫人》实指地名，《臙脂》为“桃源之路”典故，不能以同一湖南县点统摄两篇。',
    '长安市': '《鼠戏》“长安市上卖鼠戏”需辨长安之市还是专名；未证对应浙江武康的长安市镇。',
    '兰陵': '《田子成》“乃歌兰陵美酒之什”引用诗句，不证明该篇发生在兰陵集。地名典故保留原文待核。',
}

CORRECTIONS = {
    '兖': dict(lon=116.8237, lat=35.5567, admin_level='prefecture', type='city', modern_name='兖州（城名参考）',
                source_url='https://chgis.hudci.org/tgaz/placename/hvd_86005',
                reason='《房文淑》“游学至兖”按兖州城名参考；采用库载兖州府所在地，不以单字任意前缀扩词。'),
    '浙': dict(lon=120.16862, lat=30.29412, admin_level='province', type='region', modern_name='浙（浙江省域参考）',
                source_url='https://chgis.hudci.org/tgaz/placename/hvd_30015',
                reason='浙作浙江区域简称，保留原词条及省域参考点；不与浙江词条合并，也不解释成县级地点。'),
    '齐': dict(lon=118.0, lat=36.4, admin_level='region', type='region', modern_name='齐地（山东区域参考）',
               source_url='https://chgis.fas.harvard.edu/pages/database/',
               reason='《饿鬼》“马永，齐人”是齐地籍贯称谓；齐尔拉只是字符串前缀匹配。改为山东区域近似点，具体郡县待考。'),
    '晋': dict(lon=112.56, lat=37.87, admin_level='province', type='region', modern_name='晋地（山西省域参考）',
                source_url='https://fdi.mofcom.gov.cn/resource/pdf/2020/10/21/4f27926a078d414b9c147dfb8ff65163.pdf',
                reason='《仇大娘》言“晋人，忘其郡邑”及“为晋第一”，按省域籍贯理解；河北晋州的自动扩词定位停用。'),
    '闽': dict(lon=118.3, lat=26.1, admin_level='province', type='region', modern_name='闽（福建省域参考）',
                source_url='https://www.fujian.gov.cn/zjfj/',
                reason='《神女》“闽人，传者忘其名字、郡邑”及“闽中巡抚”，指福建区域，不能缩小到闽县。'),
    '楚': dict(lon=112.8, lat=29.0, admin_level='region', type='region', modern_name='楚地（湖广区域参考）',
                source_url='https://mzt.hunan.gov.cn/yw/qhdm/200812/t20081226_3722479.html',
                reason='《菱角》“胡大成，楚人”为历史地域称谓。楚雄府只是前缀匹配；改湖广区域近似点，郡县待考。'),
    '洛': dict(lon=112.45, lat=34.62, admin_level='prefecture', type='city', modern_name='洛阳（城名参考）',
                source_url=DOCS,
                reason='《葛巾》“常大用，洛人”“约会于洛”“牡丹之盛，洛下无双”，结合牡丹语境按洛阳城参考，停用陕西洛川县结果；城名不自动等于府域。'),
    '彭城': dict(lon=117.18, lat=34.26, admin_level='prefecture', type='city', modern_name='彭城／今徐州（城名参考）',
                  source_url='https://www.zgjssw.gov.cn/shixianchuanzhen/xuzhou/202408/t20240805_8371438.shtml',
                  reason='《书痴》“彭城郎玉柱”按徐州古城名参考，停用河北广平府彭城镇；城名不证明清代府域。'),
    '瓜州': dict(lon=119.4, lat=32.24, admin_level='town', type='settlement', modern_name='瓜洲渡／今扬州瓜洲（候选参考）',
                  source_url='https://gjgz.jszwfw.gov.cn/',
                  reason='《霍女》舟行、片帆、金陵行程支持长江瓜洲渡的读法；停用甘肃瓜州口。按行程校读的候选参考，字形及古渡位置待考。'),
}


def compatible_name(word, match):
    """Only explicit administrative suffixes can expand a textual name."""
    candidate = NORMAL(match.get('name', ''))
    return candidate == word or candidate in {word + s for s in ('省', '府', '县', '州', '厅', '镇', '村')}


def valid(match):
    try:
        lon, lat = float(match['lon']), float(match['lat'])
        return math.isfinite(lon) and math.isfinite(lat) and 70 <= lon <= 140 and 15 <= lat <= 55
    except (KeyError, TypeError, ValueError):
        return False


def qing_match(word, matches, reference=None):
    rows = [m for m in matches if valid(m) and compatible_name(word, m) and m.get('data_source', 'CHGIS') == 'CHGIS']
    # An existing selection is an identity, not just another search string.
    # Exact bare-name villages must not replace a previously selected county.
    if reference:
        selected_uri = (reference.get('selected_history_match') or {}).get('uri') or reference.get('source_url')
        existing = next((m for m in rows if m.get('uri') and m['uri'] == selected_uri), None)
        if existing:
            return existing
    def score(m):
        years = [int(n) for n in re.findall(r'-?\d+', m.get('years', ''))]
        covers = len(years) == 2 and years[0] <= 1820 <= years[1]
        distance = math.hypot(float(m['lon']) - reference['lon'], float(m['lat']) - reference['lat']) if reference else 0
        return (-distance, covers, m.get('years') == '1820 ~ 1820', NORMAL(m.get('name', '')) == word)
    return max(rows, key=score) if rows else None


def historical_level(match):
    feature = NORMAL(match.get('feature_type', ''))
    parent = NORMAL(match.get('parent_name', '')).split(' (')[0]
    if '省' in feature: return 'province', '省域'
    if '府' in feature or '直隶州' in feature: return 'prefecture', '府' if '府' in feature else '直隶州'
    if '县' in feature: return 'county', '县'
    if '州' in feature:
        return ('county', '散州（库载隶属府，按县级展示）') if parent.endswith('府') else ('prefecture', '州（直隶／散州待核）')
    if '厅' in feature: return 'unknown', '厅（直隶／散厅待核）'
    if '村' in feature or '镇' in feature: return 'town', '村镇（原库合类，未细分）'
    if any(s in feature for s in ('山', '河', '湖', '海')): return 'natural', '山川水域'
    return 'unknown', '层级待核'


def audit(places, chapters, searches):
    reviewed, withdrawn, report = [], [], []
    for p in places:
        name = p['name']
        examples = [{'chapter_id': c['chapter_id'], 'chapter': c['chapter'], 'unit': u['unit'], 'quote': u['text']}
                    for c in chapters if c['chapter_id'] in p['chapter_ids']
                    for u in c['source_units'] if name in u['text']][:5]
        matches = searches.get(name, {}).get('matches', [])
        original = {'lon': p['lon'], 'lat': p['lat'], 'name': p.get('modern_name'), 'source_url': p.get('source_url')}
        result = {'name': name, 'previous': original, 'evidence': examples, 'status': 'reference',
                  'note': '已检查坐标有效性、名称及库载类型；参考点不证明每篇指向或故事时代隶属。'}
        if name in WITHDRAW:
            result.update(status='withdrawn', note=WITHDRAW[name])
            withdrawn.append({'place': name, 'chapter_ids': p['chapter_ids'], 'search_name': name,
                              'reason': '尚无已核实的人间地理对照；' + WITHDRAW[name],
                              'historical_search': searches.get(name, {}), 'location_audit': result})
            report.append(result)
            continue
        if name in CORRECTIONS:
            rule = CORRECTIONS[name]
            p.update({k: v for k, v in rule.items() if k != 'reason'})
            p.update(note=rule['reason'], coordinate_kind='approximate', confidence='medium',
                     source='原文语境校读＋历史地理资料，区域或城名参考', mapping_source='text_context_review',
                     mapping_review_status='原文语境已校读；古称／区域参考，具体篇内位置仍待核')
            # Do not retain the rejected candidate as selected provenance.
            p.pop('selected_history_match', None)
            result.update(status='corrected', note=rule['reason'])
            target = {'洛': '洛阳', '彭城': '徐州', '晋': '山西', '闽': '福建', '瓜州': '瓜洲'}.get(name)
            match = qing_match(target, searches.get(target, {}).get('matches', []), p) if target else None
            if match: p['level_source_url'] = match.get('uri', DOCS)
        else:
            selected = qing_match(name, matches, p)
            if name in {'广陵', '金陵'}:
                alias = '扬州' if name == '广陵' else '江宁'
                selected = qing_match(alias, searches.get(alias, {}).get('matches', []), p)
            if name == '临洮':
                p.update(admin_level='county', historical_type_label='今临洮县参考（清代狄道县，临洮府另地）',
                         historical_parent_warning='此词古今指向不同，既有点仅为今临洮参考；不能作为清代临洮府位置。')
                result.update(status='ambiguous', note='临洮古今指向不同，现代参考点与清代府名不等同，逐篇待核。')
            if p.get('mapping_source') == 'historical_search_auto_promoted':
                if not selected:
                    result.update(status='withdrawn', note='原记录是前缀或非 CHGIS 同名匹配，缺少可确认的地名身份。')
                    withdrawn.append({'place': name, 'chapter_ids': p['chapter_ids'], 'search_name': name,
                                      'reason': '尚无已核实的人间地理对照；' + result['note'],
                                      'historical_search': searches.get(name, {}), 'location_audit': result})
                    report.append(result)
                    continue
                p.update(lon=float(selected['lon']), lat=float(selected['lat']), selected_history_match=selected,
                         source_url=selected.get('uri') or p['source_url'],
                         modern_name=f"{NORMAL(selected.get('name', name))}（清代候选）",
                         region_description='库载隶属：' + NORMAL(selected.get('parent_name') or '待核'))
            if name == '安丘' and selected:
                p['type'] = 'historical-county'
            if selected and p['type'] not in {'mountain', 'lake', 'river', 'sea', 'region'}:
                level, label = historical_level(selected)
                p.update(admin_level=level, historical_type_label=label, level_source_url=selected.get('uri', DOCS),
                         level_history_match=selected,
                         historical_parent_name=NORMAL(selected.get('parent_name', '')).split(' (')[0],
                         hierarchy_year=1820)
                if selected.get('years') != '1820 ~ 1820':
                    p['hierarchy_year'] = None
                    p['historical_parent_warning'] = '库载年代为' + (selected.get('years') or '未提供') + '；层级仅供参考，未确认为1820年或故事年代隶属。'
                distinct = {(round(float(m['lon']), 1), round(float(m['lat']), 1)) for m in matches
                            if valid(m) and compatible_name(name, m)}
                if len(distinct) > 1:
                    result.update(status='ambiguous', note='有不同坐标的同名行政记录；当前保留参考点，篇目指向仍待核。')
                elif p.get('mapping_source') == 'historical_search_auto_promoted':
                    result.update(status='gazetteer_checked', note='已核对名称、有效坐标与 CHGIS 类型。库载参考点仍需逐篇确认。')
            if p['type'] == 'region' and name not in {'江南', '江北'}: p.setdefault('admin_level', 'province')
            if p['type'] in {'mountain', 'lake', 'river', 'sea'}: p['admin_level'] = 'natural'
        if p.get('selected_history_match'):
            parent = p.get('historical_parent_name', '')
            # Some time-series parent labels are inherited from older slices.
            if parent and any(s in parent for s in ('行省', '越州', '江南省')):
                p['historical_parent_warning'] = '该父级名可能沿用较早年代记录，未作为清代包含关系。'
        p['location_audit'] = result
        result['current'] = {k: p.get(k) for k in ('lon', 'lat', 'admin_level', 'modern_name', 'source_url')}
        reviewed.append(p)
        report.append(result)
    return reviewed, withdrawn, {'checked': len(report), 'corrected': sum(r['status'] == 'corrected' for r in report),
                                 'withdrawn': len(withdrawn), 'ambiguous': sum(r['status'] == 'ambiguous' for r in report),
                                 'rows': report, 'method': '全部参考点按名称、类型、坐标和同名记录筛查；错配项结合原文复核。未逐篇核定全部故事地点。'}
