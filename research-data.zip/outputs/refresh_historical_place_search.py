"""Refresh historical-place search evidence for every currently unmapped term.

The search is deliberately an audit layer, not an automatic geocoder.  The
source API accepts a year, so 1820 is used as a Qing-period priority snapshot.
Every query is converted to Traditional Chinese before it is sent.  Multiple
same-name records remain visible for manual disambiguation by chapter context.
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path

from opencc import OpenCC

ROOT = Path(__file__).parent
DATA = ROOT / "ghost_map"
OUTPUT = DATA / "未定位地名_历史检索.json"
API_ROOT = "https://chgis.hudci.org/tgaz/placename"
SOURCE_URL = "https://chgis.hudci.org/tgaz/"
S2T = OpenCC("s2t").convert
T2S = OpenCC("t2s").convert


def query_url(term: str, year: int = 1820) -> str:
    return API_ROOT + "?" + urllib.parse.urlencode(
        {"n": term, "yr": str(year), "fmt": "json"}
    )


def parse_coordinates(value: str | None) -> tuple[float | None, float | None]:
    try:
        lon, lat = (float(part.strip()) for part in (value or "").split(",", 1))
    except (ValueError, TypeError):
        return None, None
    if not (-180 <= lon <= 180 and -85 <= lat <= 85) or lon == 0:
        return None, None
    return lon, lat


def normalize_match(match: dict) -> dict:
    lon, lat = parse_coordinates(match.get("xy coordinates"))
    return {
        "record_id": match.get("sys_id", ""),
        "uri": match.get("uri", ""),
        "name": S2T(match.get("name", "")),
        "api_name": match.get("name", ""),
        "years": match.get("years", ""),
        "feature_type": S2T(match.get("feature type", "")),
        "parent_name": S2T(match.get("parent name", "")),
        "coordinates": match.get("xy coordinates", ""),
        "lon": lon,
        "lat": lat,
        "data_source": match.get("data source", ""),
    }


def fetch(record: dict, year: int = 1820) -> dict:
    term = record["query_traditional"]
    url = query_url(term, year)
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "LiaozhaiTextMap/1.0"})
        with urllib.request.urlopen(request, timeout=12) as response:
            payload = json.load(response)
        matches = [normalize_match(row) for row in payload.get("placenames", [])]
        status = "清代记录待人工核对" if matches else "清代无精确结果"
        return {**record, "query_url": url, "status": status, "matches": matches}
    except Exception as exc:  # Keep failed queries visible instead of hiding them.
        return {**record, "query_url": url, "status": "检索失败，需重试", "matches": [], "error": str(exc)}


def refresh(records: list[dict], year: int = 1820, workers: int = 12) -> dict:
    jobs = [{
        "word": row["place"],
        "query_traditional": S2T(row["place"]),
        "chapter_ids": row.get("chapter_ids", []),
    } for row in records]
    output: list[dict] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(fetch, job, year) for job in jobs]
        for future in as_completed(futures):
            output.append(future.result())
    output.sort(key=lambda row: row["word"])
    return {
        "schema_version": 1,
        "source": {
            "name": "Temporal Gazetteer（CHGIS，哈佛大学／复旦大学）",
            "url": SOURCE_URL,
            "api": API_ROOT,
            "documentation": "https://chgis.hudci.org/tgw/",
            "method": "将未定位词转为繁体后，以1820年清代代表年检索；同名记录不自动择定。",
        },
        "query_year": year,
        "queried_at": date.today().isoformat(),
        "count": len(output),
        "with_results": sum(bool(row["matches"]) for row in output),
        "records": output,
        "note": "检索结果是历史地名候选证据，不是《聊斋》故事发生地的自动判定；需结合篇目原文、人物行程与行政层级人工确认。",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=1820)
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    sys.path.insert(0, str(ROOT))
    from build_ghost_gis import build_payload

    payload = build_payload()
    refreshed = refresh(payload["unmapped_textual_places"], args.year, args.workers)
    args.output.write_text(json.dumps(refreshed, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: refreshed[k] for k in ("count", "with_results", "query_year", "queried_at")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
