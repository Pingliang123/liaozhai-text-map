(function(root){
  'use strict';
  const KINDS={spaces:'空间词',times:'时间词',places:'地点词',people:'人物词'};
  const clone=x=>JSON.parse(JSON.stringify(x));
  function source(c){return c.source_units.map(u=>u.text||u.original||'').join('');}
  function count(text,word){return word ? text.split(word).length-1 : 0;}
  function tokenCounts(c){
    const out=new Map();
    const add=w=>{if(w && /[\p{L}\p{N}]/u.test(w)) out.set(w,(out.get(w)||0)+1);};
    // A saved segmentation is an explicitly edited token stream; untouched units use their offsets.
    const strip=s=>s.replace(/[\s/|]+/gu,'');
    if(c.segmentation_note && strip(c.segmentation_note)===strip(source(c))){for(const w of c.segmentation_note.split(/[\s/|]+/u)) add(w.trim());}
    else for(const u of c.source_units){const text=u.text||u.original||'';for(const t of u.tokens||[]) add(text.slice(Array.isArray(t)?t[0]:t.start,Array.isArray(t)?t[1]:t.end));}
    return out;
  }
  function active(c,kind){
    return kind==='people' ? c.people.map(p=>p.word) : kind==='places' ? c.places.map(p=>p.word) : kind==='times' ? Object.keys(c.years||{}) : c.space_words||[];
  }
  function rows(base,model){
    const placeReason = (word,chapter) => (typeof module!=='undefined' && module.exports ? require('./ghost_map_model.js') : root.GhostMapModel).placeWordReason(word,chapter);
    const byChapter=new Map(model.ids.map(id=>[id,new Map()]));
    const originals=new Map(base.chapter_overview.map(c=>[c.chapter_id,c]));
    const owners=new Map(),tokensByChapter=new Map(),tokenOwners=new Map();
    for(const id of model.ids){const c=model.view(id),tokens=tokenCounts(c);tokensByChapter.set(id,tokens);for(const u of c.source_units) owners.set(u.unit,id);for(const word of tokens.keys()){if(!tokenOwners.has(word)) tokenOwners.set(word,new Set());tokenOwners.get(word).add(id);}}
    for(const [kind,panel] of Object.entries(base.candidate_review||{})){
      if(!['people','places','times'].includes(kind)) continue;
      for(const row of panel.rows||[]){
        const ids=new Set([...(row.chapter_ids||[]),...(row.examples||[]).map(e=>owners.get(e.unit)),...(tokenOwners.get(row.word)||[])]);
        for(const id of ids) if(byChapter.has(id)) byChapter.get(id).set(kind+':'+row.word,{kind,word:row.word,candidate:row});
      }
    }
    const out=[];
    for(const id of model.ids){
      const c=model.view(id), entries=byChapter.get(id), text=source(c), tokens=tokensByChapter.get(id);
      for(const kind of Object.keys(KINDS)) for(const word of active(originals.get(id),kind)) if(!entries.has(kind+':'+word)) entries.set(kind+':'+word,{kind,word});
      for(const kind of Object.keys(KINDS)) for(const word of active(c,kind)) entries.set(kind+':'+word,{...entries.get(kind+':'+word),kind,word});
      for(const key of Object.keys(c.lexical_reviews||{})){const split=key.indexOf(':');if(!entries.has(key)) entries.set(key,{kind:key.slice(0,split),word:key.slice(split+1)});}
      for(const [key,row] of entries){
        const present=active(c,row.kind).includes(row.word), review=c.lexical_reviews?.[key], person=row.kind==='people'?c.people.find(p=>p.word===row.word):null;
        const at=text.indexOf(row.word);
        const removed=!present && ((!review && active(originals.get(id),row.kind).includes(row.word))||review?.status==='accepted');
        const reason=row.kind==='places' ? placeReason(row.word,c.chapter) : '';
        out.push({...row,key,chapter_id:id,chapter:c.chapter,present,review,person,rejection_reason:reason,
          status:reason?'excluded':removed?'removed':review?.status || (present?'retained':'pending'),frequency:tokens.get(row.word)||0,mentions:count(text,row.word),
          context:at<0?'原文未找到此词，请核对候选例句。':text.slice(Math.max(0,at-35),Math.min(text.length,at+row.word.length+65))});
      }
    }
    return out;
  }
  function aggregate(rows){
    const groups=new Map();
    for(const r of rows){const key=r.kind+':'+r.word;let g=groups.get(key);if(!g){g={word:r.word,kind:r.kind,frequency:0,mentions:0,chapters:new Set()};groups.set(key,g);}g.frequency+=r.frequency;g.mentions+=r.mentions;g.chapters.add(r.chapter_id);}
    return [...groups.values()].map(g=>({...g,chapters:g.chapters.size})).sort((a,b)=>b.frequency-a.frequency||b.mentions-a.mentions||a.word.localeCompare(b.word,'zh'));
  }
  function splitValues(value){
    return [...new Set(String(value||'').split(/\s*(?:→|／|、|,|，|；|;)\s*/u).map(s=>s.trim()).filter(Boolean))];
  }
  function pathRows(base,model){
    const N=typeof module!=='undefined'&&module.exports?require('./ghost_map_narrative.js'):root.GhostMapNarrative;
    const out=[];
    const mapped=model.places();
    for(const id of model.ids){
      const c=model.view(id), events=N.rows(model,[c],mapped);
      events.forEach((event,index)=>{
        const from=String(event.from_space||'').trim(), to=String(event.to_space||'').trim();
        const values=splitValues([from,to,event.space].filter(Boolean).join(' → ')).filter(v=>! /未明|未标|不详|待核|未知|^无$/.test(v));
        const location=N.endpoint(event.location,'',mapped,model);
        const placesMentioned=[...new Set([event.from,event.to,location].filter(Boolean).map(p=>p.name))];
        const kind=event.transition_kind || 'scene', endpointReview=event.endpoint_review;
        const before={access:event.from_access||endpointReview?.from_access||'待核',realm:event.from_realm||endpointReview?.from_realm||'待核'};
        const fromType=event.from_type||endpointReview?.from_type||'待核',toType=event.to_type||endpointReview?.to_type||'待核';
        const classification=event.classification;
        out.push({chapter_id:id,chapter:c.chapter,step:index+1,unit:event.unit,actors:event.actors||'',location:event.location||'',space:event.space||'',from_space:from,to_space:to,transition_kind:kind,has_movement:kind==='movement',values,places:placesMentioned,event:event.event||'',quote:event.quote||'',classification,endpoint_review:endpointReview,step_id:event.step_id||'',
          from_access:before.access,from_realm:before.realm,from_type:fromType,to_type:toType,
          normalized_transition:kind==='movement'&&fromType!=='待核'&&toType!=='待核'?fromType+' → '+toType:'',
          access_transition:kind==='movement'&&(endpointReview||(event.from_access&&event.space_access))&&from&&to&&before.access!=='待核'&&classification.access!=='待核'?before.access+' → '+classification.access:'',
          realm_transition:kind==='movement'&&(endpointReview||(event.from_realm&&event.space_realm))&&from&&to&&before.realm!=='待核'&&classification.realm!=='待核'?before.realm+' → '+classification.realm:''});
      });
    }
    return out;
  }
  function aggregatePaths(rows){
    const count=(map,key,chapters)=>{if(!key)return;map.set(key,(map.get(key)||{label:key,count:0,chapters:new Set()}));const item=map.get(key);item.count++;item.chapters.add(chapters);};
    const spaces=new Map(),transitions=new Map(),locations=new Map(),kinds=new Map(),access=new Map(),realms=new Map(),patterns=new Map(),normalized=new Map(),accessAudit=new Map(),realmAudit=new Map();
    for(const row of rows){
      count(kinds,row.transition_kind,row.chapter_id);
      for(const value of row.values) count(spaces,value,row.chapter_id);
      const transition=row.has_movement&&row.from_space&&row.to_space ? row.from_space+' → '+row.to_space : '';
      count(transitions,transition,row.chapter_id);
      for(const place of row.places) count(locations,place,row.chapter_id);
      count(access,row.classification?.access||'待核',row.chapter_id);
      count(realms,row.classification?.realm||'待核',row.chapter_id);
      count(accessAudit,row.classification?.accessStatus||'尚未完成分类',row.chapter_id);
      count(realmAudit,row.classification?.realmStatus||'尚未完成分类',row.chapter_id);
      count(patterns,row.access_transition,row.chapter_id);
      count(normalized,row.normalized_transition,row.chapter_id);
    }
    const finish=map=>[...map.values()].map(item=>({...item,chapters:item.chapters.size})).sort((a,b)=>b.count-a.count||b.chapters-a.chapters||a.label.localeCompare(b.label,'zh'));
    return {spaces:finish(spaces),transitions:finish(transitions),normalized:finish(normalized),locations:finish(locations),kinds:finish(kinds),access:finish(access),realms:finish(realms),accessAudit:finish(accessAudit),realmAudit:finish(realmAudit),patterns:finish(patterns),steps:rows.length,chapters:new Set(rows.map(r=>r.chapter_id)).size,movementSteps:rows.filter(r=>r.has_movement).length};
  }
  function revise(model,row,edit){
    const d=model.editable(row.chapter_id), word=model.simplify((edit.word||'').trim()), kind=edit.kind, status=edit.status;
    if(!Object.hasOwn(KINDS,kind)) throw new Error('请选择词语类别');
    if(!['accepted','rejected','pending'].includes(status)) throw new Error('请选择审核结论');
    if(status==='accepted' && (!word || !source(model.view(row.chapter_id)).includes(word))) throw new Error('保留的词必须出现在本篇原文中；请先对照原文修正词语。');
    if(status==='accepted' && kind==='places') {
      const reason=(typeof module!=='undefined' && module.exports ? require('./ghost_map_model.js') : root.GhostMapModel).placeWordReason(word,model.view(row.chapter_id).chapter);
      if(reason) throw new Error(reason+' 请改为空间词或修正为原文中的具名地点。');
    }
    if(status!=='pending'){
      if(row.kind==='people') d.people=d.people.filter(p=>p.word!==row.word);
      if(row.kind==='places') d.places=d.places.filter(p=>p.word!==row.word);
      if(row.kind==='spaces') d.space_words=d.space_words.filter(w=>w!==row.word);
      if(row.kind==='times') delete d.years[row.word];
      if(status==='accepted'){
        if(kind==='people'){
          const original=row.person||{};
          const p={...clone(original),word,canonical:edit.canonical||'',person_types:Object.fromEntries((edit.types||[]).map(t=>[t,1])),review_status:'reviewed',aliases:original.aliases||[],evidence:edit.note||original.evidence||'',ontology_evidence:edit.note||original.ontology_evidence||''};
          d.people=d.people.filter(p=>p.word!==word);d.people.push(p);
        }
        if(kind==='places'&&!d.places.some(p=>p.word===word)) d.places.push({word});
        if(kind==='spaces'&&!d.space_words.includes(word)) d.space_words.push(word);
        if(kind==='times') d.years[word]=1;
      }
    }
    const changed=word!==row.word||kind!==row.kind;
    d.lexical_reviews=d.lexical_reviews||{};
    if(row.word) d.lexical_reviews[row.key]={status:status==='accepted'&&changed?'corrected':status,word,kind,note:edit.note||''};
    if(status==='accepted'&&changed) d.lexical_reviews[kind+':'+word]={status:'accepted',word,kind,note:edit.note||''};
    model.save(row.chapter_id,d);
    return model.document();
  }
  const api={KINDS,source,count,tokenCounts,rows,aggregate,pathRows,aggregatePaths,revise};
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
  root.GhostMapReports=api;
})(typeof globalThis!=='undefined'?globalThis:this);
