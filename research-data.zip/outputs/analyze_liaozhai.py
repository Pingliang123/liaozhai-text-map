"""Reproducible, standard-library-only analysis of the supplied Wikisource export.

Usage: python outputs/analyze_liaozhai.py SOURCE.txt --out outputs
Counts describe literal strings, not automatically inferred meanings or species.
"""
import argparse
import hashlib
import json
import re
from pathlib import Path

CJK = re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff]')
TITLE = re.compile(r'^[\u3400-\u4dbf\u4e00-\u9fff]{1,10}$')
VOLUME = re.compile(r'^第[一二三四五六七八九十百]+卷$')
LEXICONS = {
    '建筑与边界': ['門', '窗', '牆', '壁', '戶', '室', '堂', '院', '庭', '齋', '樓', '舍'],
    '自然与郊野': ['山', '水', '海', '林', '野', '洞', '谷', '郊'],
    '丧葬': ['墳', '墓', '塚', '冢', '葬', '棺', '骸'],
    '宗教场所': ['蘭若', '寺', '廟', '觀宇', '宮觀'],
    '司法场所': ['獄', '衙', '公堂', '官廨', '冥府', '陰曹'],
    '方向与移动字面线索': ['入', '出', '歸', '往', '返', '遷', '逾', '越'],
}
PLACES = ['淄川', '濟南', '濟城', '稷下', '稷門', '萊陽', '棲霞', '萊霞里',
          '莒', '羅店', '金華', '蘭溪', '太原', '勞山', '崂山', '嶗山', '長山',
          '沂水', '華陰', '東安', '灌口', '東岳', '羅剎國', '大羅剎國', '海市', '龍宮']
CASES = ['畫壁', '勞山道士', '聶小倩', '嬰寧', '青鳳', '畫皮', '蓮香',
         '羅剎海市', '席方平', '促織', '公孫九娘', '地震', '野狗', '山市']


def clean(text):
    text = re.sub(r'〈.*?〉', '', text, flags=re.S)
    text = re.sub(r'\[\d+\]', '', text)
    text = re.sub(r'<[^>]*>', '', text)
    return text.strip()


def parse(text):
    chapters, notes, appendix = [], False, False
    current, buffer = None, []

    def flush():
        if current is not None:
            full = clean('\n'.join(buffer))
            story, sep, comment = full.partition('異史氏曰')
            if CJK.search(story):
                chapters.append({'title': current, 'story': story.strip(),
                                 'author_comment': comment.strip() if sep else ''})

    for raw in text.splitlines():
        line = raw.strip()
        if line == 'About this digital edition':
            flush()
            break
        if VOLUME.fullmatch(line):
            flush()
            current, buffer, notes = None, [], False
            continue
        if line in ('註釋', '注釋', '注释'):
            flush()
            current, buffer, notes = None, [], True
            continue
        if line == '附錄':
            flush()
            current, buffer, appendix = None, [], True
            continue
        if notes or appendix or line.startswith('↑') or re.match(r'^<卷.*完>$', line):
            continue
        if TITLE.fullmatch(line):
            flush()
            current, buffer = line, []
        elif current is not None:
            buffer.append(line)
    else:
        flush()
    return chapters


def hits(text, words):
    # Longest-first matching prevents overlapping dictionary entries counting twice.
    pattern = '|'.join(re.escape(w) for w in sorted(words, key=len, reverse=True))
    return sum(1 for _ in re.finditer(pattern, text))


def analyze(text):
    chapters = parse(text)
    body = '\n'.join(c['story'] for c in chapters)
    n = len(CJK.findall(body))
    terms = []
    for group, words in LEXICONS.items():
        for word in words:
            count = body.count(word)
            terms.append({'group': group, 'term': word, 'occurrences': count,
                          'chapters': sum(word in c['story'] for c in chapters),
                          'per_10000_cjk': round(count / n * 10000, 2) if n else 0})
    metrics = []
    for c in chapters:
        length = len(CJK.findall(c['story']))
        counts = {g: hits(c['story'], ws) for g, ws in LEXICONS.items()}
        metrics.append({'title': c['title'], 'cjk_characters': length,
                        'counts': counts,
                        'per_10000_cjk': {g: round(v / length * 10000, 2) for g, v in counts.items()},
                        'places': {p: c['story'].count(p) for p in PLACES if p in c['story']}})
    places = [{'form': p, 'occurrences': body.count(p),
               'chapters': [c['title'] for c in chapters if p in c['story']]} for p in PLACES]
    concordances = {}
    for term in ['門', '窗', '牆', '墓', '葬', '萊霞里']:
        examples = []
        for c in chapters:
            if c['title'] not in CASES:
                continue
            for m in re.finditer(re.escape(term), c['story']):
                examples.append({'title': c['title'], 'context': c['story'][max(0, m.start()-25):m.end()+35].replace('\n', '')})
        concordances[term] = examples
    return {'chapters': len(chapters), 'cjk_characters': n,
            'author_comment_cjk': sum(len(CJK.findall(c['author_comment'])) for c in chapters),
            'term_counts': sorted(terms, key=lambda x: x['occurrences'], reverse=True),
            'chapter_metrics': metrics, 'place_forms': places, 'concordances': concordances}


def tables(result):
    lines = ['# 《聊斋志异》空间词汇数据表', '',
             f"正文篇章数：{result['chapters']}；叙事正文汉字数：{result['cjk_characters']}。", '',
             '## 处理方法', '',
             '输入是用户提供的 Wikisource 导出文本。按独立短标题分篇，排除卷标题、卷一注释、附录和数字版本说明；',
             '去掉 〈…〉 内的后人评语、数字注号与尖括号标记；“異史氏曰”单独保存，不计入叙事正文。',
             '括号内的异文保留；不做繁简统一。计数分母仅含基本与扩展 A 汉字，不含标点、拉丁字符。',
             '空间词组采用明示词典。单字具有歧义，表格是字面线索，不能直接视为语义识别。',
             '一组内使用最长优先非重叠匹配；不同组可重叠。地名表逐项匹配，嵌套名称可能重叠，不可求和。',
             '地名共现只代表同篇提及，不能证明人物往返；未自动匹配现代经纬度。', '',
             '## 空间词频（前 25 项）', '',
             '|词项|类别|次数|覆盖篇数|每万汉字次数|', '|---|---|---:|---:|---:|']
    for row in result['term_counts'][:25]:
        lines.append(f"|{row['term']}|{row['group']}|{row['occurrences']}|{row['chapters']}|{row['per_10000_cjk']}|")
    groups = ['建筑与边界', '丧葬', '司法场所', '自然与郊野']
    lines += ['', '## 选定篇章的标准化比较', '',
              '单位：每万汉字字面命中次数。篇章是人工选例，不能代表整个人／鬼／妖类别。', '',
              '|篇名|正文汉字数|' + '|'.join(groups) + '|', '|---|---:|' + '---:|'*len(groups)]
    for name in CASES:
        for row in result['chapter_metrics']:
            if row['title'] == name:
                lines.append(f"|{name}|{row['cjk_characters']}|" + '|'.join(str(row['per_10000_cjk'][g]) for g in groups) + '|')
    lines += ['', '## 地名字形／命名场所', '', '|字形|次数|覆盖篇数|篇名（前 12）|', '|---|---:|---:|---|']
    for row in result['place_forms']:
        if row['occurrences']:
            lines.append(f"|{row['form']}|{row['occurrences']}|{len(row['chapters'])}|{'、'.join(row['chapters'][:12])}|")
    lines += ['', '## 文本来源与复用', '',
              '输入文件末尾声明来源 Wikisource，并提供 CC BY-SA 3.0／GNU FDL 许可链接。本文仅保留短上下文用于分析；',
              '来源：[Wikisource](https://wikisource.org)；许可：[CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/)。',
              '完整文本、注释准确性与版本来源仍需研究者复核；未把导出文件当作校勘定本。', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    data = args.source.read_bytes()
    result = analyze(data.decode('utf-8-sig'))
    result['source_sha256'] = hashlib.sha256(data).hexdigest()
    result['source_filename'] = args.source.name
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / 'liaozhai_data.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    (args.out / '空间词汇数据表.md').write_text(tables(result), encoding='utf-8')
    print(json.dumps({'chapters': result['chapters'], 'cjk_characters': result['cjk_characters'],
                      'top_terms': result['term_counts'][:12],
                      'cases': [m for m in result['chapter_metrics'] if m['title'] in CASES]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
