"""Resumable DeepSeek review for candidate-bearing source units.

This script keeps AI segmentation in a separate, append-only audit file. It
never changes the corpus or the browser's manual revisions. A hard USD cap is
enforced using the conservative peak Flash price basis (input $0.30/M,
output $1.20/M), so a run can stop safely and resume later.
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib import error, request

ROOT = Path(__file__).parent
DATA = ROOT / "ghost_map"
SOURCE = DATA / "歷史地名對照與文本地圖.json"
OUT = DATA / "分词_AI审核.json"
LEDGER = DATA / "分词_AI审核_预算.json"
URL = "https://api.deepseek.com/chat/completions"
INPUT_PRICE = 0.30
OUTPUT_PRICE = 1.20
YEAR_RE = re.compile(r"(?:[顺順前后後]?年|元年|[一二三四五六七八九十百千万萬两兩]+月|[一二三四五六七八九十百千万萬两兩]+日|朔日|望日|翌日|次日|今日|明日|昨日|一日|数日|數日|旬日|经年|經年)")


def cost(usage: dict, off_peak: bool = False) -> float:
    p = usage.get("prompt_tokens") or usage.get("input_tokens")
    c = usage.get("completion_tokens") or usage.get("output_tokens")
    if not isinstance(p, int) or not isinstance(c, int):
        return 0.0
    value = (p * INPUT_PRICE + c * OUTPUT_PRICE) / 1_000_000
    return value * (0.5 if off_peak else 1.0)


def load_queue():
    payload = json.loads(SOURCE.read_text(encoding="utf-8"))
    candidate = payload.get("candidate_review", {})
    terms = {kind: {row["word"] for row in candidate.get(kind, {}).get("rows", [])}
             for kind in ("people", "places", "times")}
    # Include the high-recall time candidates even when they are not in the
    # compact report (e.g. exact year strings).
    for row in json.loads((DATA / "時間詞表_全量模型候選.json").read_text(encoding="utf-8")).get("candidates", []):
        terms["times"].add(row["word"])
    queue = []
    for chapter in payload.get("chapter_overview", []):
        for unit in chapter.get("source_units", []):
            text = unit.get("text", "")
            hits = {kind: sorted({word for word in words if word and word in text})
                    for kind, words in terms.items()}
            if any(hits.values()) or YEAR_RE.search(text):
                queue.append({"id": f"c{chapter['chapter_id']}-u{unit['unit']}",
                              "chapter_id": chapter["chapter_id"],
                              "chapter": chapter["chapter"],
                              "unit": unit["unit"], "text": text,
                              "tokens": unit.get("tokens", []), "hits": hits})
    return queue


def prompt_for(batch):
    return ("请对《聊斋志异》原文单位做严格的数字人文校订。文本已经是简体，不能改写原文。"
            "逐单位返回更可靠的分词边界，并判断候选词在该单位是否真的是人物、地点、空间词或时间词。"
            "人物类型只能用人、鬼、妖、神；空间词是廊、室、城隍庙、野等叙事空间，不等于行政地名；"
            "方位、距离、天气、动作、虚词和普通名词不要误判为地点。地点应是可指称的地名或地理实体。"
            "只返回 JSON，不要 Markdown：{\"units\":[{\"id\":\"...\","
            "\"tokens\":[{\"start\":0,\"end\":1}],"
            "\"annotations\":[{\"term\":\"...\",\"category\":\"person|place|space|time|none\","
            "\"label\":\"accept|reject|uncertain\",\"canonical\":\"\","
            "\"person_types\":[\"人\"],\"evidence\":\"不超过30字\"}]}]}。"
            "tokens 必须覆盖主要文字且 start/end 是简体 text 的字符偏移；不要凭空添加字符。"
            "输入如下：\n" + json.dumps(batch, ensure_ascii=False))


def call(batch, key, model, timeout=120):
    max_tokens = max(800, len(batch) * 500)
    body = json.dumps({"model": model, "messages": [
        {"role": "system", "content": "你是古汉语文本校勘与数字人文标注助手，必须忠实原文并输出 JSON。"},
        {"role": "user", "content": prompt_for(batch)},
    ], "temperature": 0, "response_format": {"type": "json_object"}, "max_tokens": max_tokens}).encode("utf-8")
    req = request.Request(URL, data=body, headers={"Content-Type": "application/json", "Authorization": "Bearer " + key}, method="POST")
    with request.urlopen(req, timeout=timeout) as response:
        raw = json.loads(response.read().decode("utf-8"))
    content = raw["choices"][0]["message"]["content"]
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        # Some compatible DeepSeek gateways still wrap JSON in a code fence
        # despite response_format=json_object. Extract only the outer object;
        # arbitrary prose is never accepted as a review.
        match = re.search(r"\{.*\}", content, flags=re.S)
        if not match:
            raise
        parsed = json.loads(match.group(0))
    return parsed, raw.get("usage", {})


def validate(payload, batch):
    requested = {row["id"]: row for row in batch}
    output = []
    for row in payload.get("units", []) if isinstance(payload, dict) else []:
        source = requested.get(row.get("id"))
        if not source:
            continue
        text = source["text"]
        spans, previous = [], -1
        for token in row.get("tokens", []) if isinstance(row.get("tokens"), list) else []:
            try:
                a, b = int(token["start"]), int(token["end"])
            except (KeyError, TypeError, ValueError):
                continue
            if 0 <= a < b <= len(text) and a >= previous:
                spans.append([a, b]); previous = b
        annotations = []
        for ann in row.get("annotations", []) if isinstance(row.get("annotations"), list) else []:
            if not isinstance(ann, dict) or not ann.get("term"):
                continue
            category = ann.get("category") if ann.get("category") in {"person", "place", "space", "time", "none"} else "none"
            label = ann.get("label") if ann.get("label") in {"accept", "reject", "uncertain"} else "uncertain"
            types = [x for x in ann.get("person_types", []) if x in {"人", "鬼", "妖", "神"}]
            annotations.append({"term": str(ann["term"])[:80], "category": category,
                                "label": label, "canonical": str(ann.get("canonical", ""))[:120],
                                "person_types": types, "evidence": str(ann.get("evidence", ""))[:120]})
        output.append({"id": source["id"], "chapter_id": source["chapter_id"], "chapter": source["chapter"],
                       "unit": source["unit"], "text": text, "tokens": spans,
                       "annotations": annotations, "reviewer": "deepseek"})
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch-size", type=int, default=6)
    parser.add_argument("--budget-usd", type=float, default=3.0)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--model", default=os.getenv("DEEPSEEK_MODEL", "deepseek-chat"))
    parser.add_argument("--prompt-key", action="store_true")
    args = parser.parse_args()
    if args.batch_size < 1 or args.budget_usd <= 0:
        raise SystemExit("invalid batch or budget")
    key = getpass.getpass("DeepSeek API key (不会写入文件): ") if args.prompt_key else os.getenv("DEEPSEEK_API_KEY")
    if not key:
        raise SystemExit("未设置 DeepSeek API key")
    queue = load_queue()
    saved = json.loads(OUT.read_text(encoding="utf-8")) if OUT.exists() else {"reviews": []}
    reviews = {r["id"]: r for r in saved.get("reviews", []) if r.get("id")}
    ledger = json.loads(LEDGER.read_text(encoding="utf-8")) if LEDGER.exists() else {
        "cap_usd": args.budget_usd, "model": args.model,
        "price_basis": "conservative peak: input $0.30/M, output $1.20/M; off-peak discount only in accounting",
        "attempts": [], "started_at": datetime.now(timezone.utc).isoformat()}
    used = sum(float(a.get("cost_upper_bound_usd", 0)) for a in ledger.get("attempts", []))
    remaining = [r for r in queue if r["id"] not in reviews]
    if args.limit:
        remaining = remaining[:args.limit]
    print(f"queue={len(queue)} cached={len(reviews)} remaining={len(remaining)} budget_left=${args.budget_usd-used:.4f}", flush=True)
    for start in range(0, len(remaining), args.batch_size):
        batch = remaining[start:start + args.batch_size]
        estimate_prompt = max(1, len(prompt_for(batch)) // 3)
        max_tokens = max(800, len(batch) * 500)
        reserve = (estimate_prompt * INPUT_PRICE + max_tokens * OUTPUT_PRICE) / 1_000_000
        if used + reserve > args.budget_usd:
            print("budget cap reached; checkpoint saved", flush=True); break
        attempt = {"ids": [r["id"] for r in batch], "reserved_usd": reserve,
                   "status": "reserved", "started_at": datetime.now(timezone.utc).isoformat()}
        ledger.setdefault("attempts", []).append(attempt)
        try:
            result, usage = call(batch, key, args.model)
            accepted = validate(result, batch)
            for row in accepted: reviews[row["id"]] = row
            actual = cost(usage, off_peak=False)
            attempt.update({"status": "accepted", "usage": usage, "cost_upper_bound_usd": max(reserve, actual), "accepted_units": len(accepted)})
            used += max(reserve, actual)
        except (error.URLError, TimeoutError, ValueError, KeyError, json.JSONDecodeError) as exc:
            attempt.update({"status": "failed", "error": type(exc).__name__, "cost_upper_bound_usd": reserve})
            used += reserve
            ledger["used_upper_bound_usd"] = used
            LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"request failed: {type(exc).__name__}; skipped unit and continued", flush=True)
            continue
        OUT.write_text(json.dumps({"status": "deepseek_unit_review", "model": args.model,
                                   "source": str(SOURCE.name), "reviews": list(reviews.values())}, ensure_ascii=False, indent=2), encoding="utf-8")
        ledger["used_upper_bound_usd"] = used
        LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"reviewed={len(reviews)} budget=${used:.4f}/${args.budget_usd:.2f}", flush=True)
    OUT.write_text(json.dumps({"status": "deepseek_unit_review", "model": args.model,
                               "source": str(SOURCE.name), "reviews": list(reviews.values())}, ensure_ascii=False, indent=2), encoding="utf-8")
    ledger["used_upper_bound_usd"] = used
    LEDGER.write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"done cached={len(reviews)} used_upper_bound=${used:.4f}", flush=True)


if __name__ == "__main__":
    main()
