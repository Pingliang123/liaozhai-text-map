"""Generate a clean, independently authored analysis notebook, without running attachment."""
import json
from pathlib import Path


def cell(kind, source):
    c = {'cell_type': kind, 'metadata': {}, 'source': source.splitlines(keepends=True)}
    if kind == 'code':
        c.update({'execution_count': None, 'outputs': []})
    return c


def main():
    cells = [
        cell('markdown', '# 《聊齋志異》：全書分詞、候選辨識與搭配分析\n\n參考附件的分詞—實體候選—搭配—比較流程；未執行附件程式。所有模型輸出首先視為候選，不冒充完整人工標註。\n'),
        cell('code', "from pathlib import Path\nimport sys, json\nROOT = Path.cwd()\nif ROOT.name == 'nlp': ROOT = ROOT.parent\nif ROOT.name != 'outputs': ROOT = ROOT / 'outputs'\nsys.path.insert(0, str(ROOT.resolve()))\nfrom liaozhai_nlp import jsonl_read, kwic\nDATA = ROOT / 'nlp'\nmanifest = json.loads((DATA / 'manifest.json').read_text(encoding='utf-8'))\nmanifest\n"),
        cell('markdown', '## 1. 全詞彙表與詞性\n\n沒有先用少數空間字決定全書詞彙範圍。完整詞表供補漏與覆核；人名與地名仍需古文消歧。\n'),
        cell('code', "vocabulary = json.loads((DATA / 'vocabulary.json').read_text(encoding='utf-8'))\nvocabulary[:30]\n"),
        cell('code', "candidates = json.loads((DATA / 'entity_space_candidates.json').read_text(encoding='utf-8'))\npeople = [r for r in candidates if r['kind']=='person']\nplaces = [r for r in candidates if r['kind']=='place']\nspaces = [r for r in candidates if r['kind']=='space']\n{'person_candidates': len(people), 'place_candidates': len(places), 'space_candidates': len(spaces)}\n"),
        cell('code', "people[:20]\n"),
        cell('code', "places[:20]\n"),
        cell('code', "spaces[:30]\n"),
        cell('markdown', '## 2. 檢查分詞與原文\n\n保留短句；以句號、問號、驚嘆號、分號及段落切分。窗口不跨這些邊界。繁簡轉換只用於模型分析，原文另存。\n'),
        cell('code', "units = jsonl_read(DATA / 'segmented_units.jsonl.gz')\n[u for u in units if u['chapter']=='黃英'][:10]\n"),
        cell('markdown', '## 3. 窗口與同分句搭配\n\n觀察／期望比 O/E 以全書為基準。左右窗口 5 和 10 詞都是真正的參數。重疊窗口覆蓋的同一詞位只計一次。Fisher／BH 僅作探索篩選，語料詞位相依，不將 q 值當成獨立實驗的因果證據。\n'),
        cell('code', "top5 = json.loads((DATA / 'top_collocations_window5.json').read_text(encoding='utf-8'))\ntop10 = json.loads((DATA / 'top_collocations_window10.json').read_text(encoding='utf-8'))\nsame_clause = json.loads((DATA / 'top_collocations_sentence0.json').read_text(encoding='utf-8'))\nTARGET = '寺'\n{'window5': top5.get(TARGET, [])[:15], 'window10': top10.get(TARGET, [])[:15], 'same_clause': same_clause.get(TARGET, [])[:15]}\n"),
        cell('markdown', '## 4. 共享與相異搭配\n\n比較使用同一分詞與同一基準。相似度不是空間的本體定義，詞頻和少量材料會影響結果。\n'),
        cell('code', "comparisons = json.loads((DATA / 'spatial_comparisons.json').read_text(encoding='utf-8'))\nA, B = '寺', '墓'\n[r for r in comparisons if {r['a'], r['b']} == {A, B}]\n"),
        cell('code', "kwic(units, TARGET, limit=20)\n"),
        cell('markdown', '## 5. 人物與地點的搭配\n\n人名簡稱、同名與代稱尚未全書共指合併。某詞沒有結果時應先檢查分詞与實體候選，不得以缺席證明它不重要。\n'),
        cell('code', "TARGET = '黄英'\n{'collocates': top10.get(TARGET, [])[:20], 'original_contexts': kwic(units, TARGET, limit=20, chapter='黃英')}\n"),
        cell('markdown', '## 6. 覆核與圖表\n\n完整候選和搭配資料在本資料夾；人工覆核樣本及方法修訂說明見報告。網絡邊只表示局部搭配，不能充當人物實際移動。\n'),
        cell('markdown', '![空間詞搭配熱圖](空间搭配热图.png)\n'),
        cell('code', "market_review = json.loads((DATA / '市词义人工复核.json').read_text(encoding='utf-8'))\nmarket_review['counts']\n"),
        cell('code', "evidence = json.loads((DATA / '重点搭配原文证据.json').read_text(encoding='utf-8'))\n[{k:r[k] for k in ['target','collocate','observed','expected','oe_ratio','support_chapters']} for r in evidence]\n"),
        cell('code', "huangying = json.loads((DATA / '黃英复核实体与空间.json').read_text(encoding='utf-8'))\nhuangying['counts']\n"),
        cell('code', "huangying['edges'][:25]\n"),
        cell('markdown', '## 重新運行\n\n在已安裝 THULAC、OpenCC、spaCy 中文模型、SciPy 的 Python 環境執行。模型版本見 manifest。\n\n```powershell\npython outputs/liaozhai_nlp.py SOURCE.txt --out outputs/nlp --phase all\npython -m unittest discover -s outputs -p test_*.py -v\n```\n\n已存在相同來源的分詞快取時，可加 `--reuse`。完整可執行原始碼為上一層 `liaozhai_nlp.py`。\n'),
    ]
    notebook = {'cells': cells, 'metadata': {'kernelspec': {'display_name':'Python 3', 'language':'python', 'name':'python3'}, 'language_info':{'name':'python'}}, 'nbformat':4, 'nbformat_minor':5}
    for i, c in enumerate(cells):
        c['id'] = f'liaozhai-{i:02d}'
    output = Path(__file__).parent/'nlp'/'聊齋全書分詞與搭配分析.ipynb'
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(notebook, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
