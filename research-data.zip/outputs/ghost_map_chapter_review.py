"""Source-scoped AI close-reading corrections, not a whole-book gold standard."""
from copy import deepcopy

DING_PEOPLE = [
    ('丁前溪', ['丁', '丁某'], '主人公', '丁前溪，诸城人。'),
    ('杨某', ['杨', '主人'], '款客者，原文未载其名', '主人杨姓，我其内侄也。'),
    ('杨妻', ['娘子', '妻', '室人'], '杨某之妻；别称限本篇相应语境', '家惟娘子在。'),
    ('杨某的内侄', ['少年'], '接待丁前溪的少年', '我其内侄也。'),
    ('御史', [], '按访丁前溪的官员；不是姓名；不将“行台”另立人物', '御史行台按访之。'),
    ('郭解', [], '典故人物，非本篇在场人物', '慕郭解之为人。'),
]

# Every line corresponds to one complete source unit, 3127--3177.
# This is a reviewed boundary layer; it does not silently rewrite the model cache/POS.
DING_SEGMENTATION = '''丁前溪/，/诸城/人/。
富有/钱谷/。
游侠/好义/，/慕/郭解/之/为人/。
御史/行台/按访/之/。
丁/亡/去/。
至/安丘/，/遇/雨/，/避身/逆旅/。
雨/日中/不/止/。
有/少年/来/，/馆谷/丰隆/。
既而/昏暮/，/止宿/其/家/；
莝豆/饲/畜/，/给食/周至/。
问/其/姓字/，/少年/云/：/「/主人/杨/姓/，/我/其/内侄/也/。
主人/好/交游/，/适/他/出/，/家/惟/娘子/在/。
贫/不能/厚/客/给/，/幸/能/垂谅/。
」/问/主人/何/业/，/则/家/无/资产/，/惟/日/设/博场/，/以/谋/升斗/。
次日/，/雨/仍/不/止/，/供给/弗/懈/。
至/暮/，/剉/刍/，/刍束/湿/，/颇/极/参差/。
丁/怪/之/。
少年/曰/：/「/实/告/客/：/家/贫/无以/饲/畜/，/适/娘子/撤/屋/上/茅草/。
」/丁/益/异/之/，/谓/其/意/在/得/直/。
天明/，/付/之/金/，/不/受/；
强/付/，/少年/持/入/。
俄了/，/仍/出/以/反/客/，/云/：/「/娘子/言/：/我/非/业/此/猎食/者/。
主人/在外/，/尝/数日/不/携/一钱/；
客/至/吾/家/，/何/遂/索偿/乎/？
」/丁/叹赞/而/别/。
嘱/曰/：/「/我/诸城/丁某/，/主人/归/，/宜/告/之/。
暇/幸/见顾/。
数年/无/耗/。
值/岁/大饥/，/杨/困/甚/，/无/所/为/计/。
妻/漫/劝/诣/丁/，/从/之/。
至/诸/，/通/姓名/于/门者/。
丁/茫/不/忆/。
申言/始/忆/之/。
足/丽/履/而/出/，/揖/客/入/。
见/其/衣/敝/踵/决/，/居/之/温室/，/设筵/相/款/，/宠礼/异常/。
明日/，/为/制/冠服/，/表里/温暖/。
杨/义/之/；
而/内顾/增/懮/，/褊心/不能/无/少/望/。
居/数日/，/殊/不/言/赠别/。
杨/意/甚/亟/，/告/丁/曰/：/「/顾/不敢/隐/：/仆/来/时/，/米/不/满/升/。
今/过/蒙/推解/，/固/乐/；
妻子/如何/矣/！
」/丁/曰/：/「/是/无烦/虑/，/已/代/经纪/矣/。
幸/舒/意/少/留/，/当/助/资斧/。
」/走/伻/招/诸/博徒/，/使/杨/坐/而/乞头/，/终夜/得/百金/，/乃/送/之/还/。
归/见/室人/，/衣履/鲜整/，/小婢/侍/焉/。
惊/问/之/。
妻/言/：/「/自/若/去/后/，/次日/即/有/车徒/赍送/布帛/菽粟/，/堆积/满/屋/，/云/是/丁/客/所/赠/。
又/婢/十指/，/为/妾/驱使/。
」/杨/感/不/自已/。
由此/小康/，/不屑/旧业/矣/。'''

def apply_chapter_review(profile):
    if profile['chapter_id'] != 52 or profile['chapter'] != '丁前溪':
        return profile
    result = deepcopy(profile)
    result.update(event_types={'人': 1}, realm='人間', realms_present=['人間'],
                  realm_spaces=[], realm_review_status='source_reviewed',
                  realm_review_reason='通读本篇：款客、报恩与赈济均由人完成；“怪之”是感到奇怪，不是妖怪。',
                  annotation_status='AI逐篇对照原文核对；仍可人工修订',
                  segmentation_note=DING_SEGMENTATION,
                  review_note='本篇“人”是篇目分类，非事件次数。郭解仅为典故。单字称谓限本篇指代。未臆改“俄了”“懮”等底本文字。')
    result['people'] = [dict(word=name, canonical=name, aliases=aliases,
        person_types={'人': 1}, mentions=None, review_status='reviewed',
        role=role, evidence=evidence, identity_links=[])
        for name, aliases, role, evidence in DING_PEOPLE]
    result['places'] = [
        {'word': '诸城', 'mentions': 2, 'aliases': ['诸'], 'evidence': '诸城人；我诸城丁某；至诸',
         'role': '丁的籍贯及后段访问地；“诸”是本篇缩称'},
        {'word': '安丘', 'mentions': 1, 'evidence': '至安丘，遇雨，避身逆旅', 'role': '丁避雨、受款待之地'},
    ]
    result['person_types'] = {name: {'人': 1} for name, *_ in DING_PEOPLE}
    result['person_aliases'] = {name: aliases for name, aliases, *_ in DING_PEOPLE}
    result['realm_counts'] = {'人間': result.get('units', 51)}
    result['event_units'] = [{'unit': 3144, 'labels': ['人'],
        'excerpt': '少年曰：「實告客：家貧無以飼畜，適娘子撤屋上茅草。'}]
    return result
