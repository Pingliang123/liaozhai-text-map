"""Conservative scene candidates with offsets; not complete semantic annotation."""
import re

GROUPS = {
    '非人间与高空': ('云霄',),
    '居住与内部': ('卧室', '内室', '书斋', '庭院', '院落', '闺房', '厅堂', '温室', '满屋', '房中', '屋内', '闺中', '茅茨', '楼舍'),
    '信仰与祭祀': ('城隍庙', '土地庙', '佛寺', '祠堂', '庙宇'),
    '道路与边界': ('城郭', '府廨', '城门', '门外', '门内', '门庭', '桥上', '桥下', '路旁', '廊下', '逆旅'),
    '自然与旷野': ('北山', '旷野', '郊野', '荒野', '荒圃', '山林', '洞穴', '坟墓', '墓地', '菊畦', '亭园'),
}
SINGLES = {'野': '自然与旷野', '室': '居住与内部', '廊': '道路与边界',
           '庭': '居住与内部', '庙': '信仰与祭祀', '寺': '信仰与祭祀'}


def scene_evidence(units):
    records = []
    lexicon = {w: group for group, words in GROUPS.items() for w in words}
    pattern = re.compile('|'.join(map(re.escape, sorted(lexicon, key=len, reverse=True))))
    for unit in units:
        text = unit['text']
        spans = [(m.start(), m.end(), m.group(), lexicon[m.group()]) for m in pattern.finditer(text)]
        for m in re.finditer(r'[至入出归居于在到][其一此彼]?([野室廊庭庙寺])(?![心性蛮女家])', text):
            a, b = m.span(1)
            if not any(a < end and b > start for start, end, _, _ in spans):
                spans.append((a, b, m.group(1), SINGLES[m.group(1)]))
        for a, b, word, group in sorted(spans):
            records.append({'word': word, 'category': group, 'unit': unit['unit'],
                            'start': a, 'end': b, 'excerpt': text, 'status': 'candidate'})
    return records
