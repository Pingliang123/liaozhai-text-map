"""Publish a source-linked record of the directional-name editorial review."""
import json
from pathlib import Path
from collections import Counter
from place_word_review import POLICY, rejection_reason

ROOT = Path(__file__).parent


def build(data):
    rows = []
    for r in sorted(data['candidate_review']['places']['rows'], key=lambda r:r['word']):
        word = r['word']
        if not any(c in word for c in '东西南北中'):
            continue
        evidence = [dict(chapter_id=c['chapter_id'], chapter=c['chapter'], unit=u['unit'], quote=u['text'])
                    for c in data['chapter_overview'] for u in c['source_units'] if word in u['text']]
        if word in POLICY['spaces']:
            decision, note = '改列空间词', rejection_reason(word)
        elif word in POLICY['replacements']:
            decision, note = '修正误切词', rejection_reason(word)
        elif rejection_reason(word):
            decision, note = '排除地名误词', rejection_reason(word)
        elif word in POLICY['pending']:
            decision, note = '保留待考候选', POLICY['pending'][word]
        elif '排除' in r['status']:
            decision, note = '维持原有排除', r.get('rejection_reason') or '原文为动词、人物、称谓或误切片段，不作具名地点。'
        else:
            decision, note = '保留地名或地域称谓', '原文支持地名／地域称谓；不据此认定事件发生地或精确坐标。'
        scoped = {title:rules[word] for title,rules in POLICY['chapter_exclusions'].items() if word in rules}
        if scoped:
            decision = '按篇目分别判断'
        rows.append(dict(word=word, decision=decision, note=note, chapter_exclusions=scoped,
                         evidence_count=len(evidence), evidence=evidence[:4]))
    return dict(reviewed_on=POLICY['reviewed_on'], count=len(rows),
                counts=dict(Counter(r['decision'] for r in rows)), method=POLICY['method'], rows=rows)


def main():
    data = json.loads((ROOT/'ghost_map'/'歷史地名對照與文本地圖.json').read_text(encoding='utf8'))
    report = build(data)
    (ROOT/'direction_place_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    lines = ['# 含东西南北中的地点候选原文复核', '', report['method'], '',
             '共核对 '+str(report['count'])+' 个词。方位字不直接决定词类，地方专名与篇内空间分别记录。同名、典故、神祇和籍贯不自动作为事件地点。', '',
             '## 判断分布', '', *[f'- {k}：{v} 个' for k,v in report['counts'].items()], '',
             '## 逐词记录', '', '|词语|结论|依据与原文示例|', '|---|---|---|']
    for r in report['rows']:
        examples = '；'.join('《'+e['chapter']+'》'+e['quote'] for e in r['evidence'][:2])
        scoped = '；'.join('《'+k+'》'+v for k,v in r['chapter_exclusions'].items())
        lines.append('|'+ '|'.join([r['word'], r['decision'], (r['note']+' '+scoped+' '+examples).replace('|','／').replace('\n',' ')])+'|')
    (ROOT/'direction_place_audit.md').write_text('\n'.join(lines)+'\n', encoding='utf8')
    print(json.dumps(dict(count=report['count'],counts=report['counts']), ensure_ascii=False))


if __name__ == '__main__':
    main()
