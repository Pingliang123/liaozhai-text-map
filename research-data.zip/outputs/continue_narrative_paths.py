"""Continue the existing authorization in bounded, checkpointed batches."""
import argparse
import getpass
import json
import os
import sys
from urllib import request, error
import ai_narrative_paths as task

FIRST_RESUME_IDS = [5,21,46,48,59,68,83,96,105,130,131,151,157,171,175,178,181,182,186,188,191,192,195,197]


def authorized_cap(ledger):
    cap = ledger['cap_usd']
    if cap == 4.3:
        return cap
    if cap == 4.5 and any(row.get('previous_cap_usd') == 4.3 and
                          row.get('cap_usd') == 4.5 and row.get('authorization')
                          for row in ledger.get('authorization_history', [])):
        return cap
    raise ValueError('Missing authorization for cumulative budget cap')


def reconcile_first_resume(ledger):
    """This observed batch ran after 10:26 UTC with a per-request off-peak gate.

    The first run used the legacy peak estimate. Only this witnessed batch is
    reconciled; earlier unknown reservations and incomplete usage stay intact.
    Call only when the previous writer has exited.
    """
    result = json.loads(json.dumps(ledger))
    rows = result['attempts'][360:384]
    if [r['chapter_id'] for r in rows] != FIRST_RESUME_IDS:
        raise ValueError('Known off-peak batch identity mismatch; no ledger changes')
    for row in rows:
        if row.get('price_window') == 'off_peak': continue
        if row['status'] not in {'accepted','rejected_or_failed'}:
            raise ValueError('Observed batch is not finished; no reconciliation')
        row['peak_cost_upper_bound_usd'] = row.get('cost_upper_bound_usd',row['reserved_usd'])
        row['cost_upper_bound_usd'] = task.usage_cost(row.get('usage',{}),row['reserved_usd'],off_peak=True)
        row['price_window'] = 'off_peak'
        row['rate_evidence'] = '2026-10-14手动续跑首批24次：UTC10:26之后启动，逐请求低谷守卫；仅修正已知批次，旧未知预留不变。'
    for row in result['attempts'][384:]:
        if row.get('price_window') == 'off_peak' and row.get('request_started_at'):
            row.setdefault('previous_cost_upper_bound_usd',row.get('cost_upper_bound_usd',row['reserved_usd']))
            row['cost_upper_bound_usd'] = task.usage_cost(row.get('usage',{}),row['reserved_usd'],off_peak=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prompt-key', action='store_true')
    parser.add_argument('--reconcile-known-offpeak', action='store_true')
    args = parser.parse_args()
    key = os.environ.get('DEEPSEEK_API_KEY')
    if not key and args.prompt_key:
        key = getpass.getpass('DeepSeek API key (hidden): ')
    if not key:
        parser.error('Set DEEPSEEK_API_KEY or use --prompt-key; keys are never saved')
    if not task.is_off_peak():
        parser.error('Outside the authorized off-peak window; no request sent')
    # Read-only authentication avoids reserving dozens of unusable requests.
    req = request.Request('https://api.deepseek.com/user/balance',
                          headers={'Authorization': 'Bearer ' + key})
    try:
        with request.urlopen(req, timeout=20) as response:
            available = json.load(response).get('is_available')
    except error.HTTPError as exc:
        parser.error('API authentication failed: HTTP ' + str(exc.code))
    if not available:
        parser.error('No API balance available')
    os.environ['DEEPSEEK_API_KEY'] = key
    ledger = task.CACHE.parent / 'budget-authorized-20261014.json'
    try:
        cap = authorized_cap(json.loads(ledger.read_text(encoding='utf-8')))
    except ValueError as exc:
        parser.error(str(exc))
    if args.reconcile_known_offpeak:
        task.write_json_atomic(ledger,reconcile_first_resume(json.loads(ledger.read_text(encoding='utf-8'))))
    for batch in range(20):
        before = len(task.load_cache()['chapters'])
        if not task.is_off_peak():
            print('Off-peak window ended; stop without scheduling more requests', flush=True)
            break
        print('Resume batch ' + str(batch + 1), flush=True)
        sys.argv = ['ai_narrative_paths.py', '--workers', '8', '--limit', '32',
                    '--max-tokens', '10000', '--adaptive-output', '--budget-id', 'authorized-20261014', '--budget-usd', str(cap)]
        task.main()
        after = len(task.load_cache()['chapters'])
        if after == 491 or after <= before:
            print('Stop: all chapters completed, reservation limit reached, or no accepted progress', flush=True)
            break


if __name__ == '__main__':
    main()
