"""Post-discovery, explicitly scoped human reviews and reproducible evidence."""
import copy
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from liaozhai_nlp import (jsonl_read, json_write, jsonl_write, collect_occurrences,
                          collocations, comparisons, kwic)

DATA = Path(__file__).parent / 'nlp'
# All 66 exact-token 市 contexts were read before this sense list was authored.
MARKET_UNITS = {479,2014,2069,2172,2185,2187,3471,3961,4446,8135,
                8587,10276,10441,12537,14585,14983,15080,18524,18809,
                19184,19379,22662,22977,23046,23880,24023,24081,25326,
                28300,28511,30794,30797}
SIMILE_UNITS = {12971,20875,20886,22200,22236,23928,26631}
ACTOR_UNITS = {494,8533,8596,15105,24293}  # 一市粲然 = market crowd laughing.
LEGAL_UNITS = {19064,31633}


def review_market(units):
    spans = collect_occurrences(units, {'市'})['市']
    rows, accepted = [], []
    seen = Counter()
    for s in spans:
        uid = s[0]
        # 九山王: first 市 means market, second means purchasing saltpetre/sulphur.
        if uid in MARKET_UNITS and not (uid == 4446 and seen[uid] > 0):
            label = 'market_place'
            accepted.append(s)
        elif uid in SIMILE_UNITS:
            label = 'market_simile'
        elif uid in ACTOR_UNITS:
            label = 'market_people_not_space'
        elif uid in LEGAL_UNITS:
            label = 'execution_idiom'
        else:
            label = 'purchase_verb'
        seen[uid] += 1
        u = units[uid]
        rows.append({'unit':uid,'start':s[3],'end':s[4], 'sense':label,
                     'chapter':u['chapter'], 'original':u['original'],
                     'review':'single-reader purposive exact-token sense annotation'})
    return rows, accepted


def annotate_huangying(units):
    """After all-book discovery, annotate selected explicit aliases/space expressions.

    No automatic pronoun resolution; relatives, households, allusions and synonyms
    are NOT silently folded into principal names. This is not a complete gold set.
    """
    patterns = {
        'person': [('马子才',r'马子才|马(?!妻)'), ('黄英',r'黄英|(?<!黄)英'),
                   ('陶三郎',r'三郎|(?<!醉)陶(?!家|姓)'), ('吕氏',r'吕'),
                   ('曾生',r'曾生|曾')],
        'place': [('金陵','金陵'),('顺天','顺天'),('河朔','河朔'),('东粤','东粤'),('都中','都中')],
        'allusion': [('陈仲子','陈仲子'),('渊明','渊明'),('彭泽','彭泽'),
                     ('东篱','东篱'),('东食西宿','东食西宿'),('玉山倾倒','玉山倾倒')],
        'space': [(w,re.escape(w)) for w in ['荒圃','茅庐','小室','北院','荒庭','菊畦',
                    '畦侧','畦边','花畦','南第','楼舍','廊舍','夏屋','茅茨','园中',
                    '亭园','房中','村外','墙外','花肆','肆中','闺中','盆中','间壁',
                    '门','扉','田','床榻','床头']]
    }
    annotations, edges = [], defaultdict(list)
    for u in units:
        if u['chapter'] != '黃英':
            continue
        found = defaultdict(set)
        for kind, items in patterns.items():
            for lemma, pattern in items:
                for m in re.finditer(pattern,u['text']):
                    # '有友人曾生' names 曾生; elsewhere 曾 refers to him in this story.
                    a,b = u['alignment'][m.start()],u['alignment'][m.end()]
                    annotations.append({'unit':u['unit'],'kind':kind,'lemma':lemma,
                        'normalized_form':m.group(),'start':m.start(),'end':m.end(),
                        'original_form':u['original'][a:b],'original':u['original']})
                    found[kind].add(lemma)
        for p in found['person']:
            for kind in ['place','space']:
                for s in found[kind]:
                    edges[p,kind,s].append({'unit':u['unit'],'original':u['original']})
    edge_rows = [{'person':p,'kind':kind,'target':s,'cooccurring_clauses':len(contexts),
                  'relation':'undirected cooccurrence, NOT travel/ownership/causation',
                  'contexts':contexts} for (p,kind,s),contexts in sorted(edges.items())]
    return {'scope':'Selected explicit name aliases and spatial expressions, reviewed after whole-book segmentation. Nonexhaustive: no pronoun/kinship coreference gold standard.',
            'patterns':patterns,'mentions':annotations,'edges':edge_rows,
            'counts':{kind:dict(Counter(a['lemma'] for a in annotations if a['kind']==kind))
                      for kind in patterns}}


def pair_contexts(units, target, collocate, horizon=5):
    spans = collect_occurrences(units,{target})[target]
    result, seen = [],set()
    for uid,a,b,*_ in spans:
        u=units[uid]
        for i in range(max(0,a-horizon),min(len(u['tokens']),b+horizon)):
            t=u['tokens'][i]
            if a<=i<b or t['word']!=collocate or (uid,i) in seen:
                continue
            seen.add((uid,i))
            result.append({'unit':uid,'chapter':u['chapter'],'original':u['original'],
                           'collocate_start':t['start'],'collocate_end':t['end']})
    return result


def figures(rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans']
    plt.rcParams['axes.unicode_minus']=False
    targets=['门','室','墓','山','市（场所义）']
    words=['闭','扣','启','入','窥','清明','侧','价']
    lookup={(r['target'],r['collocate']):r for r in rows}
    arr=np.full((len(targets),len(words)),np.nan)
    for i,a in enumerate(targets):
        for j,b in enumerate(words):
            r=lookup.get((a,b))
            if r and r['observed']>=3 and r['oe_ratio']>1:
                arr[i,j]=r['log2_oe']
    fig,ax=plt.subplots(figsize=(11,4.5),constrained_layout=True)
    im=ax.imshow(np.ma.masked_invalid(arr),cmap='YlGnBu',vmin=0,vmax=8)
    ax.set_xticks(range(len(words)),words,fontsize=12)
    ax.set_yticks(range(len(targets)),targets,fontsize=12)
    for i,a in enumerate(targets):
        for j,b in enumerate(words):
            if np.isfinite(arr[i,j]):
                r=lookup[a,b]
                ax.text(j,i,f"{r['oe_ratio']:.1f}\nn={r['observed']}",ha='center',va='center',
                        color='white' if arr[i,j]>4.5 else '#17212b',fontsize=10)
    ax.set_title('全書空間詞的局部搭配：±5 詞、同分句內',fontsize=15,pad=16)
    ax.set_xlabel('格內：O/E 與觀察詞位數 n；空白：不足 3 次或 O/E ≤ 1，不等於無關係',labelpad=12)
    fig.colorbar(im,ax=ax,label='log2(O/E)')
    fig.savefig(DATA/'空间搭配热图.png',dpi=160)
    plt.close(fig)


def main():
    manifest=json.loads((DATA/'manifest.json').read_text(encoding='utf-8'))
    if manifest['source_sha256']!='28bc2dcf34612ca44c4dccadd0351edea130cca135dfd41bccb144660fc6e665':
        raise ValueError('Human annotations use unit IDs from the reviewed source edition only.')
    units=jsonl_read(DATA/'segmented_units.jsonl.gz')
    market,accepted=review_market(units)
    json_write(DATA/'市词义人工复核.json',{'scope':'All exact-token 市 occurrences, not all compounds containing 市',
                'counts':dict(Counter(r['sense'] for r in market)),'mentions':market})
    reviewed={'市（场所义）':accepted}
    reviewed_rows,_=collocations(units,{'市（场所义）'},reviewed_occurrences=reviewed)
    jsonl_write(DATA/'市场所义搭配.jsonl.gz',reviewed_rows)
    rows=jsonl_read(DATA/'collocations_window5.jsonl.gz')+reviewed_rows
    # Focus vocabulary is selected AFTER discovery, not used to constrain segmentation.
    focused={'门','室','墓','寺','山','市（场所义）'}
    json_write(DATA/'重点空间比较.json',comparisons(rows,focused))
    pairs=[('门','闭'),('门','扣'),('门','启'),('室','入'),('室','窥'),
           ('墓','清明'),('墓','侧'),('山','入'),('市（场所义）','价')]
    evidence=[]
    for a,b in pairs:
        r=next(x for x in rows if x['target']==a and x['collocate']==b)
        evidence.append({**r,'contexts':pair_contexts(units,'市' if a.startswith('市（') else a,b),
                         'audit':'Contexts read; not a corpus-wide entity gold standard'})
    json_write(DATA/'重点搭配原文证据.json',evidence)
    json_write(DATA/'黃英复核实体与空间.json',annotate_huangying(units))
    diagnostic=[('place','俄','reject: 文言时间副词，不是俄国'),
                ('place','日','reject: 时间表达，不是日本'),
                ('space','长亭','reject: 本批例子为人名'),
                ('place','玉山','reject: 已见两例均为醉倒比喻'),
                ('person','茅茨','reject: 居处，不是人名'),
                ('person','马大悦','reject: 马＋大悦，实体边界错误'),
                ('space','城','mixed: 城市、人名连城、城隍；未经消歧不可整体解释'),
                ('space','室','mixed: 居室与继室等关系称谓，需逐例消歧'),
                ('place','金陵','accept sampled place contexts; reject PERSON tag for same form')]
    json_write(DATA/'模型误判复核.json',[{'candidate_kind':k,'word':w,'judgment':j,
                   'examples':kwic(units,w,8),'selection':'purposive diagnostic, NOT random accuracy estimate'}
                  for k,w,j in diagnostic])
    figures(rows)
    print('Market sense counts:',Counter(r['sense'] for r in market))
    print('Huangying annotation counts:',annotate_huangying(units)['counts'])
    print('Evidence and figure complete.')


if __name__=='__main__':
    main()
