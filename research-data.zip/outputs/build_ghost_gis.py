"""Join curated historical place references to chapter-level textual events."""
import json
import gzip
from build_place_chronology import build_chronology, render_report
from pathlib import Path
from opencc import OpenCC
from extract_scene_spaces import scene_evidence
from ai_narrative_paths import load_cache, checked_record
from place_hierarchy import annotate as annotate_place_hierarchy
from audit_place_locations import audit as audit_place_locations
from place_word_review import rejection_reason, chapter_reason, reviewed_places, POLICY as PLACE_POLICY

ROOT=Path(__file__).parent
DATA=ROOT/'ghost_map'

# Coordinates are modern reference points for historical names, not claims
# about Qing administrative boundaries. The historical-name source is kept in
# each record so the interactive map remains auditable.
GAZETTEER=[
 {'name':'金陵','modern_name':'南京','lon':118.7969,'lat':32.0603,'type':'city','confidence':'high','source':'南京市地方志：南京古称金陵','source_url':'https://dfz.nanjing.gov.cn/ztzl/njzj/szcs/200806/P020210517585259435810.pdf','note':'歷史名稱對應現代南京；文本中也可能兼具故土、商旅與婚姻語境。'},
 {'name':'青州','modern_name':'青州','lon':118.4791,'lat':36.6814,'type':'city','confidence':'high','source':'青州古城地理參考','source_url':'https://ditu.amap.com/place/B0FFFTL0U1','note':'現代參考點；文本中的青州可能是籍貫、城市或故事位置。'},
 {'name':'濟南','modern_name':'濟南','lon':117.1201,'lat':36.6512,'type':'city','confidence':'high','source':'中國歷史地名查詢系統（地名史料入口）','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'以現代城市中心作參考，不把古今行政範圍視為相同。'},
 {'name':'洞庭','modern_name':'洞庭湖','lon':112.9500,'lat':29.3700,'type':'lake','confidence':'medium','source':'中國歷史地名查詢系統（地名史料入口）','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'文本多作水域與舟行節點；湖區不是單一城市點。'},
 {'name':'泰山','modern_name':'泰山','lon':117.1000,'lat':36.2600,'type':'mountain','confidence':'high','source':'泰山世界遺產地理資料','source_url':'https://twh.boch.gov.tw/world/intro.aspx?id=545','note':'山嶽地標；文本中的泰山另有祭祀、神異與冥界想像。'},
 {'name':'南海','modern_name':'南海區域','lon':113.5000,'lat':20.5000,'type':'sea','confidence':'low','source':'歷史地名候選，區域近似點','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'只表示海域方向，不是精確故事地點。'},
 {'name':'湖南','modern_name':'湖南省','lon':111.7000,'lat':27.4000,'type':'region','confidence':'medium','source':'歷史地名候選，現代省域近似點','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'區域級地名，不應縮小為單一城市。'},
 {'name':'山東','modern_name':'山東省','lon':118.0000,'lat':36.4000,'type':'region','confidence':'medium','source':'歷史地名候選，現代省域近似點','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'區域級地名；與文本中的青州、濟南、沂水不可自動合併。'},
 {'name':'沂水','modern_name':'沂水县','lon':118.6300,'lat':35.7900,'type':'county','admin_level':'county','modern_level':'县级','region_description':'山东省临沂市沂水县','coordinate_kind':'approximate','confidence':'medium','source':'沂水县政府：地理环境；临沂市民政局：沂水县建制沿革','source_url':'https://www.yishui.gov.cn/zjys/ysgk1/dlhj1.htm','note':'用户纠正为县级地名。保留既有现代县城附近参考点，不代表县域边界；县级沿革来源：https://mzj.linyi.gov.cn/info/1296/12627.htm。'},
 {'name':'江南','modern_name':'長江以南區域','lon':120.0000,'lat':30.0000,'type':'region','confidence':'low','source':'歷史地理區域候選','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'文化—地理區域，不是固定行政邊界。'},
 {'name':'東海','modern_name':'東海區域','lon':123.0000,'lat':30.0000,'type':'sea','confidence':'low','source':'歷史地理區域候選','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'海域名稱，採區域近似點。'},
 {'name':'東莞','modern_name':'東莞','lon':113.7518,'lat':23.0207,'type':'city','confidence':'medium','source':'歷史地名候選，現代城市近似點','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'現代參考點，古今城界不等同。'},
 {'name':'西安','modern_name':'西安','lon':108.9398,'lat':34.3416,'type':'city','confidence':'medium','source':'歷史地名候選，現代城市近似點','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'現代參考點，文本可能使用歷史文化意涵。'},
 {'name':'南陽','modern_name':'南陽','lon':112.5283,'lat':32.9902,'type':'city','confidence':'medium','source':'歷史地名候選，現代城市近似點','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html','note':'現代參考點，需與篇內人物與事件核對。'},
]

# Additional high-confidence names detected in the full place inventory. They
# use modern reference points and the same historical-name lookup source; the
# map does not claim that these points reproduce Qing administrative borders.
_MORE=[
 ('東昌','东昌',36.46,115.99,'city'),('江西','江西',27.60,115.90,'region'),('鎮江','镇江',32.20,119.45,'city'),
 ('西湖','西湖',30.25,120.15,'lake'),('太原','太原',37.87,112.55,'city'),('河南','河南',34.76,113.66,'region'),
 ('揚州','扬州',32.39,119.42,'city'),('雲南','云南',25.04,102.72,'region'),('諸城','诸城',35.99,119.41,'city'),
 ('長沙','长沙',28.23,112.94,'city'),('膠州','胶州',36.26,120.03,'city'),('蘇州','苏州',31.30,120.62,'city'),
 ('西江','西江',23.00,112.50,'river'),('遼陽','辽阳',41.27,123.18,'city'),('陝西','陕西',34.26,108.95,'region'),
 ('河間','河间',38.44,116.10,'city'),('廣陵','广陵',32.39,119.42,'historical-city'),('天津','天津',39.08,117.20,'city'),
 ('泰安','泰安',36.20,117.09,'city'),('萊蕪','莱芜',36.21,117.68,'city'),('南昌','南昌',28.68,115.86,'city'),
 ('太行','太行',36.50,113.50,'mountain'),('洛陽','洛阳',34.62,112.45,'city'),('成都','成都',30.57,104.06,'city'),
 ('大同','大同',40.08,113.30,'city'),('瀋陽','沈阳',41.80,123.40,'city'),('金華','金华',29.10,119.65,'city'),
 ('臨洮','临洮',35.38,103.86,'city'),('淄川','淄川',36.65,118.00,'city'),('臨朐','临朐',36.50,118.54,'city'),
 ('萊州','莱州',37.18,119.94,'city'),('廣陵','广陵',32.39,119.42,'historical-city')]
for traditional, simplified, lat, lon, kind in _MORE:
    GAZETTEER.append({'name':traditional,'modern_name':simplified,'lon':lon,'lat':lat,'type':kind,'confidence':'medium',
        'source':'中國歷史地名查詢系統（地名史料入口）','source_url':'https://ihns.cas.cn/njgsz/zcbm/lytsg/zydh/sjkdh/zwdj/202310/t20231030_6910650.html',
        'note':'現代參考點；古今行政範圍與文本敘事位置不必相同。'})
import hashlib
from importlib.metadata import distribution
from collections import Counter, defaultdict

GAZETTEER.append({'name': '安丘', 'modern_name': '安丘市', 'lat': 36.36, 'lon': 119.11,
    'type': 'region', 'confidence': 'low', 'source': 'Wikidata Q568514（现代行政区域参考点）',
    'source_url': 'https://www.wikidata.org/wiki/Q568514',
    'note': '现代安丘市区域近似点，取两位小数；不是清代县城或杨家旅舍的精确位置。'})
GAZETTEER.append({'name':'长山','modern_name':'邹平市长山镇／原长山县一带','lat':36.88,'lon':117.87,
    'type':'historical-county','admin_level':'county','modern_level':'镇；原县域现跨市县','coordinate_kind':'approximate',
    'region_description':'山东省邹平市东部与淄博市西北部交界一带（用户提供）；参考点取今长山镇附近',
    'confidence':'low','source':'《山东通志》卷五（县级地名）；OpenStreetMap node 3979130141（今长山镇参考点）',
    'source_url':'https://zh.wikisource.org/wiki/山東通志_(四庫全書本)/卷05',
    'note':'历史长山县与现代长山镇分别记录。县级依据《山东通志》卷五；现代点位参照 https://www.openstreetmap.org/node/3979130141（Mapcarta https://mapcarta.com/15976808 显示36.87709,117.86641），取两位小数为区域近似点。不能由现代镇点还原整个旧县域；同名词的各篇指向仍需核对。'})

DISPLAY = OpenCC('t2s').convert
NORMAL = OpenCC('t2s').convert
VERSION = '2026.10.16-direction-review'
# UI releases must not invalidate the corpus identity or hide browser drafts.
ANNOTATION_VERSION = '2026.10.10-r3'
REALM_TERMS = {
    '天界': ('大羅刹國', '羅刹國', '羅剎國', '天宮', '天庭', '仙界', '仙境', '蓬萊', '瑤池', '龍宮', '海市'),
    '地界': ('冥府', '地府', '地獄', '幽冥', '陰司', '陰間', '酆都', '奈河', '冥間'),
}

# The user has supplied the semantic correction for these broad or ambiguous
# names.  Their points are deliberately labelled as reference/approximate
# points: a textual place name is not automatically a precise event location.
USER_CONFIRMED_PLACE_MAPS = {
    '黄河': {
        'modern_name': '黄河（山东段区域参考）', 'lon': 117.95, 'lat': 36.50,
        'type': 'river', 'admin_level': 'region', 'modern_level': '自然地理区域',
        'region_description': '黄河下游山东段；区域近似点，不代表具体河段',
        'coordinate_kind': 'approximate', 'confidence': 'medium',
        'note': '用户核定为黄河；此处只作山东段区域参考点，不据此推断故事中的具体渡口或河岸。',
    },
    '京': {
        'modern_name': '北京', 'lon': 116.4074, 'lat': 39.9042,
        'type': 'city', 'admin_level': 'prefecture', 'modern_level': '直辖市',
        'region_description': '今北京市', 'coordinate_kind': 'reference', 'confidence': 'high',
        'note': '用户核定“京”指北京；以北京市中心作参考点。',
    },
    '劳山': {
        'modern_name': '青岛崂山', 'lon': 120.4790, 'lat': 36.2020,
        'type': 'mountain', 'admin_level': 'natural', 'modern_level': '山岳地标',
        'region_description': '今山东省青岛市崂山区一带', 'coordinate_kind': 'approximate', 'confidence': 'high',
        'note': '用户核定劳山指青岛崂山；山体为区域对象，点位仅作参考。',
    },
    '江北': {
        'modern_name': '长江以北区域', 'lon': 118.50, 'lat': 32.80,
        'type': 'region', 'admin_level': 'region', 'modern_level': '历史地理区域',
        'region_description': '与江南相对，泛指长江以北；不是单一行政单位',
        'coordinate_kind': 'approximate', 'confidence': 'medium',
        'note': '用户核定江北与江南相对，指长江以北；中心点仅用于地图展示，不代表边界。',
    },
    '华山': {
        'modern_name': '陕西华山', 'lon': 110.0930, 'lat': 34.5450,
        'type': 'mountain', 'admin_level': 'natural', 'modern_level': '五岳山岳地标',
        'region_description': '今陕西省渭南市华阴市华山', 'coordinate_kind': 'reference', 'confidence': 'high',
        'note': '用户核定为五岳华山；点位指华山山岳地标，不等于华阴县域。',
    },
}

# These terms have a historical-search hit or a plausible lexical reading,
# but the user explicitly asked to keep them unresolved instead of putting a
# misleading point on the map.
USER_UNRESOLVED_PLACE_WORDS = {'南山', '芙蓉', '南城', '东村', '东山', '北山'}


def _valid_coordinates(match):
    """Return whether a CHGIS match can be rendered as a map reference."""
    try:
        lon, lat = float(match.get('lon')), float(match.get('lat'))
    except (TypeError, ValueError):
        return False
    # Zero components in this China historical gazetteer are missing-data
    # placeholders, not locations on Greenwich or the equator.
    return -180 <= lon <= 180 and -85 <= lat <= 85 and lon != 0 and lat != 0


def _history_match_score(word, match):
    """Prefer a Qing administrative/natural record over a village homonym."""
    if not _valid_coordinates(match):
        return -10_000
    name = NORMAL(str(match.get('name', '')))
    feature = NORMAL(str(match.get('feature_type', ''))).lower()
    score = 1000
    if name == word:
        score += 180
    elif name.startswith(word):
        score += 80
    if any(term in feature for term in ('省', '府', '州', '厅', '廳', '县', '縣', '道', '卫', '衛')):
        score += 120
    if any(term in feature for term in ('村', '镇', '鎮', '屯', '堡')):
        score -= 35
    years = str(match.get('years', ''))
    if '1820' in years:
        score += 30
    return score


def _history_place_type(match):
    """Translate a CHGIS feature label into the map's small type vocabulary."""
    label = NORMAL(str(match.get('feature_type', '')))
    # Type metadata takes precedence over characters in a proper name:
    # 山西 is a province; 江宁、湖州 are administrative places.
    if '省' in label:
        return 'region'
    if any(term in label for term in ('府', '州', '道', '县', '厅')):
        return 'historical-county' if '县' in label else 'city'
    if any(term in label for term in ('村', '镇', '屯', '堡')):
        return 'settlement'
    if '山' in label:
        return 'mountain'
    if any(term in label for term in ('河', '江', '湖', '海', '洲')):
        return 'river' if any(term in label for term in ('河', '江')) else 'lake'
    return 'city'


def _history_admin_level(match):
    label = NORMAL(str(match.get('feature_type', '')))
    if '省' in label:
        return 'province'
    if any(term in label for term in ('府', '州', '道', '厅', '廳')):
        return 'prefecture'
    if any(term in label for term in ('县', '縣')):
        return 'county'
    if any(term in label for term in ('村', '镇', '鎮', '屯', '堡')):
        return 'town'
    if any(term in label for term in ('山', '河', '江', '湖', '海')):
        return 'natural'
    return 'unknown'


def _promote_history_record(word, record):
    """Turn a coordinate-bearing Qing lookup into an auditable map point."""
    matches = [m for m in record.get('matches', []) if _valid_coordinates(m)]
    if not matches:
        return None
    selected = max(matches, key=lambda match: _history_match_score(word, match))
    feature = selected.get('feature_type') or '历史地名记录'
    parent = selected.get('parent_name') or '未提供清代隶属'
    return {
        'name': word,
        'modern_name': f"{selected.get('name', word)}（清代候选）",
        'lon': float(selected['lon']), 'lat': float(selected['lat']),
        'type': _history_place_type(selected),
        'admin_level': _history_admin_level(selected),
        'modern_level': f'清代检索类型：{feature}；现代层级待核',
        'region_description': f'清代隶属：{parent}',
        'coordinate_kind': 'reference', 'confidence': 'medium',
        'source': 'CHGIS／Harvard-Fudan Temporal Gazetteer，1820年清代优先检索',
        'source_url': selected.get('uri') or record.get('query_url'),
        'note': '用户说明：除南山、芙蓉、南城、东村、东山、北山等不详词外，其余历史检索候选可直接标图。此点为同名候选的参考点，不等于精确故事地点；同名记录与现代边界仍需核对。',
        'mapping_source': 'historical_search_auto_promoted',
        'historical_search': record,
        'selected_history_match': selected,
    }


def display_tree(value):
    """Convert display labels, never original source text, URLs or identifiers."""
    if isinstance(value, str):
        return DISPLAY(value)
    if isinstance(value, list):
        return [display_tree(v) for v in value]
    if isinstance(value, dict):
        return {DISPLAY(k): (v if k in {'original', 'text', 'excerpt', 'quote', 'narrative_analysis', 'narrative_events', 'source_url', 'query_traditional', 'id', 'migration_strings', 'name_aliases', 'conversion_license'} else display_tree(v))
                for k, v in value.items()}
    return value


def realm_evidence(units):
    """Exact lexical evidence, NOT an inferred destination or traversal."""
    records = []
    for unit in units:
        text = unit['text']
        covered = []
        for realm, words in REALM_TERMS.items():
            for word in sorted(words, key=len, reverse=True):
                needle = NORMAL(word)
                start = text.find(needle)
                while start >= 0:
                    end = start + len(needle)
                    if not any(start >= a and end <= b for a, b in covered):
                        covered.append((start, end))
                        records.append({'id': f"u{unit['unit']}-{start}-{end}",
                                        'realm': realm, 'space': word, 'unit': unit['unit'],
                                        'start': start, 'end': end, 'excerpt': unit['text'],
                                        'status': 'lexical_candidate',
                                        'relation': '篇內提及；非已確認跨界路線'})
                    start = text.find(needle, end)
    return records


def migration_strings():
    """Offline T2S dictionaries for preserving user-authored correction strings."""
    import opencc
    directory = Path(opencc.__file__).parent / 'dictionary'
    table = {}
    for filename in ('TSCharacters.txt', 'TSPhrases.txt'):
        for line in (directory / filename).read_text(encoding='utf-8').splitlines():
            if line.strip() and not line.startswith('#'):
                key, value = line.split('\t')
                table[key] = value.split(' ')[0]
    return table


def build_payload():
    from path_review_v2 import identity as step_identity, valid_review
    endpoint_file = DATA/'空间双端_AI审核.json'
    endpoint_reviews = {row['id']: row for row in json.loads(endpoint_file.read_text(encoding='utf-8')).get('reviews', [])} if endpoint_file.exists() else {}
    narrative_pilot = json.loads((ROOT/'narrative_space_pilot.json').read_text(encoding='utf-8'))
    narrative_cache = load_cache()['chapters']
    path_review_path = DATA/'空间路径_AI审核.json'
    path_reviews = {}
    if path_review_path.exists():
        try:
            path_reviews = {str(row['chapter_id']): row for row in json.loads(
                path_review_path.read_text(encoding='utf-8')).get('reviews', [])
                if row.get('chapter_id') is not None}
        except (OSError, ValueError, TypeError):
            path_reviews = {}
    profiles = json.loads((DATA/'篇目人物地點年份分析.json').read_text(encoding='utf-8'))['chapters']
    hotspots = json.loads((DATA/'異事地點熱點.json').read_text(encoding='utf-8'))['hotspots']
    source_path = ROOT/'nlp_dictionary'/'segmented_units.jsonl.gz'
    ai_segmentation_path = DATA/'分词_AI审核.json'
    ai_segmentation = {}
    if ai_segmentation_path.exists():
        try:
            ai_segmentation = {row['id']: row for row in json.loads(
                ai_segmentation_path.read_text(encoding='utf-8')).get('reviews', [])
                if row.get('id') and row.get('tokens')}
        except (OSError, ValueError, TypeError):
            # A partial or malformed AI checkpoint must never make the site
            # unavailable; the deterministic tokenizer remains the fallback.
            ai_segmentation = {}
    evidence_audit = json.loads((ROOT/'ghost_map_evidence_review.json').read_text(encoding='utf-8'))
    rejected_place_path = DATA/'地點詞表_人工審核排除.json'
    rejected_place_words = []
    if rejected_place_path.exists():
        rejected_place_words = sorted({row['word'] for row in json.loads(
            rejected_place_path.read_text(encoding='utf-8')).get('candidates', [])})
    used_review_ids = set()
    by_chapter = defaultdict(list)
    with gzip.open(source_path, 'rt', encoding='utf-8') as fh:
        for line in fh:
            unit = json.loads(line)
            by_chapter[unit['chapter_id']].append(unit)
    chapters = []
    for profile in profiles:
        chapter = display_tree({k: profile[k] for k in (
            'chapter_id', 'chapter', 'people', 'places', 'years', 'event_types',
            'realms_present', 'realm_review_status', 'realm_review_reason',
            'segmentation_note', 'review_note', 'annotation_status') if k in profile})
        cid = chapter['chapter_id']
        chapter['search_title'] = NORMAL(profile['chapter'])
        original_places = chapter.get('places', [])
        units = by_chapter[cid]
        chapter['source_units'] = []
        chapter['token_count'] = 0
        for unit in units:
            tokens = []
            for token in unit['tokens']:
                a, b = unit['alignment'][token['start']], unit['alignment'][token['end']]
                # Web segmentation only needs normalized half-open boundaries.
                # POS and original-coordinate alignment remain in the NLP cache.
                tokens.append([token['start'], token['end']])
            reviewed = ai_segmentation.get(f'c{cid}-u{unit["unit"]}')
            if reviewed:
                # The AI script validates every span against the exact source
                # text. Keep manual browser revisions separate and let only a
                # valid, unit-scoped checkpoint replace the baseline spans.
                candidate_tokens = reviewed.get('tokens', [])
                if all(isinstance(pair, list) and len(pair) == 2 and
                       isinstance(pair[0], int) and isinstance(pair[1], int) and
                       0 <= pair[0] < pair[1] <= len(unit['text'])
                       for pair in candidate_tokens):
                    tokens = candidate_tokens
            chapter['source_units'].append({'unit': unit['unit'], 'original': unit['original'],
                                            'text': unit['text'], 'tokens': tokens,
                                            'ai_review': bool(reviewed)})
            chapter['token_count'] += len(tokens)
        chapter['places'] = reviewed_places(chapter['chapter'], original_places, ''.join(u['text'] for u in chapter['source_units']))
        chapter['realm_evidence'] = display_tree(realm_evidence(units))
        chapter['space_evidence'] = scene_evidence(units)
        scene_targets = {PLACE_POLICY['spaces'][p['word']] for p in original_places if p['word'] in PLACE_POLICY['spaces']}
        scene_targets.update(PLACE_POLICY['chapter_spaces'].get(chapter['chapter'], []))
        for unit in chapter['source_units']:
            for word in sorted(scene_targets):
                start = unit['text'].find(word)
                while start >= 0:
                    if not any(e['unit']==unit['unit'] and e['word']==word and e['start']==start for e in chapter['space_evidence']):
                        chapter['space_evidence'].append(dict(word=word, category='方位与篇内空间', unit=unit['unit'],
                            start=start, end=start+len(word), excerpt=unit['text'], status='source_reviewed'))
                    start = unit['text'].find(word, start+len(word))
        chapter['space_words'] = list(dict.fromkeys(e['word'] for e in chapter['space_evidence']))
        by_unit = defaultdict(list)
        for evidence in chapter['space_evidence']:
            by_unit[evidence['unit']].append(evidence['word'])
        chapter['space_profile'] = {
            'status': 'machine_draft',
            'method': '原文单位中的地点候选、空间词与三界证据并列统计；未推断人物移动或空间意义。',
            'place_words': [p['word'] for p in chapter.get('places', [])],
            'space_words': chapter['space_words'],
            'space_counts': {word: sum(e['word'] == word for e in chapter['space_evidence']) for word in chapter['space_words']},
            'realm_labels': list(chapter.get('realms_present', [])),
            'event_types': list(chapter.get('event_types', {}).keys()),
            'people_count': len(chapter.get('people', [])),
            'evidence_units': [
                {'unit': unit, 'spaces': list(dict.fromkeys(words)),
                 'excerpt': next(u['text'] for u in units if u['unit'] == unit)}
                for unit, words in sorted(by_unit.items())
            ],
            'research_questions': [
                '这些地点词分别是事发地、籍贯、途经地还是仅被提及？需回到原文判断。',
                '空间词出现时，人物是否进入、停留、离开或只是叙述背景？目前不自动推断。',
                '空间变化是否伴随人物身份或异事类型变化？需要逐段核对。',
            ],
        }
        analysis = checked_record(narrative_cache.get(str(cid)), chapter)
        # Narrative events have one authoritative chapter collection. Keeping
        # a second mutable copy inside the analysis duplicated endpoint audits
        # and silently changed the supposedly historical AI reading.
        chapter['narrative_analysis'] = {key: value for key, value in analysis.items() if key != 'events'} if analysis else None
        chapter['narrative_editorial_notes'] = list(dict.fromkeys(r['note'] for r in narrative_cache.get(str(cid),{}).get('editorial_reviews',[])))
        chapter['narrative_status'] = 'close_reading_pilot' if str(cid) in narrative_pilot else 'ai_draft_source_checked' if analysis else 'pending'
        chapter['narrative_events'] = narrative_pilot.get(str(cid), analysis['events'] if analysis else [])
        path_review = path_reviews.get(str(cid))
        if path_review:
            # DeepSeek may review the baseline and add only source-anchored
            # omissions. Browser-saved human edits remain a later overlay.
            reviewed = {int(row['step']): row for row in path_review.get('classifications', [])
                        if isinstance(row.get('step'), int)}
            for index, event in enumerate(chapter['narrative_events']):
                row = reviewed.get(index)
                if not row:
                    continue
                event['space_access'] = row['space_access']
                event['space_realm'] = row['space_realm']
                event['space_review_source'] = 'deepseek'
                event['space_review_evidence'] = row.get('evidence', '')
                event['classification_binding'] = 'legacy_step_index'
            existing_quotes = {event.get('quote', '') for event in chapter['narrative_events']}
            for event in path_review.get('added_events', []):
                # Re-anchor a unique continuous quote to the actual source
                # units. Providers occasionally return a nearby unit number
                # while preserving the exact quote; never publish an invalid
                # unit reference.
                quote = event.get('quote', '')
                full_source = ''.join(unit['text'] for unit in chapter['source_units'])
                hit = full_source.find(quote) if quote else -1
                if quote and hit >= 0 and full_source.find(quote, hit + 1) < 0:
                    offsets, cursor = [], 0
                    for source_unit in chapter['source_units']:
                        offsets.append((source_unit['unit'], cursor, cursor + len(source_unit['text'])))
                        cursor += len(source_unit['text'])
                    covered = [number for number, start, end in offsets if start < hit + len(quote) and hit < end]
                    if covered:
                        event['unit'], event['unit_end'] = covered[0], covered[-1]
                if event.get('quote') and event['quote'] not in existing_quotes:
                    chapter['narrative_events'].append(event)
                    existing_quotes.add(event['quote'])
            chapter['narrative_events'].sort(key=lambda event: (event.get('unit', 0), event.get('unit_end', event.get('unit', 0))))
            chapter['narrative_ai_path_review'] = {
                'status': 'deepseek_context_review',
                'classifications': len(path_review.get('classifications', [])),
                'added_events': len(path_review.get('added_events', [])),
            }
        for event in chapter['narrative_events']:
            event['step_id'] = step_identity(cid, event)
            endpoint_review = endpoint_reviews.get(event['step_id'])
            if endpoint_review and valid_review(endpoint_review, event, chapter):
                event['endpoint_review'] = dict(endpoint_review)
                if not event.get('from_space'):
                    for field in ('access', 'realm', 'type'):
                        event['endpoint_review']['from_'+field] = '待核'
                event['space_access'] = endpoint_review['to_access']
                event['space_realm'] = endpoint_review['to_realm']
                event['space_review_source'] = 'deepseek'
                event['space_review_evidence'] = endpoint_review['reason']
                event['classification_binding'] = 'source_hash_and_step_id'
            evidence_unit = next((u for u in units if u['unit'] == event['unit']), None)
            evidence_text = ''.join(u['text'] for u in units if event['unit'] <= u['unit'] <= event.get('unit_end',event['unit']))
            if not evidence_unit or not event['quote'] or event['quote'] not in evidence_text:
                raise ValueError(f'Narrative evidence mismatch: chapter {cid}, unit {event["unit"]}')
        chapter['evidence_review'] = {e['id']: evidence_audit['reviews'][e['id']]
            for e in chapter['realm_evidence'] if e['id'] in evidence_audit['reviews']}
        used_review_ids.update(chapter['evidence_review'])
        # A lexical hit missing from the old realm classifier must still be
        # available for inspection (e.g. 伍秋月、晚霞). This remains a candidate.
        chapter['realms_present'] = list(dict.fromkeys(chapter['realms_present'] + [
            e['realm'] for e in chapter['realm_evidence'] if
            chapter['evidence_review'].get(e['id'], {}).get('kind') != 'reject']))
        # The old realm_spaces field expands an entire lexicon for one trigger.
        # Replace it with observed words, retaining the old judgment only as a candidate.
        chapter['realm_spaces'] = list(dict.fromkeys(e['space'] for e in chapter['realm_evidence']))
        chapter.setdefault('annotation_status', '既有模型／规则候选，需逐篇核对')
        for index, person in enumerate(chapter['people']):
            person['id'] = f"c{cid}-p{index}"
            person['identity_links'] = [link for link in person.get('identity_links', []) if cid in link.get('chapters', [])]
            person['canonical'] = person.get('canonical', '')
            person.setdefault('review_status', 'candidate')
            if '神／仙' in person.get('person_types', {}):
                person['person_types']['神'] = person['person_types'].pop('神／仙')
            person['ontology_status'] = 'candidate' if person['review_status'] == 'candidate' else 'reviewed'
            person['ontology_evidence'] = '按人物词形邻近语境的规则候选；未完成人工／AI身份核定。' if person['ontology_status'] == 'candidate' else '已标记为人工核定。'
        chapters.append(chapter)
    if used_review_ids != set(evidence_audit['reviews']):
        raise ValueError('Space evidence review IDs no longer match the source; audit before building.')
    # Keep a compact, inspectable inventory in the standalone page.  The full
    # source examples remain in the JSON audit files; the page gets enough
    # context to let a researcher decide whether to open a chapter and edit it.
    def candidate_panel(kind, filename, rejected_filename=None, ai_filename=None):
        raw = json.loads((DATA / filename).read_text(encoding='utf-8')).get('candidates', [])
        rejected = {}
        if rejected_filename and (DATA / rejected_filename).exists():
            rejected = {r['word']: r for r in json.loads((DATA / rejected_filename).read_text(encoding='utf-8')).get('candidates', [])}
            # The accepted inventory is intentionally smaller after AI review;
            # append rejected rows so the website still exposes the full
            # candidate universe for audit and manual reconsideration.
            known = {r['word'] for r in raw}
            raw.extend(r for word, r in rejected.items() if word not in known)
        ai = {}
        if ai_filename and (DATA / ai_filename).exists():
            ai = {r['word']: r for r in json.loads((DATA / ai_filename).read_text(encoding='utf-8')).get('reviews', [])}
        chapter_ids = defaultdict(list)
        for c in chapters:
            for row in c['people' if kind == 'person' else 'places']:
                chapter_ids[row['word']].append(c['chapter_id'])
        rows = []
        for r in raw:
            word = r['word']; review = ai.get(word)
            if kind == 'place' and rejection_reason(NORMAL(word)):
                rejected[word] = dict(r, reason=rejection_reason(NORMAL(word)))
                if NORMAL(word) not in rejected_place_words:
                    rejected_place_words.append(NORMAL(word))
            if word in rejected:
                status = '规则／AI排除'
            elif review and review.get('label') == ('person' if kind == 'person' else 'place') and review.get('confidence', 0) >= .8:
                status = 'DeepSeek确认候选'
            elif review:
                status = 'DeepSeek待核／排除'
            else:
                status = '模型候选，待人工核对'
            rows.append({'word': word, 'mentions': r.get('mentions', 0), 'chapters': r.get('chapters', 0),
                         'methods': r.get('methods', []), 'examples': r.get('examples', [])[:1],
                         'chapter_ids': chapter_ids.get(word, []), 'status': status,
                         **({'ai_review': review} if review else {}),
                         **({'rejection_reason': rejected[word].get('reason', '')} if word in rejected else {})})
            if kind == 'place' and word in PLACE_POLICY['pending']:
                rows[-1]['context_review_note'] = PLACE_POLICY['pending'][word]
        return {'kind': kind, 'count': len(rows), 'rows': rows,
                'note': '模型／AI复核均为候选，需以原文篇目为单位人工确认。'}
    candidate_review = {
        'people': candidate_panel('person', '人物詞表_全量模型候選.json', ai_filename='人物詞表_AI审核.json'),
        'places': candidate_panel('place', '地點詞表_全量模型候選.json', '地點詞表_人工審核排除.json', '地點詞表_AI审核.json'),
    }
    year_inventory = json.loads((DATA/'時間詞表_全量模型候選.json').read_text(encoding='utf-8'))
    time_rows = {}
    for occurrence in year_inventory.get('candidates', []):
        value = occurrence['word']
        row = time_rows.setdefault(value, {'word': value, 'mentions': 0, 'chapter_ids': [], 'examples': [], 'methods': []})
        row['mentions'] = occurrence.get('mentions', 0)
        row['chapter_ids'] = occurrence.get('chapter_ids', [])
        row['methods'] = occurrence.get('methods', [])
        row['examples'] = [{'chapter': e['chapter'], 'context': e['context']} for e in occurrence.get('examples', [])[:1]]
    candidate_review['times'] = {'kind': 'time', 'count': len(time_rows), 'rows': sorted(
        time_rows.values(), key=lambda r: (-r['mentions'], r['word'])),
        'note': '正則候選；包含年号、年龄、相对时长与月日，不等于全部历史年份。'}
    chronology = build_chronology(chapters)
    review_path=DATA/'年份词_AI审核.json'
    if review_path.exists():
        from ai_review_chronology import candidate_items, apply_reviews
        reviews=json.loads(review_path.read_text(encoding='utf-8')).get('reviews',[])
        chronology=apply_reviews(chronology,reviews,candidate_items({'chapter_overview':chapters}))
    # A reviewed, geocodable single occurrence must not disappear merely because
    # the old hotspot ranking required >=2 model mentions (e.g. 安丘).
    by_name = {NORMAL(r['name']): r for r in GAZETTEER}
    existing = {NORMAL(h['place']) for h in hotspots}
    for word in sorted({NORMAL(p['word']) for c in chapters for p in c['places']}):
        if word in by_name and word not in existing:
            hotspots.append({'place': word})
    places, unmapped, links = [], [], []
    historical_search_path = DATA/'未定位地名_历史检索.json'
    historical_search = {}
    historical_search_payload = {'records': []}
    if historical_search_path.exists():
        historical_search_payload = json.loads(historical_search_path.read_text(encoding='utf-8'))
        historical_search = {NORMAL(row['word']): row for row in historical_search_payload.get('records', [])}
    # Promote every coordinate-bearing historical-search result except terms
    # explicitly kept unresolved by the user.  This makes the map useful as a
    # review surface while preserving the original search record as evidence.
    promoted_history = {}
    for word, record in historical_search.items():
        if word in USER_UNRESOLVED_PLACE_WORDS or word in USER_CONFIRMED_PLACE_MAPS:
            continue
        promoted = _promote_history_record(word, record)
        if promoted:
            promoted_history[word] = promoted
    user_confirmed = {}
    for word, fields in USER_CONFIRMED_PLACE_MAPS.items():
        user_confirmed[word] = {
            'name': word, **fields,
            'source': '用户核定释义与区域；坐标为地图参考点',
            'source_url': 'https://chgis.hudci.org/tgw/',
            'mapping_source': 'user_confirmed',
        }
    by_name = {NORMAL(r['name']): r for r in GAZETTEER}
    for word, record in {**promoted_history, **user_confirmed}.items():
        by_name.setdefault(NORMAL(word), record)
    # Use every place word present in the chapter-level inventory.  Hotspots
    # are useful for ranking, but must not decide which unresolved words get a
    # historical-name search: the UI promises a complete audit list.
    all_textual_places = sorted({NORMAL(place['word']) for chapter in chapters for place in chapter['places']})
    for textual_place in all_textual_places:
        base = by_name.get(textual_place)
        ids = sorted({
            c['chapter_id'] for c in chapters if any(
                NORMAL(p['word']) == textual_place for p in c['places'])})
        if base is None:
            row = {'place': DISPLAY(textual_place), 'chapter_ids': ids,
                   'search_name': textual_place,
                   'reason': '尚無已核實的人間地理對照；可能是泛稱、異域或模型誤識，請依原文核對。'}
            if textual_place in historical_search:
                row['historical_search'] = historical_search[textual_place]
            unmapped.append(row)
            continue
        p = display_tree(base)
        p['search_names'] = list(dict.fromkeys([p['name'], NORMAL(p['name']), p['modern_name'], NORMAL(p['modern_name'])]))
        p.update({'id': 'place-'+NORMAL(base['name']), 'chapter_ids': ids,
                  'mapping_review_status': (
                      '用户核定；坐标为区域／地标参考点，仍需逐篇核对' if p.get('mapping_source') == 'user_confirmed'
                      else '清代检索候选已直接标图；同名与现代对应仍需逐篇核对' if p.get('mapping_source') == 'historical_search_auto_promoted'
                      else '現代參考點；古今範圍、籍貫與事發位置仍需逐篇核對')})
        # Keep lightweight references, not independently editable chapter snapshots.
        p['textual'] = {'place': p['name'], 'ordered_chapters': [
            {'chapter_id': cid, 'chapter': chapters[cid]['chapter']} for cid in ids]}
        places.append(p)
        for cid in ids:
            for evidence in chapters[cid]['realm_evidence']:
                if chapters[cid]['evidence_review'].get(evidence['id'], {}).get('kind') == 'reject':
                    continue
                links.append({'place_id': p['id'], 'chapter_id': cid, 'evidence_id': evidence['id']})
    audit_searches = dict(historical_search)
    mapped_search_path = DATA / '已定位地名_清代核对.json'
    if mapped_search_path.exists():
        audit_searches.update({NORMAL(r['word']): r for r in json.loads(mapped_search_path.read_text(encoding='utf-8'))['records']})
    places, audit_withdrawn, location_audit = audit_place_locations(places, chapters, audit_searches)
    unmapped.extend(audit_withdrawn)
    # Withdraw erroneous edges without removing the original entity or excerpt.
    mapped_ids = {p['id'] for p in places}
    links = [link for link in links if link['place_id'] in mapped_ids]
    place_hierarchy = annotate_place_hierarchy(places)
    chapter_by_id = {c['chapter_id']: c for c in chapters}
    place_chapters = {p['name']: [c['chapter_id'] for c in chapters if any(NORMAL(x['word']) == NORMAL(p['name']) for x in c['places'])] for p in places}
    scene_chapters = defaultdict(set)
    scene_mentions = Counter()
    scene_by_realm = defaultdict(Counter)
    scene_by_event = defaultdict(Counter)
    transitions = Counter()
    place_scene = defaultdict(Counter)
    for chapter in chapters:
        evidence = chapter.get('space_evidence', [])
        for row in evidence:
            scene_chapters[row['word']].add(chapter['chapter_id'])
            scene_mentions[row['word']] += 1
            for realm in chapter.get('realms_present', []): scene_by_realm[realm][row['word']] += 1
            for event_type in chapter.get('event_types', {}): scene_by_event[event_type][row['word']] += 1
            for place in chapter.get('places', []): place_scene[place['word']][row['word']] += 1
        ordered = []
        for row in chapter.get('space_evidence', []):
            if not ordered or ordered[-1][0] != row['unit']: ordered.append((row['unit'], row['word']))
        for left, right in zip(ordered, ordered[1:]):
            if left[1] != right[1]: transitions[(left[1], right[1])] += 1
    synthesis = {
        'method': '全书关系综合：篇目是基本单位；地点词与空间词分层；空间词按原文单位顺序计算邻接；不把共现自动解释为人物移动或因果。',
        'coverage': {'chapters': len(chapters), 'chapters_with_scene_evidence': len({cid for ids in scene_chapters.values() for cid in ids}),
                     'named_places': len(places), 'scene_terms': len(scene_chapters), 'scene_mentions': sum(scene_mentions.values())},
        'top_scene_terms': [{'word': w, 'mentions': n, 'chapters': len(scene_chapters[w])} for w, n in scene_mentions.most_common(40)],
        'place_scene': [{'place': p, 'chapters': len(place_chapters.get(p, [])), 'scenes': dict(counts)} for p, counts in sorted(place_scene.items(), key=lambda item: (-len(place_chapters.get(item[0], [])), item[0]))[:60]],
        'realm_scene': {realm: dict(counts.most_common(30)) for realm, counts in scene_by_realm.items()},
        'event_scene': {event: dict(counts.most_common(30)) for event, counts in scene_by_event.items()},
        'scene_transitions': [{'from': left, 'to': right, 'count': n} for (left, right), n in transitions.most_common(50)],
        'research_claims': [
            '地点词与空间词不是同一尺度：前者可连接历史地理，后者主要塑造篇内场景。',
            '同一空间词跨越不同地点与异事类型时，应比较其叙事功能，而非把它固定为某一类鬼怪空间。',
            '空间转移只能在逐段事件路径中确认；篇目级共现只适合提出问题，不能证明旅行路线。',
            '人物序列、异事类型和三界是篇目标签，必须与原文事件阶段结合，不能用篇目标签替代人物行动。',
        ],
    }
    return {
        'schema_version': 2, 'app_version': VERSION,
        # Keep previous generated hashes so browser drafts migrate after rebuilds.
        'compatible_source_sha256': ['230b005976350e5b4ed99fa488613b84cc2c19c411f80b6ecb91a6eb4b6b1279', '12b76b86d75a47a665e60e564d6a33173be267700ef52f8be34f0757dd316c38'],
        'migration_strings': migration_strings(),
        'conversion_license': distribution('opencc-python-reimplemented').read_text('LICENSE.txt'),
        'corpus_id': hashlib.sha256(source_path.read_bytes()).hexdigest(),
        'source_sha256': hashlib.sha256(ANNOTATION_VERSION.encode() + source_path.read_bytes() + json.dumps(
            profiles, ensure_ascii=False, sort_keys=True).encode('utf-8') + json.dumps(
            evidence_audit, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest(),
        'name_aliases': {r['name']: NORMAL(r['name']) for r in GAZETTEER},
        'method': '篇目共現＋原文詞彙證據；不等於事發地、旅行路線或故事年代',
        'coordinate_warning': '地圖採現代參考點／區域近似，不重建清代邊界；籍貫、提及與事發地尚需區分。',
        'mapping_review': {'mapped_count': len(places), 'unmapped_count': len(unmapped),
                           'user_confirmed_count': len(user_confirmed),
                           'historical_search_auto_promoted_count': len(promoted_history),
                           'user_unresolved_words': sorted(USER_UNRESOLVED_PLACE_WORDS)},
        'places': places, 'unmapped_textual_places': unmapped, 'historical_place_search': historical_search_payload,
        'location_audit': location_audit,
        'chapter_overview': chapters,
        'place_hierarchy': place_hierarchy,
        'candidate_review': candidate_review,
        'chronology': chronology,
        'rejected_place_words': rejected_place_words,
        'realm_links': links,
        'person_type_legend': {'人': '人类', '鬼': '鬼类', '妖': '妖类', '神': '神／仙类'},
        'book_synthesis': synthesis,
        'narrative_coverage': {'total': len(chapters), 'ai_read': sum(bool(c['narrative_analysis']) for c in chapters),
            'endpoint_reviewed_steps': sum(bool(e.get('endpoint_review')) for c in chapters for e in c['narrative_events']),
            'classification_missing_steps': sum(e.get('space_review_source') != 'deepseek' for c in chapters for e in c['narrative_events']),
            'with_paths': sum(bool(c['narrative_events']) for c in chapters),
            'pending': [c['chapter_id'] for c in chapters if not c['narrative_analysis']],
            'method': '逐篇全文AI阅读；原文单位与引句程序核验；解释及主题待人工核定。三篇精读及浏览器人工修订优先。'},
        'research_documents': [{'title': title, 'content': DISPLAY((ROOT / filename).read_text(encoding='utf-8'))}
            for title, filename in [('空间路径复查与双端审核', '空间路径复查说明.md'),
                                    ('方位与地名逐词复核（267词）', 'direction_place_audit.md'),
                                    ('研究台使用与研究方法', '空间叙事研究台使用说明.md'),
                                    ('人物路线、时地关联与空间塑造', '人物路径与空间研究说明.md'),
                                    ('全书空间综合分析', '全书空间综合分析.md'),
                                    ('三篇空间叙事精读', '情节空间试点分析.md'),
                                    ('黄英空间数字人文分析', '黃英空間數字人文分析.md')]],
    }


def render_html(payload):
    payload = dict(payload, modern_boundaries=json.loads((ROOT/'modern_province_boundaries.geojson').read_text(encoding='utf-8')))
    template = (ROOT/'ghost_map_template.html').read_text(encoding='utf-8')
    data = json.dumps(payload, ensure_ascii=False, separators=(',', ':')).replace('<', r'\u003c')
    return (DISPLAY(template).replace('zh-Hant', 'zh-Hans').replace('__MAP_DATA__', data)
            .replace('__MAP_MODEL__', 'globalThis.GhostMapPlaceReview=' + json.dumps(PLACE_POLICY, ensure_ascii=False).replace('<', r'\u003c') + ';\n' + (ROOT/'ghost_map_model.js').read_text(encoding='utf-8'))
            .replace('__MAP_PACKAGE__', (ROOT/'ghost_map_package.js').read_text(encoding='utf-8'))
            .replace('__MAP_NARRATIVE__', (ROOT/'ghost_map_narrative.js').read_text(encoding='utf-8'))
            .replace('__MAP_REPORTS__', (ROOT/'ghost_map_reports.js').read_text(encoding='utf-8'))
            .replace('__MAP_GEOMETRY__', (ROOT/'ghost_map_geometry.js').read_text(encoding='utf-8'))
            .replace('__MAP_APP__', (ROOT/'ghost_map_app.js').read_text(encoding='utf-8')))


def main():
    payload = display_tree(build_payload())
    # One record per line avoids millions of diff lines for token metadata.
    encoded = '{\n' + ',\n'.join(json.dumps(k, ensure_ascii=False) + ':' + (
        '[\n' + ',\n'.join(json.dumps(row, ensure_ascii=False, separators=(',', ':')) for row in v) + '\n]'
        if isinstance(v, list) else json.dumps(v, ensure_ascii=False, separators=(',', ':')))
        for k, v in payload.items()) + '\n}\n'
    (DATA/'歷史地名對照與文本地圖.json').write_text(encoded, encoding='utf-8')
    (DATA/'聊齋鬼怪歷史地理互動地圖.html').write_text(render_html(payload), encoding='utf-8')
    (DATA/'故事地点年表.json').write_text(json.dumps(payload['chronology'],ensure_ascii=False,indent=2),encoding='utf-8')
    (DATA/'故事地点年表.md').write_text(render_report(payload['chronology']),encoding='utf-8')
    (DATA/'全书简体分词输入.txt').write_text('\n\n'.join(c['chapter'] + '\n' + ''.join(
        NORMAL(u['original']) for u in c['source_units']) for c in payload['chapter_overview']), encoding='utf-8')
    print(json.dumps({'mapped': len(payload['places']),
                      'chapters': len(payload['chapter_overview']),
                      'version': VERSION}))


if __name__ == '__main__':
    main()
