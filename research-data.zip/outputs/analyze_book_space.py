"""Post-segmentation lexical-family analysis; not a full semantic gold standard."""
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
from liaozhai_nlp import (CJK, jsonl_read, jsonl_write, json_write, collocations,
                          comparisons, FUNCTION_WORDS)

ROOT=Path(__file__).parent
INPUT=ROOT/'nlp'
OUTPUT=ROOT/'book_space'
SOURCE_SHA='28bc2dcf34612ca44c4dccadd0351edea130cca135dfd41bccb144660fc6e665'
# All forms selected AFTER inspection of full-corpus vocabulary and KWIC.
# Families label expressions, not mutually exclusive real-world building types.
FAMILIES={
    '寺院词族': ['寺','兰若','禅院','某寺','萧寺','废寺','野寺','古寺','僧寺','报国寺',
        '柳沟寺','旧寺','山寺','菩陀寺','兴福寺','寄灵寺','香水月寺','水月寺','醴泉寺',
        '大佛寺','蛇佛寺','五莲山寺','天宁寺','伏虎寺','金沙寺','寺院','大禅院',
        '匡山僧寺','寺门','寺观'],
    '庙庵词族': ['庙','庙宇','庙门','青帝庙','圣庙','岳庙','东岳庙','城隍庙',
        '关庙','观音庙','关帝庙','吴王庙','宗庙','庵','庵中','庵前','吕祖庵'],
    '园圃词族': ['园','园中','园亭','亭园','后园','荒园','园门','园墙','花畦','畦',
        '畦边','荒圃','旧圃','民圃','周氏园','何氏园','小园','废园','读书园','桃园',
        '亲园','皇亲园','西园','园所','绅园','孤园','春园'],
    '旅寓词族': ['旅舍','逆旅','旅邸','旅店','税舍','逆旅阁','旅肆','寓所'],
    '客舍词': ['客舍'],
    '署衙词族': ['署','官署','内署','廨署','县署','衙门','官衙','衙署'],
    '墓葬词族': ['墓','坟','冢','墓所','祖墓','冢室','坟冢','孤坟','坟垅','墓处',
        '荒坟','荒墓','荒冢','墓木','父墓','丘墓','墓地','故墓','女冢','母冢',
        '妾墓','墟墓','墓田','坟墓','古墓','墓门','墓址'],
}
# Full review of independent 坟 (17) and 署 (18), bound to this corpus checksum.
EXCLUSIONS={
    (537,'坟'):'body swelling', (14747,'坟'):'body swelling',
    (15800,'坟'):'body swelling', (22980,'坟'):'body swelling',
    (28408,'坟'):'body swelling', (17405,'坟'):'ancient texts 三坟',
    (21414,'坟'):'ancient texts 三坟', (31018,'署'):'verb inscribe a sign',
    (21840,'西园'):'part of personal name 高西园',
    (8425,'冢室'):'principal wife, not tomb chamber',
    (9410,'冢室'):'principal wife, not tomb chamber',
}
NONMEMBERS={'寺人':'eunuch, not temple','适阉寺':'eunuch expression',
    '桂庵':'personal name','青庵':'personal name','吴青庵':'personal name',
    '高西园':'personal name','晤杞园':'personal name within phrase',
    '梨园':'performing-arts allusion in observed context',
    '梨园子弟':'actors, not a garden','畛畦':'figurative social boundary',
    '不为畛畦':'figurative social boundary','园丁':'occupation, not place',
    '冢宰':'official title, not tomb','冢室':'principal wife in both exact-token contexts',
    '署券':'sign a deed, not office',
    '地狱':'mixed simile and world-reference; not pooled with actual offices',
    '城隍':'deity/office holder, not by itself an architectural space',
    '客舍':'separate family; often private guest quarters, not necessarily an inn'}

# These are retained model-token forms containing a spatial reference, not
# validated dictionary entries or proper place names. Never geocode them as-is.
TOKENIZATION_CAVEATS={
    '香水月寺':'降香 + 水月寺, not a temple named 香水月寺',
    '寄灵寺':'寄灵 + 寺, not a temple named 寄灵寺',
    '读书园':'读书 + 园, not a garden named 读书园',
    '亲园':'fragment of 皇亲园',
    '孤园':'fragment of 给孤园 in both selected occurrences',
}


def collect_families(units, families=FAMILIES, exclusions=EXCLUSIONS):
    lookup=defaultdict(list)
    for family,words in families.items():
        for word in words:
            lookup[word].append(family)
    spans=defaultdict(list)
    mentions,excluded=[],[]
    for u in units:
        for i,t in enumerate(u['tokens']):
            word=t['word']
            if word not in lookup:
                continue
            context={'unit':u['unit'],'chapter_id':u['chapter_id'],'chapter':u['chapter'],
                'word':word,'start':t['start'],'end':t['end'],'original':u['original']}
            if (u['unit'],word) in exclusions:
                excluded.append({**context,'reason':exclusions[u['unit'],word]})
                continue
            # Do not count 寺 as a place if tokenizer splits 寺僧 / 寺人.
            if word=='寺' and u['text'][t['end']:t['end']+1] in {'僧','人'}:
                excluded.append({**context,'reason':'monk/eunuch compound, not spatial head'})
                continue
            for family in lookup[word]:
                spans[family].append((u['unit'],i,i+1,t['start'],t['end']))
                a,b=u['alignment'][t['start']],u['alignment'][t['end']]
                mentions.append({**context,'family':family,'original_form':u['original'][a:b],
                    'annotation_status':'post-discovery form inclusion + explicit sense exclusions; not full gold annotation'})
    return dict(spans),mentions,excluded


def statistics(units,mentions,families=FAMILIES):
    chapter_lengths=Counter()
    titles={}
    for u in units:
        chapter_lengths[u['chapter_id']]+=len(CJK.findall(u['original']))
        titles[u['chapter_id']]=u['chapter']
    total=sum(chapter_lengths.values())
    result=[]
    for family,forms in families.items():
        rows=[m for m in mentions if m['family']==family]
        counts=Counter(m['chapter_id'] for m in rows)
        coverage={m['unit'] for m in rows}
        ranked=sorted(counts,key=lambda cid:(-counts[cid],cid))
        result.append({'family':family,'selected_forms':forms,'observed_forms':dict(Counter(m['word'] for m in rows)),
            'mentions':len(rows),'clauses':len(coverage),'chapters':len(counts),
            'per_10000_cjk':round(len(rows)*10000/total,4),
            'max_single_chapter_share':round(max(counts.values(),default=0)/len(rows),4) if rows else 0,
            'top_chapters_by_count':[{'chapter_id':cid,'chapter':titles[cid],'mentions':counts[cid],
                'cjk':chapter_lengths[cid],'per_10000_cjk':round(counts[cid]*10000/chapter_lengths[cid],3)} for cid in ranked[:12]]})
    pairs=[]
    sets={f:{m['chapter_id'] for m in mentions if m['family']==f} for f in families}
    keys=list(families)
    for i,a in enumerate(keys):
        for b in keys[i+1:]:
            shared=sets[a]&sets[b]
            pairs.append({'a':a,'b':b,'shared_chapters':len(shared),
                'chapter_jaccard':round(len(shared)/len(sets[a]|sets[b]),5) if sets[a]|sets[b] else None,
                'chapters':[{'chapter_id':cid,'chapter':titles[cid]} for cid in sorted(shared)],
                'meaning':'same chapter only; NOT spatial adjacency or movement'})
    return result,pairs


def contexts_for_pair(units,spans,collocate,horizon):
    seen=set()
    contexts=[]
    occupied=defaultdict(set)
    for uid,a,b,*_ in spans:
        occupied[uid].update(range(a,b))
    for uid,a,b,*_ in spans:
        for i in range(max(0,a-horizon),min(len(units[uid]['tokens']),b+horizon)):
            if i in occupied[uid] or (uid,i) in seen:
                continue
            if units[uid]['tokens'][i]['word']==collocate:
                seen.add((uid,i))
                contexts.append({'unit':uid,'collocate_token_index':i,'chapter':units[uid]['chapter'],
                                 'original':units[uid]['original']})
    return contexts


def figure(rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans']
    plt.rcParams['axes.unicode_minus']=False
    # Inspect these comparable role/action words, without re-labelling all characters.
    words=['读书','寄宿','僧','道士','主人','女','清明','葬','寻','白杨','入']
    families=list(FAMILIES)
    lookup={(r['target'],r['collocate']):r for r in rows}
    values=np.full((len(families),len(words)),np.nan)
    for i,f in enumerate(families):
        for j,w in enumerate(words):
            r=lookup.get((f,w))
            if r and r['observed']>=3 and r['oe_ratio']>1:
                values[i,j]=r['log2_oe']
    fig,ax=plt.subplots(figsize=(13,6),constrained_layout=True)
    plot=ax.imshow(np.ma.masked_invalid(values),cmap='YlGnBu',vmin=0,vmax=8)
    ax.set_xticks(range(len(words)),words,fontsize=11)
    ax.set_yticks(range(len(families)),families,fontsize=11)
    for i,f in enumerate(families):
        for j,w in enumerate(words):
            if np.isfinite(values[i,j]):
                r=lookup[f,w]
                ax.text(j,i,f"{r['oe_ratio']:.1f}\nn={r['observed']}",ha='center',va='center',fontsize=9,
                        color='white' if values[i,j]>4.5 else '#14202b')
    ax.set_title('全書選定空間詞族的搭配：同分句內 ±5 詞',fontsize=16,pad=15)
    ax.set_xlabel('格內為 O/E 與觀察詞位數；空白 = n < 3 或 O/E ≤ 1\n詞族在分詞完成後選定；共現不等於人物身分或移動事件',labelpad=13)
    fig.colorbar(plot,ax=ax,label='log2(O/E)')
    fig.savefig(OUTPUT/'空间词族搭配.png',dpi=170)
    plt.close(fig)


def main():
    manifest=json.loads((INPUT/'manifest.json').read_text(encoding='utf-8'))
    if manifest['source_sha256']!=SOURCE_SHA:
        raise ValueError('Sense review is tied to the inspected source edition.')
    units=jsonl_read(INPUT/'segmented_units.jsonl.gz')
    OUTPUT.mkdir(exist_ok=True)
    spans,mentions,excluded=collect_families(units)
    json_write(OUTPUT/'词族定义与排除规则.json',{'source_sha256':SOURCE_SHA,'families':FAMILIES,
        'excluded_forms_with_reason':NONMEMBERS,
        'retained_tokenization_caveats':TOKENIZATION_CAVEATS,
        'scope':'Conservative selected token forms AFTER full-corpus segmentation; partial lexical coverage; not a semantic census.'})
    json_write(OUTPUT/'词族全部语境.json',{'mentions':mentions,'excluded_occurrences':excluded})
    stats,pairs=statistics(units,mentions)
    json_write(OUTPUT/'词族频率与篇章分布.json',stats)
    json_write(OUTPUT/'词族跨篇共现.json',pairs)
    for method,horizon in [('window',5),('window',10),('sentence',0)]:
        rows,family=collocations(units,set(FAMILIES),method=method,horizon=horizon,reviewed_occurrences=spans)
        jsonl_write(OUTPUT/f'词族搭配_{method}{horizon}.jsonl.gz',rows)
        top={f:sorted([r for r in rows if r['target']==f and r['observed']>=3 and r['support_chapters']>=2
            and r['collocate'] not in FUNCTION_WORDS and r['oe_ratio']>1],
            key=lambda r:(-r['oe_ratio'],-r['observed']))[:25] for f in FAMILIES}
        json_write(OUTPUT/f'高支持搭配_{method}{horizon}.json',top)
        if horizon==5:
            json_write(OUTPUT/'词族搭配相似度.json',comparisons(rows,set(FAMILIES)))
            selected=[('寺院词族','读书'),('寺院词族','寄宿'),('庙庵词族','道士'),
                ('园圃词族','女'),('旅寓词族','主人'),('署衙词族','女'),
                ('墓葬词族','清明'),('墓葬词族','白杨'),('墓葬词族','葬'),('墓葬词族','寻')]
            evidence=[]
            for family,word in selected:
                row=next(r for r in rows if r['target']==family and r['collocate']==word)
                evidence.append({**row,'contexts':contexts_for_pair(units,spans[family],word,5)})
            json_write(OUTPUT/'重点词对原文证据.json',evidence)
            figure(rows)
    metadata={'source_sha256':SOURCE_SHA,'segmentation_cache_sha256':hashlib.sha256((INPUT/'segmented_units.jsonl.gz').read_bytes()).hexdigest(),
        'pipeline_version':manifest['pipeline_version'],'chapter_units':manifest['chapter_units'],
        'cjk':manifest['cjk_characters'],'families':len(FAMILIES),'selected_mentions':len(mentions),
        'explicitly_excluded_token_occurrences':len(excluded),
        'count_unit':'selected token positions; same-clause and chapter cooccurrence separate',
        'coverage_limit':'Chosen lexical forms; misses alternate/embedded forms; roles and worlds not fully annotated.'}
    json_write(OUTPUT/'manifest.json',metadata)
    print(json.dumps([{k:r[k] for k in ['family','mentions','chapters','per_10000_cjk']} for r in stats],ensure_ascii=False))

if __name__=='__main__':
    main()
