"""Open-vocabulary segmentation, candidate extraction, concordance and collocation.

Reference notebook is inspected as data, never executed. This pipeline preserves
all short clauses and unit boundaries. Modern NLP outputs remain candidates.
"""
import argparse
import gzip
import hashlib
import importlib.metadata
import json
import math
import re
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
from analyze_liaozhai import parse, CJK

SPACE_SUFFIXES = tuple('门窗墙壁户室堂院庭斋楼舍屋宅房宫殿寺庙观墓坟冢墟圃畦园垣关亭台阁榭廊厨床榻山岭洞谷林野郊江河湖海溪池泉桥街巷路道村镇乡县城国港渡寨营第肆店市庵馆扉墉庐居郭田土盆岸塘窟')
SPATIAL_POS = {'n', 'ns', 'f', 'nz', 's', 'g', 'j'}
NOUN_POS = {'n', 'np', 'ns', 'ni', 'nz', 'f', 's', 'g', 'j'}
PIPELINE_VERSION = '4-user-dictionary'
DEFAULT_USER_DICT = Path(__file__).parent/'shuihucihui.txt'
# Stopwords affect result display only, never token distances or denominators.
FUNCTION_WORDS = set('之其而以于於乃则則亦也矣焉乎者所为為不未无無有曰云与與及即遂甚因又已一二三四五六七八九十百千万萬余餘此彼何故且皆但将將可能当當尝嘗复復至得是如若每既向')
FUNCTION_WORDS.update(['于是', '然后', '已经', '不能', '不知', '或者', '一个', '时候', '如此', '所以'])


def json_write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def jsonl_write(path, rows):
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'wt', encoding='utf-8', newline='\n') as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')


def jsonl_read(path):
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt', encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]


def split_units(chapters, converter):
    units = []
    for chapter_id, chapter in enumerate(chapters):
        for m in re.finditer(r'[^。！？；\n]+[。！？；]?', chapter['story']):
            original = m.group()
            if not CJK.search(original):
                continue
            units.append({'unit': len(units), 'chapter_id': chapter_id,
                          'chapter': chapter['title'], 'chapter_offset': m.start(),
                          'original': original, 'text': converter.convert(original)})
    return units


def alignment(original, normalized):
    """Return normalized-character -> original-character positions, including end."""
    mapping = [0] * (len(normalized) + 1)
    for tag, i, j, a, b in SequenceMatcher(None, original, normalized, autojunk=False).get_opcodes():
        for k in range(a, b):
            mapping[k] = i + min(max(j-i-1, 0), (k-a)*(j-i)//max(1, b-a))
        mapping[b] = j
    mapping[-1] = len(original)
    return mapping


def classify_token(word, pos):
    labels = set()
    if pos == 'np':
        labels.add('person')
    if pos == 'ns':
        labels.add('place')
    if pos in SPATIAL_POS and word.endswith(SPACE_SUFFIXES):
        labels.add('space')
    return labels


def mention_add(mentions, start, end, kind, method):
    key = (start, end, kind)
    mentions.setdefault(key, set()).add(method)


def clean_token(word, pos, start):
    """Split punctuation accidentally attached by THULAC; preserve char offsets."""
    if pos == 'w':
        return []
    return [{'word': m.group(), 'pos': pos, 'start': start+m.start(),
             'end': start+m.end()} for m in re.finditer(r'[\u3400-\u4dbf\u4e00-\u9fff]+', word)]


def repair_cached_units(units):
    """Preserve characters and rebuild POS rules after segmentation."""
    first_unit = {}
    for u in units:
        first_unit.setdefault(u['chapter_id'], u['unit'])
        u['tokens'] = [v for t in u['tokens'] for v in clean_token(t['word'], t['pos'], t['start'])]
        covered = {i for t in u['tokens'] for i in range(t['start'],t['end'])}
        # THULAC can silently omit rare classical characters. Never lose corpus data.
        for m in CJK.finditer(u['text']):
            if m.start() not in covered:
                u['tokens'].append({'word':m.group(),'pos':'x_unsegmented',
                                    'start':m.start(),'end':m.end()})
        u['tokens'].sort(key=lambda t:t['start'])
        mentions = {}
        # Keep independent NER guesses; regenerate all rule/POS candidates.
        for m in u['mentions']:
            for method in m['methods']:
                if method.startswith('spacy_'):
                    mention_add(mentions, m['start'], m['end'], m['kind'], method)
        for t in u['tokens']:
            for kind in classify_token(t['word'], t['pos']):
                mention_add(mentions, t['start'], t['end'], kind,
                            'thulac_'+t['pos'] if kind!='space' else 'spatial_suffix')
            # Broad fallback is explicitly unreviewed, including possible verbs.
            if t['word'].endswith(SPACE_SUFFIXES):
                mention_add(mentions, t['start'], t['end'], 'space', 'all_pos_suffix_candidate')
        for i,t in enumerate(u['tokens']):
            if not t['word'].endswith(SPACE_SUFFIXES) or t['pos'] not in SPATIAL_POS:
                continue
            for size in (2,3):
                if i-size+1<0:
                    continue
                span=u['tokens'][i-size+1:i+1]
                if any(x['pos'] not in NOUN_POS|{'a'} for x in span[:-1]):
                    continue
                if any(a['end']!=b['start'] for a,b in zip(span,span[1:])):
                    continue
                if t['end']-span[0]['start']<=6:
                    mention_add(mentions,span[0]['start'],t['end'],'space','noun_compound_suffix')
        if first_unit[u['chapter_id']] == u['unit']:
            m = re.match(r'^\s*([\u4e00-\u9fff]{2,5})[，,]([\u4e00-\u9fff]{1,6})人[，,。]', u['text'])
            if m:
                mention_add(mentions, m.start(1), m.end(1), 'person', 'opening_biography_candidate')
                mention_add(mentions, m.start(2), m.end(2), 'place', 'opening_biography_candidate')
        u['mentions'] = [{'word':u['text'][a:b], 'start':a, 'end':b, 'kind':kind,
                          'methods':sorted(methods)} for (a,b,kind), methods in sorted(mentions.items())]
    return units


def prepare_user_dictionary(source, destination, converter):
    """Normalize one-word-per-line input exactly as the corpus is normalized."""
    data=source.read_bytes()
    words=set()
    for line in data.decode('utf-8-sig').splitlines():
        word=line.strip()
        if not word:
            continue
        if any(c.isspace() for c in word):
            raise ValueError('User dictionary requires one word per line: '+repr(word))
        words.add(converter.convert(word))
    if not words:
        raise ValueError('Empty user dictionary')
    destination.write_text('\n'.join(sorted(words))+'\n',encoding='utf-8')
    return {'source_name':source.name,'source_sha256':hashlib.sha256(data).hexdigest(),
            'normalized_sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
            'unique_words':len(words),'normalization':'OpenCC t2s',
            'format':'UTF-8, one word per line; segmentation only, no entity labels'}


def process_units(units, user_dict=None, ner_units=None):
    import thulac
    import spacy
    print('Loading THULAC and spaCy zh_core_web_sm.', flush=True)
    thu = thulac.thulac(seg_only=False, user_dict=str(user_dict) if user_dict else None)
    nlp = None if ner_units is not None else spacy.load('zh_core_web_sm', disable=['parser', 'tagger', 'attribute_ruler'])
    if ner_units is not None and (len(units)!=len(ner_units) or any(
        (a['original'],a['text'],a['chapter_id'])!=(b['original'],b['text'],b['chapter_id'])
        for a,b in zip(units,ner_units))):
        raise ValueError('NER cache does not match the source passages.')
    # Stage 1: finish the entire corpus segmentation before entity extraction.
    for idx, unit in enumerate(units):
        text, pointer, tokens, mentions = unit['text'], 0, [], {}
        for word, pos in thu.cut(text, text=False):
            start = text.find(word, pointer)
            if start < 0:
                raise ValueError(f"Unalignable THULAC token: {unit['unit']} {word!r}")
            end = start + len(word)
            pointer = end
            if pos == 'w' or not CJK.search(word):
                continue
            tokens.append({'word': word, 'pos': pos, 'start': start, 'end': end})
        unit['tokens'] = tokens
        unit['alignment'] = alignment(unit['original'], text)
        if (idx+1)%500==0:
            print(f"Segmented {idx+1}/{len(units)} clauses", flush=True)
    # Stage 2: independent NER and POS/suffix candidates; never alter segmentation.
    if ner_units is not None:
        for unit,previous in zip(units,ner_units):
            unit['mentions']=[m for m in previous['mentions'] if any(
                method.startswith('spacy_') for method in m['methods'])]
        return units
    docs = nlp.pipe((u['text'] for u in units), batch_size=64)
    for idx, (unit, doc) in enumerate(zip(units, docs)):
        text,tokens,mentions=unit['text'],unit['tokens'],{}
        for ent in doc.ents:
            if not CJK.search(ent.text):
                continue
            if ent.label_ == 'PERSON':
                mention_add(mentions, ent.start_char, ent.end_char, 'person', 'spacy_PERSON')
            elif ent.label_ in ('GPE', 'LOC', 'FAC'):
                kind = 'space' if ent.label_ == 'FAC' else 'place'
                mention_add(mentions, ent.start_char, ent.end_char, kind, 'spacy_' + ent.label_)
        unit['tokens'] = tokens
        unit['alignment'] = alignment(unit['original'], text)
        unit['mentions'] = [
            {'word': text[start:end], 'start': start, 'end': end, 'kind': kind,
             'methods': sorted(methods)} for (start, end, kind), methods in sorted(mentions.items())
        ]
        if (idx+1) % 500 == 0:
            print(f"NER / candidates {idx+1}/{len(units)} clauses", flush=True)
    return units


def inventories(units):
    vocab, by_pos, vocabulary_chapters = Counter(), defaultdict(Counter), defaultdict(set)
    candidate_spans, candidates = defaultdict(set), {}
    for unit in units:
        for t in unit['tokens']:
            vocab[t['word']] += 1
            by_pos[t['word']][t['pos']] += 1
            vocabulary_chapters[t['word']].add(unit['chapter_id'])
        for m in unit['mentions']:
            key = (m['kind'], m['word'])
            candidate_spans[key].add((unit['unit'], m['start'], m['end']))
            r = candidates.setdefault(key, {'kind': m['kind'], 'word': m['word'], 'methods': set(),
                                          'chapter_ids': set(), 'examples': []})
            r['methods'].update(m['methods'])
            r['chapter_ids'].add(unit['chapter_id'])
            if len(r['examples']) < 3:
                start, end = unit['alignment'][m['start']], unit['alignment'][m['end']]
                r['examples'].append({'chapter': unit['chapter'], 'unit': unit['unit'],
                                      'original_form': unit['original'][start:end],
                                      'context': unit['original'][max(0, start-20):end+30]})
    rows = []
    for key, row in candidates.items():
        row['mentions'] = len(candidate_spans[key])
        row['methods'] = sorted(row['methods'])
        row['chapters'] = len(row.pop('chapter_ids'))
        row['review_status'] = 'unreviewed_candidate'
        rows.append(row)
    vocabulary = [{'word': w, 'frequency': f, 'pos': dict(by_pos[w]),
                   'chapters': len(vocabulary_chapters[w])} for w, f in vocab.most_common()]
    return vocabulary, sorted(rows, key=lambda r: (-r['mentions'], r['kind'], r['word']))


def collect_occurrences(units, target_words):
    """Unique spans, even if POS and NER discover the same mention."""
    occurrences = defaultdict(list)
    for unit in units:
        spans = {(m['word'], m['start'], m['end']) for m in unit['mentions'] if m['word'] in target_words}
        spans.update((t['word'], t['start'], t['end']) for t in unit['tokens'] if t['word'] in target_words)
        for word, start, end in sorted(spans):
            overlap = [i for i, t in enumerate(unit['tokens']) if t['end'] > start and t['start'] < end]
            if overlap:
                occurrences[word].append((unit['unit'], min(overlap), max(overlap)+1, start, end))
    return occurrences


def window_margins(units, spans, horizon, global_counts):
    """Bernoulli unit = a non-target token position, covered once per target."""
    occupied, covered = defaultdict(set), defaultdict(set)
    for unit_id, start, end, *_ in spans:
        occupied[unit_id].update(range(start, end))
        covered[unit_id].update(range(max(0, start-horizon), min(len(units[unit_id]['tokens']), end+horizon)))
    removed, local, support = Counter(), Counter(), defaultdict(set)
    for unit_id, positions in occupied.items():
        removed.update(units[unit_id]['tokens'][i]['word'] for i in positions)
    for unit_id, positions in covered.items():
        positions.difference_update(occupied[unit_id])
        for i in positions:
            word = units[unit_id]['tokens'][i]['word']
            local[word] += 1
            support[word].add(units[unit_id]['chapter_id'])
    eligible = sum(global_counts.values()) - sum(removed.values())
    exposure = sum(local.values())
    eligible_frequency = global_counts - removed
    return eligible, exposure, eligible_frequency, local, support


def contingency(n, exposure, frequency, observed):
    table = [[observed, exposure-observed], [frequency-observed, n-exposure-frequency+observed]]
    if any(v < 0 for row in table for v in row) or sum(map(sum, table)) != n:
        raise ValueError(f'Invalid contingency table: {table} N={n}')
    expected = exposure * frequency / n if n else 0
    return table, expected, observed/expected if expected else 0


def bh_adjust(pvalues, total_tests=None):
    """BH with implicit p=1 for unobserved pairs; report test-family size."""
    m = total_tests if total_tests is not None else len(pvalues)
    order = sorted(range(len(pvalues)), key=lambda i: pvalues[i])
    adjusted, previous = [1.0]*len(pvalues), 1.0
    for rank_index in range(len(order)-1, -1, -1):
        i = order[rank_index]
        previous = min(previous, pvalues[i]*m/(rank_index+1), 1.0)
        adjusted[i] = previous
    return adjusted


def collocations(units, target_words, horizon=5, method='window', reviewed_occurrences=None):
    from scipy.stats import fisher_exact
    global_counts = Counter(t['word'] for u in units for t in u['tokens'])
    vocabulary = {w for w, f in global_counts.items() if f >= 5}
    occurrences = reviewed_occurrences if reviewed_occurrences is not None else collect_occurrences(units, target_words)
    sentence_counts = Counter(w for u in units for w in {t['word'] for t in u['tokens']})
    rows, test_family = [], 0
    for target in sorted(target_words):
        spans = occurrences[target]
        if not spans:
            continue
        if method == 'window':
            n, exposure, eligible_freq, local, support = window_margins(units, spans, horizon, global_counts)
        else:
            selected = {s[0] for s in spans}
            n, exposure, eligible_freq = len(units), len(selected), sentence_counts
            local, support = Counter(), defaultdict(set)
            for unit_id in selected:
                for word in {t['word'] for t in units[unit_id]['tokens']}:
                    local[word] += 1
                    support[word].add(units[unit_id]['chapter_id'])
        test_family += len(vocabulary - {target})
        for word, observed in local.items():
            if word not in vocabulary or word == target:
                continue
            table, expected, ratio = contingency(n, exposure, eligible_freq[word], observed)
            p = float(fisher_exact(table, alternative='greater').pvalue)
            rows.append({'target': target, 'collocate': word, 'method': method, 'horizon': horizon if method=='window' else None,
                         'target_mentions': len(spans), 'observed': observed, 'expected': round(expected, 8),
                         'oe_ratio': round(ratio, 6), 'log2_oe': round(math.log2(ratio), 6) if ratio else None,
                         'global_token_frequency': global_counts[word], 'eligible_frequency': eligible_freq[word],
                         'eligible_positions': n, 'covered_positions': exposure,
                         'support_chapters': len(support[word]), 'p_value': p})
    q = bh_adjust([r['p_value'] for r in rows], test_family)
    for r, value in zip(rows, q):
        r['q_value'] = value
    return rows, test_family


def profile_rows(rows, min_count=3):
    return [r for r in rows if r['observed'] >= min_count and r['collocate'] not in FUNCTION_WORDS and r['oe_ratio'] > 1]


def comparisons(rows, spatial_targets):
    profiles, top = {}, {}
    for target in sorted(spatial_targets):
        values = [r for r in profile_rows(rows) if r['target'] == target]
        profiles[target] = {r['collocate']: r['log2_oe'] * math.sqrt(r['observed']) for r in values}
        ranked = sorted(values, key=lambda r: (r['oe_ratio'], r['observed']), reverse=True)
        top[target] = [r['collocate'] for r in ranked[:20]]
    pairs = []
    words = sorted(profiles)
    for i, a in enumerate(words):
        for b in words[i+1:]:
            pa, pb = profiles[a], profiles[b]
            norm = math.sqrt(sum(v*v for v in pa.values()) * sum(v*v for v in pb.values()))
            cosine = sum(pa[w]*pb[w] for w in pa.keys() & pb.keys())/norm if norm else None
            sa, sb = set(top[a]), set(top[b])
            union = sa | sb
            pairs.append({'a': a, 'b': b, 'cosine': round(cosine, 5) if cosine is not None else None,
                          'top20_jaccard': round(len(sa & sb)/len(union), 5) if union else None,
                          'shared': sorted(sa & sb), 'a_only': sorted(sa-sb), 'b_only': sorted(sb-sa)})
    return sorted(pairs, key=lambda p: -(p['cosine'] or 0))


def kwic(units, word, limit=12, chapter=None):
    rows = []
    for u in units:
        if chapter and u['chapter'] != chapter:
            continue
        spans = {(m['start'], m['end']) for m in u['mentions'] if m['word'] == word}
        spans.update((t['start'], t['end']) for t in u['tokens'] if t['word'] == word)
        for start, end in sorted(spans):
            a, b = u['alignment'][start], u['alignment'][end]
            rows.append({'chapter': u['chapter'], 'chapter_id': u['chapter_id'], 'unit': u['unit'],
                         'original': u['original'][max(0, a-25):b+35],
                         'normalized_word': word, 'original_form': u['original'][a:b]})
    return rows[:limit]


def main():
    from opencc import OpenCC
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--phase', choices=['discover', 'collocate', 'all'], default='all')
    parser.add_argument('--reuse', action='store_true')
    parser.add_argument('--repair-cache', action='store_true')
    parser.add_argument('--user-dict',type=Path,default=DEFAULT_USER_DICT)
    parser.add_argument('--ner-cache',type=Path,help='Reuse independent NER on identical passages, but rebuild segmentation.')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    dictionary_path=args.out/'user_dictionary_t2s.txt'
    dictionary=prepare_user_dictionary(args.user_dict,dictionary_path,OpenCC('t2s'))
    data = args.source.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    chapters = parse(data.decode('utf-8-sig'))
    cache = args.out/'segmented_units.jsonl.gz'
    manifest_path = args.out/'manifest.json'
    if args.reuse and cache.exists():
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        if manifest['source_sha256'] != sha:
            raise ValueError('Cached segmentation belongs to a different input file.')
        if manifest.get('user_dictionary')!=dictionary:
            raise ValueError('Cached segmentation uses a different dictionary; rebuild without --reuse.')
        if not args.repair_cache and manifest.get('pipeline_version')!=PIPELINE_VERSION:
            raise ValueError('Cache rule version mismatch; use --repair-cache or rebuild.')
        units = jsonl_read(cache)
    else:
        units = process_units(split_units(chapters, OpenCC('t2s')),dictionary_path,
                              jsonl_read(args.ner_cache) if args.ner_cache else None)
        units = repair_cached_units(units)
        jsonl_write(cache, units)
        manifest = {'source_sha256': sha, 'chapter_units': len(chapters), 'clauses': len(units),
                    'cjk_characters': sum(len(CJK.findall(c['story'])) for c in chapters),
                    'segmentation': 'THULAC POS with user dictionary', 'NER': 'spaCy zh_core_web_sm',
                    'user_dictionary':dictionary,
                    'normalization': 'OpenCC t2s; original forms and offset alignment retained',
                    'pipeline_version': PIPELINE_VERSION,
                    'candidate_rules': 'Model/POS union + spatial suffixes; dictionary uw tag is not an entity type',
                    'packages': {p: importlib.metadata.version(p) for p in ['thulac', 'spacy', 'zh_core_web_sm', 'scipy', 'opencc-python-reimplemented']}}
    vocabulary, candidates = inventories(units)
    if args.repair_cache:
        units = repair_cached_units(units)
        jsonl_write(cache, units)
        vocabulary, candidates = inventories(units)
        manifest['pipeline_version'] = PIPELINE_VERSION
        manifest['candidate_rules'] = 'Model/POS union + spatial suffixes; dictionary uw tag is not an entity type'
    json_write(args.out/'vocabulary.json', vocabulary)
    json_write(args.out/'entity_space_candidates.json', candidates)
    manifest.update({'lexical_tokens': sum(r['frequency'] for r in vocabulary), 'word_types': len(vocabulary),
                     'unsegmented_character_fallbacks': sum(t['pos']=='x_unsegmented' for u in units for t in u['tokens']),
                     'candidate_types_by_kind': dict(Counter(r['kind'] for r in candidates)),
                     'candidate_mentions_by_kind': dict(Counter({kind: sum(r['mentions'] for r in candidates if r['kind']==kind) for kind in ['person','place','space']}))})
    json_write(manifest_path, manifest)
    print(json.dumps(manifest, ensure_ascii=False), flush=True)
    if args.phase == 'discover':
        return
    target_words = {r['word'] for r in candidates if r['mentions'] >= 3 and len(r['word']) <= 8}
    spatial_targets = {r['word'] for r in candidates if r['kind']=='space' and r['mentions']>=20 and len(r['word']) <= 4}
    json_write(args.out/'analysis_targets.json', {'targets': sorted(target_words), 'spatial_comparison_targets': sorted(spatial_targets),
               'rules': 'all candidates >=3 mentions and <=8 chars; spatial comparisons >=20 mentions and <=4 chars'})
    for method, horizon in [('window', 5), ('window', 10), ('sentence', 0)]:
        print(f'Calculating {method} h={horizon} for {len(target_words)} candidate targets', flush=True)
        rows, family = collocations(units, target_words, horizon=horizon, method=method)
        filename = f'collocations_{method}{horizon}.jsonl.gz'
        jsonl_write(args.out/filename, rows)
        filtered = profile_rows(rows)
        top = defaultdict(list)
        for r in sorted(filtered, key=lambda r: (r['oe_ratio'], r['observed']), reverse=True):
            if len(top[r['target']]) < 30:
                top[r['target']].append(r)
        json_write(args.out/f'top_collocations_{method}{horizon}.json', dict(top))
        manifest[f'{method}{horizon}'] = {'observed_pairs': len(rows), 'test_family_including_zero_pairs': family}
        if method=='window' and horizon==5:
            json_write(args.out/'spatial_comparisons.json', comparisons(rows, spatial_targets))
    json_write(manifest_path, manifest)
    print('All collocation outputs complete.', flush=True)


if __name__ == '__main__':
    main()
