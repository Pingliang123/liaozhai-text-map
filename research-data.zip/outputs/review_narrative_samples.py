"""Explicit AI editorial corrections from reading the source, not POS rules.

Retain before/after fields and exact source evidence. These sample corrections
do not claim semantic review of all generated interpretations.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
from ai_narrative_paths import load_cache, save, validate

SUMMARIES = {
    '钟生': '钟庆余应济南乡试，在趵突泉遇道士，闻母将逝，欲弃试归家。两次贳驴均受阻，他仍完场后归家，母服丹痊愈，又梦阴司因其子纯孝赐寿。中举后再访道士，得知妻子将殁、继室在中州。省舅途中因惊驴致世子堕河，逃向东南山村，入赘方叟甥女。夫妻赴南山求僧，经险径、跪沙砾，终以断杖代死脱罪，归辽阳。科场、家庭、避难村与山寺形成孝德、命数和权力危机交织的路径。',
    '黄英': '马子才嗜菊，赴金陵购种，归途携陶生姊弟同归。陶以种菊贩花致富，南北两第渐合；马妻亡后娶黄英，却因羞于依靠妻财反复分居、复合。陶醉后化菊，马模仿拔菊操作并守候观看，待叶枯才告黄英。黄英将残梗埋盆、携入闺中灌溉，后长出名为“醉陶”的菊，不等于陶恢复人形。宅院边界表现财产与婚姻关系，菊畦到闺房盆花的转换则关联照护、亲属丧失与记忆。',
    '罗刹海市': '马骥漂流入罗刹国，以煤涂面才获显位，随后因真面目被疑而退居村中。海市贸易引他进入龙宫，以文才受赏并娶龙女；思亲后返家，妻已亡，遂按龙女所许纳婢。三年后在南岛接回儿女福海、龙宫；母亡时龙女临穴尽妇职。福海可入海探母，女儿龙宫不得往而哭，龙女来赠女儿嫁资，与马骥短暂重逢后随雷而去。异域评价秩序、跨界婚姻和不同家庭成员的通行条件构成全篇空间对照。',
}
NEEDLES = {'钟生': ['不得已，从之', '辞母如济', '钟舅令于西江'],
           '黄英': ['根株已枯', '掐其梗', '醉陶'],
           '罗刹海市': ['龙宫以女子不得往', '为嫁资', '女已无矣']}
NOTES = {'钟生':'依据完场及省亲原文修正摘要；不以辽东籍贯补出家中位置，西江与中州的地点作用保持待核。',
         '黄英':'区分陶的人形复原与残梗培育成醉陶菊；不能把结尾视为陶本人复活。',
         '罗刹海市':'龙宫在末段是女儿名字；拆开福海往返、女儿哭泣及龙女来访，不把不同人物都画成进入龙宫，也不宣称所有跨界联系断绝。'}


def review(cache, chapters):
    result = json.loads(json.dumps(cache))
    for title, summary in SUMMARIES.items():
        source = next(c for c in chapters if c['chapter'] == title)
        record = result['chapters'][str(source['chapter_id'])]
        analysis = record['analysis']
        changes = []
        def change(row, key, value, path):
            if row.get(key) != value:
                changes.append({'field':path,'before':row.get(key),'after':value})
                row[key] = value
        change(analysis,'summary',summary,'summary')
        if title == '黄英':
            for i,row in enumerate(analysis['events']):
                if '救活异类生命' in row['interpretation']:
                    change(row,'interpretation','残梗从公开菊畦移入私密闺房盆养，表现亲属照护与记忆；后生醉陶菊，不等于陶恢复人形。',f'events[{i}].interpretation')
                    change(row,'identity','马为误处置者；黄英为哀悼并照护残梗的姊；陶未恢复人形',f'events[{i}].identity')
        if title == '钟生':
            for i,row in enumerate(analysis['events']):
                for field in ('location','from_space','to_space'):
                    value=row.get(field,'')
                    if '辽东' in value and i != 0:
                        value=value.replace('辽东家中','家中（该段具体地名未明）').replace('辽东','家中（该段具体地名未明）')
                        change(row,field,value,f'events[{i}].{field}')
                if row.get('to_space') == '西江、中州':
                    change(row,'to_space','省亲途中（拟途经中州，未明实际村名）',f'events[{i}].to_space')
                    change(row,'location','西江：舅任职地，区域指向待核；中州：拟途经地',f'events[{i}].location')
        if title == '罗刹海市' and len(analysis['events']) == 26:
            units=source['source_units']
            def step(needle,actors,space,event,identity,interpretation,kind='plot',departure='',arrival='',end=None):
                start=next(i for i,u in enumerate(units) if needle in u['text'])
                stop=next(i for i in range(start,len(units)) if end in units[i]['text']) if end else start
                row={'unit':units[start]['unit'],'quote':''.join(u['text'] for u in units[start:stop+1]),
                     'actors':actors,'location':space,'space':space,'event':event,'identity':identity,
                     'interpretation':interpretation,'temporal_order':'顺叙','transition_kind':kind,
                     'from_space':departure,'to_space':arrival}
                if stop!=start:row['unit_end']=units[stop]['unit']
                return row
            rows=analysis['events'][:-1]+[
                step('福海稍长','福海','海中','福海思母，自行投入海中；原文没有明说所到宫殿。','马骥与龙女之子',
                     '福海获得往还母亲所在世界的通路；不能给马骥、女儿龙宫补出同行。','movement','人间（具体出发处未明）','海中'),
                step('福海稍长','福海','人间','福海数日后返回；该句未明具体返回处。','马骥与龙女之子',
                     '往返并未使家庭永久团聚，但证明不能把结尾概括成一切跨界联系断绝。','movement','海中','人间（具体返回处未明）'),
                step('龙宫以女子不得往','龙宫（女儿）','人间家中','女儿龙宫不得往母亲处，常掩户哭泣。','马骥与龙女之女',
                     '女儿与福海的通行条件不同；此处龙宫是人名，不能作为进入宫殿的证据。'),
                step('一日昼暝','龙女、龙宫（女儿）、马骥','人间家中','龙女来赠女儿嫁资，马骥入内执手哭；随后雷声中龙女消失。','母亲、女儿与父亲',
                     '女儿无法前往而母亲来访，形成另一种联络；原文未明龙女这次的出发处及离去目的地。',end='女已无矣')]
            change(analysis,'events',rows,'events: split the last compound paragraph by actor and action')
        if changes:
            evidence=[]
            for needle in NEEDLES[title]:
                unit=next(u for u in source['source_units'] if needle in u['text'])
                evidence.append({'unit':unit['unit'],'quote':unit['text']})
            record.setdefault('editorial_reviews',[]).append({'reviewer':'Codex（AI辅助原文核读）',
                'reviewed_at':datetime.now(timezone.utc).isoformat(),'changes':changes,'evidence':evidence,
                'note':NOTES[title]+'仅审阅列示字段，其余解释仍待人工复核。'})
        for item in record.get('editorial_reviews',[]):
            if item.get('reviewer')=='Codex（AI辅助原文核读）':item['note']=NOTES[title]+'仅审阅列示字段，其余解释仍待人工复核。'
        validate(analysis,source)
    return result


if __name__=='__main__':
    path=Path(__file__).parent/'ghost_map'/'歷史地名對照與文本地圖.json'
    chapters=json.loads(path.read_text(encoding='utf8'))['chapter_overview']
    save(review(load_cache(),chapters))
    print('Reviewed 3 source-grounded samples; before/after evidence retained')
