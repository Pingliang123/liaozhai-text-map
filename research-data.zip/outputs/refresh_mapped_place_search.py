"""Cache Qing reference records for the older curated map points."""
import json
from pathlib import Path
from refresh_historical_place_search import refresh


def main():
    from build_ghost_gis import GAZETTEER, NORMAL
    rows = [{'place': NORMAL(p['name'])} for p in GAZETTEER]
    rows += [{'place': name} for name in ['徐州', '洛阳', '山西', '福建', '瓜洲']]
    rows = list({r['place']: r for r in rows}.values())
    result = refresh(rows, 1820, workers=4)
    target = Path(__file__).parent / 'ghost_map' / '已定位地名_清代核对.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'queried': result['count'], 'with_results': result['with_results'],
                      'failed': sum('error' in r for r in result['records'])}))


if __name__ == '__main__':
    main()
