"""Execute only our authored notebook, capture outputs and fail on any exception."""
import ast
import argparse
import contextlib
import io
import json
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--notebook',choices=['nlp','book-space','ghost-map'],default='nlp')
    selected=parser.parse_args().notebook
    # Explicit allowlist: never execute the user-supplied reference notebook.
    paths={'nlp':('nlp','聊齋全書分詞與搭配分析.ipynb'),
           'book-space':('book_space','全書空間詞族分析.ipynb'),
           'ghost-map':('ghost_map','全書鬼怪地圖分析.ipynb')}
    path=Path(__file__).parent.joinpath(*paths[selected])
    notebook=json.loads(path.read_text(encoding='utf-8'))
    namespace={'__name__':'__notebook__'}
    count=0
    for cell in notebook['cells']:
        if cell['cell_type']!='code':
            continue
        count+=1
        tree=ast.parse(''.join(cell['source']))
        output=io.StringIO()
        value=None
        with contextlib.redirect_stdout(output):
            last=tree.body.pop() if tree.body and isinstance(tree.body[-1],ast.Expr) else None
            exec(compile(tree,str(path),'exec'),namespace)
            if last:
                value=eval(compile(ast.Expression(last.value),str(path),'eval'),namespace)
        cell['execution_count']=count
        cell['outputs']=[]
        if output.getvalue():
            cell['outputs'].append({'output_type':'stream','name':'stdout','text':output.getvalue().splitlines(keepends=True)})
        if value is not None:
            cell['outputs'].append({'output_type':'execute_result','execution_count':count,
                'metadata':{},'data':{'text/plain':[repr(value)]}})
    notebook['metadata']['execution_note']='Executed authored Python code cells sequentially; no attachment code was executed.'
    path.write_text(json.dumps(notebook,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Executed {count} authored notebook cells successfully.')

if __name__=='__main__':
    main()
